/* Ofront 1.1 */

#ifndef Books0__h
#define Books0__h

#include "SYSTEM.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Objects.h"
#include "Texts.h"

typedef
	struct Books0_BarDesc *Books0_Bar;

typedef
	struct Books0_BarDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		char _prvt0[2];
	} Books0_BarDesc;

typedef
	struct Books0_ContElemDesc *Books0_ContElem;

typedef
	struct Books0_ContElemDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		SHORTINT mode;
		LONGINT beg, end;
		char _prvt0[2];
	} Books0_ContElemDesc;

typedef
	struct Books0_ExtFrameDesc *Books0_ExtFrame;

typedef
	struct Books0_FrameDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		SHORTINT mode;
	} Books0_FrameDesc;

typedef
	struct Books0_ExtLabelDesc *Books0_ExtLabel;

typedef
	struct Books0_ExtFrameDesc { /* Books0_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		SHORTINT mode;
		Books0_ExtLabel imp;
	} Books0_ExtFrameDesc;

typedef
	Books0_FrameDesc *Books0_Frame;

typedef
	struct Books0_ImpListDesc *Books0_ImpList;

typedef
	struct Books0_ExtLabelDesc {
		Books0_Frame frame;
		Books0_ImpList book;
		CHAR name[32];
		SHORTINT mode;
		LONGINT pos1, pos2;
		Books0_ExtLabel next;
	} Books0_ExtLabelDesc;

typedef
	struct Books0_ImpListDesc {
		CHAR name[32];
		Texts_Text notes;
		LONGINT ind;
		Books0_ExtLabel extLabels;
		Books0_ImpList next;
	} Books0_ImpListDesc;

typedef
	struct Books0_LocFrameDesc *Books0_LocFrame;

typedef
	struct Books0_LocFrameDesc { /* Books0_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		SHORTINT mode;
		LONGINT pos1, pos2;
	} Books0_LocFrameDesc;

typedef
	struct Books0_TextListDesc *Books0_TextList;

typedef
	struct Books0_TextListDesc {
		Texts_Text text;
		Books0_TextList prev, next;
	} Books0_TextListDesc;


extern Books0_ImpList Books0_loading;
extern BOOLEAN Books0_error;
extern void (*Books0_Action)();

extern long *Books0_FrameDesc__typ;
extern long *Books0_LocFrameDesc__typ;
extern long *Books0_ExtFrameDesc__typ;
extern long *Books0_ImpListDesc__typ;
extern long *Books0_ExtLabelDesc__typ;
extern long *Books0_TextListDesc__typ;
extern long *Books0_ContElemDesc__typ;
extern long *Books0_BarDesc__typ;

extern void Books0_AppendFrame();
extern void Books0_BarFrameHandler();
extern void Books0_ColorBar();
extern void Books0_CutSuffix();
extern void Books0_InsertFrame();
extern void Books0_NewBar();
extern void Books0_NewContElem();
extern void Books0_NewExt();
extern void Books0_NewLoc();
extern void Books0_StrConcat();
extern void *Books0__init();


#endif
