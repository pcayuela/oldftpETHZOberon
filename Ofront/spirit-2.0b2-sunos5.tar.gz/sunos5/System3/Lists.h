/* Ofront 1.1 */

#ifndef Lists__h
#define Lists__h

#include "SYSTEM.h"
#include "Attributes.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Objects.h"

typedef
	struct Lists_ItemDesc *Lists_Item;

typedef
	struct Lists_ItemDesc {
		BOOLEAN sel;
		CHAR s[64];
		Lists_Item prev, next;
	} Lists_ItemDesc;

typedef
	struct Lists_ListDesc *Lists_List;

typedef
	struct Lists_ListDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		Lists_Item items, beg, pointed;
		LONGINT time;
		BOOLEAN focus, sorted;
		INTEGER noitems;
		CHAR cmd[64];
		BOOLEAN scrollbar;
		char _prvt0[19];
	} Lists_ListDesc;



extern long *Lists_ItemDesc__typ;
extern long *Lists_ListDesc__typ;

extern void Lists_CopyList();
extern void Lists_DeleteSelection();
extern void Lists_DeselectList();
extern void Lists_Directory();
extern void Lists_Diskette();
extern void Lists_GetSelection();
extern void Lists_InitList();
extern void Lists_InsertItem();
extern void Lists_InsertItems();
extern void Lists_Library();
extern void Lists_ListFiles();
extern void Lists_ListHandler();
extern void Lists_NewList();
extern void *Lists__init();


#endif
