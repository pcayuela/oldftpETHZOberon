/* Ofront 1.1 */

#ifndef Organizers__h
#define Organizers__h

#include "SYSTEM.h"




extern void Organizers_Exchange();
extern void Organizers_Handler();
extern BOOLEAN Organizers_HasConstraints();
extern void Organizers_InitPanel();
extern void Organizers_NewPanel();
extern void Organizers_Solve();
extern void Organizers_SolveGadget();
extern void *Organizers__init();


#endif
