/* Ofront 1.1 */

#ifndef Args__h
#define Args__h

#include "SYSTEM.h"


extern LONGINT Args_argc, Args_argv;


extern void Args_Get();
extern void Args_GetEnv();
extern void Args_GetInt();
extern INTEGER Args_Pos();
extern void *Args__init();


#endif
