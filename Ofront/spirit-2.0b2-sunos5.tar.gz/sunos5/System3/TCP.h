/* Ofront 1.1 */

#ifndef TCP__h
#define TCP__h

#include "SYSTEM.h"

typedef
	struct TCP_ConnectionDesc *TCP_Connection;

typedef
	struct TCP_ConnectionDesc {
		BOOLEAN eos;
		LONGINT res;
		char _prvt0[8];
	} TCP_ConnectionDesc;

typedef
	struct TCP_ListenerDesc *TCP_Listener;

typedef
	struct TCP_ListenerDesc {
		INTEGER lport;
		LONGINT _prvt0;
	} TCP_ListenerDesc;



extern long *TCP_ConnectionDesc__typ;
extern long *TCP_ListenerDesc__typ;

extern void TCP_Accept();
extern LONGINT TCP_Available();
extern void TCP_Close();
extern void TCP_Connect();
extern BOOLEAN TCP_Connected();
extern void TCP_Disconnect();
extern void TCP_GetHostName();
extern void TCP_HostByName();
extern void TCP_HostByNumber();
extern void TCP_Listen();
extern void TCP_Read();
extern void TCP_ReadBytes();
extern BOOLEAN TCP_Requested();
extern void TCP_Write();
extern void TCP_WriteBytes();
extern LONGINT TCP_htonl();
extern INTEGER TCP_htons();
extern LONGINT TCP_ntohl();
extern INTEGER TCP_ntohs();
extern void *TCP__init();


#endif
