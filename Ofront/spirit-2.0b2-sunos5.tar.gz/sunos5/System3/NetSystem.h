/* Ofront 1.1 */

#ifndef NetSystem__h
#define NetSystem__h

#include "SYSTEM.h"

typedef
	struct NetSystem_ConnectionDesc *NetSystem_Connection;

typedef
	struct NetSystem_ConnectionDesc {
		BOOLEAN eos;
		LONGINT res;
		INTEGER lport;
		char _prvt0[2082];
	} NetSystem_ConnectionDesc;

typedef
	CHAR NetSystem_IPAdr[4];


extern CHAR NetSystem_user[17], NetSystem_passwd[17];
extern CHAR NetSystem_hostName[65], NetSystem_gateway[65];
extern NetSystem_IPAdr NetSystem_hostIP, NetSystem_anyIP;

extern long *NetSystem_ConnectionDesc__typ;

extern void NetSystem_Accept();
extern LONGINT NetSystem_Available();
extern void NetSystem_CloseConnection();
extern void NetSystem_GetIP();
extern void NetSystem_OpenConnection();
extern void NetSystem_Read();
extern void NetSystem_ReadBool();
extern void NetSystem_ReadBytes();
extern void NetSystem_ReadInt();
extern void NetSystem_ReadLInt();
extern void NetSystem_ReadLReal();
extern void NetSystem_ReadNum();
extern void NetSystem_ReadReal();
extern void NetSystem_ReadSet();
extern void NetSystem_ReadString();
extern BOOLEAN NetSystem_Requested();
extern void NetSystem_Start();
extern INTEGER NetSystem_State();
extern void NetSystem_Write();
extern void NetSystem_WriteBool();
extern void NetSystem_WriteBytes();
extern void NetSystem_WriteInt();
extern void NetSystem_WriteLInt();
extern void NetSystem_WriteLReal();
extern void NetSystem_WriteNum();
extern void NetSystem_WriteReal();
extern void NetSystem_WriteSet();
extern void NetSystem_WriteString();
extern void *NetSystem__init();


#endif
