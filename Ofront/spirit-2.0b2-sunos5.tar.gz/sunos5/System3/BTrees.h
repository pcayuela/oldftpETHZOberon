/* Ofront 1.1 */

#ifndef BTrees__h
#define BTrees__h

#include "SYSTEM.h"

typedef
	void (*BTrees_EnumLIntProc)();

typedef
	void (*BTrees_EnumStrProc)();

typedef
	struct BTrees_TreeDesc *BTrees_Tree;

typedef
	struct BTrees_TreeDesc {
		LONGINT _prvt0;
		char _prvt1[18];
	} BTrees_TreeDesc;


extern CHAR BTrees_MinStrKey[64], BTrees_MaxStrKey[64];

extern long *BTrees_TreeDesc__typ;

extern void BTrees_Close();
extern void BTrees_EnumLInt();
extern void BTrees_EnumStr();
extern void BTrees_InsertLInt();
extern void BTrees_InsertStr();
extern BTrees_Tree BTrees_NewLInt();
extern BTrees_Tree BTrees_NewStr();
extern BTrees_Tree BTrees_Old();
extern void BTrees_SearchLInt();
extern void BTrees_SearchStr();
extern void *BTrees__init();


#endif
