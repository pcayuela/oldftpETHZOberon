/* Ofront 1.1 */

#ifndef Oberon__h
#define Oberon__h

#include "SYSTEM.h"
#include "Display.h"
#include "Fonts.h"
#include "Objects.h"
#include "Texts.h"
#include "Viewers.h"

typedef
	struct Oberon_CaretMsg { /* Display_FrameMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
		INTEGER id;
		Display_Frame car;
		Texts_Text text;
		LONGINT pos;
	} Oberon_CaretMsg;

typedef
	struct Oberon_ConsumeMsg { /* Display_FrameMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
		INTEGER id, u, v;
		Texts_Text text;
		LONGINT beg, end;
	} Oberon_ConsumeMsg;

typedef
	struct Oberon_ControlMsg { /* Display_FrameMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
		INTEGER id, X, Y;
	} Oberon_ControlMsg;

typedef
	void (*Oberon_Painter)();

typedef
	struct Oberon_Marker {
		Oberon_Painter Fade, Draw;
	} Oberon_Marker;

typedef
	struct Oberon_Cursor {
		Oberon_Marker marker;
		BOOLEAN on;
		INTEGER X, Y;
	} Oberon_Cursor;

typedef
	void (*Oberon_Handler)();

typedef
	struct Oberon_InputMsg { /* Display_FrameMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
		INTEGER id;
		SET keys;
		INTEGER X, Y;
		CHAR ch;
		Fonts_Font fnt;
		SHORTINT col, voff;
	} Oberon_InputMsg;

typedef
	struct Oberon_ParRec *Oberon_ParList;

typedef
	struct Oberon_ParRec {
		Viewers_Viewer vwr;
		Display_Frame frame;
		Objects_Object obj;
		Texts_Text text;
		LONGINT pos;
	} Oberon_ParRec;

typedef
	struct Oberon_RecallMsg { /* Display_FrameMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
	} Oberon_RecallMsg;

typedef
	struct Oberon_SelectMsg { /* Display_FrameMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
		INTEGER id;
		LONGINT time;
		Display_Frame sel;
		Texts_Text text;
		LONGINT beg, end;
	} Oberon_SelectMsg;

typedef
	struct Oberon_TaskDesc *Oberon_Task;

typedef
	struct Oberon_TaskDesc {
		char _prvt0[4];
		LONGINT time;
		BOOLEAN safe;
		Oberon_Handler handle;
	} Oberon_TaskDesc;


extern CHAR Oberon_User[32];
extern LONGINT Oberon_Password;
extern Oberon_Marker Oberon_Arrow, Oberon_Star;
extern Oberon_Cursor Oberon_Mouse, Oberon_Pointer;
extern Texts_Text Oberon_Log;
extern Oberon_ParList Oberon_Par;
extern Fonts_Font Oberon_CurFnt;
extern SHORTINT Oberon_CurCol, Oberon_CurOff;
extern CHAR Oberon_OptionChar;

extern long *Oberon_Marker__typ;
extern long *Oberon_Cursor__typ;
extern long *Oberon_ParRec__typ;
extern long *Oberon_ControlMsg__typ;
extern long *Oberon_InputMsg__typ;
extern long *Oberon_CaretMsg__typ;
extern long *Oberon_SelectMsg__typ;
extern long *Oberon_ConsumeMsg__typ;
extern long *Oberon_RecallMsg__typ;
extern long *Oberon_TaskDesc__typ;

extern void Oberon_AllocateSystemViewer();
extern void Oberon_AllocateUserViewer();
extern void Oberon_Call();
extern void Oberon_Collect();
extern void Oberon_Defocus();
extern INTEGER Oberon_DisplayHeight();
extern INTEGER Oberon_DisplayWidth();
extern void Oberon_DrawCursor();
extern void Oberon_FadeCursor();
extern void Oberon_GetClock();
extern void Oberon_GetSelection();
extern void Oberon_Install();
extern void Oberon_Loop();
extern Viewers_Viewer Oberon_MarkedViewer();
extern void Oberon_OpenCursor();
extern void Oberon_OpenDisplay();
extern void Oberon_OpenTrack();
extern void Oberon_Remove();
extern void Oberon_RemoveMarks();
extern void Oberon_SetClock();
extern void Oberon_SetColor();
extern void Oberon_SetFont();
extern void Oberon_SetOffset();
extern void Oberon_SetUser();
extern INTEGER Oberon_SystemTrack();
extern LONGINT Oberon_Time();
extern INTEGER Oberon_UserTrack();
extern void *Oberon__init();


#endif
