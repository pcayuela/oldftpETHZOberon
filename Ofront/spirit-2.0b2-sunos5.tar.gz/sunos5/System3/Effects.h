/* Ofront 1.1 */

#ifndef Effects__h
#define Effects__h

#include "SYSTEM.h"
#include "Oberon.h"

typedef
	void (*Effects_Callback)();


extern Oberon_Marker Effects_FlatHand, Effects_PointHand, Effects_Arrow;
extern INTEGER Effects_gravity;
extern CHAR Effects_optionChar;


extern void Effects_Bar();
extern INTEGER Effects_BarPos();
extern LONGINT Effects_BarValue();
extern void Effects_CloseCursor();
extern void Effects_CloseMenu();
extern BOOLEAN Effects_InBorder();
extern BOOLEAN Effects_InCorner();
extern BOOLEAN Effects_InLineVicinity();
extern void Effects_InitPalette();
extern BOOLEAN Effects_Inside();
extern BOOLEAN Effects_Intersect();
extern BOOLEAN Effects_Invicinity();
extern void Effects_MoveRect();
extern void Effects_OpenCursor();
extern void Effects_OpenMenu();
extern void Effects_SetSnap();
extern void Effects_SizeRect();
extern void Effects_Snap();
extern void Effects_TrackBar();
extern void Effects_TrackCross();
extern void Effects_TrackHighlight();
extern void Effects_TrackMouse();
extern void *Effects__init();


#endif
