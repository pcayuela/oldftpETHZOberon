/* Ofront 1.1 */

#ifndef ExternalApps__h
#define ExternalApps__h

#include "SYSTEM.h"


extern LONGINT ExternalApps_lastError;


extern BOOLEAN ExternalApps_Start();
extern void *ExternalApps__init();


#endif
