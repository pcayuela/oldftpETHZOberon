/* Ofront 1.1 */

#ifndef Panels__h
#define Panels__h

#include "SYSTEM.h"
#include "Attributes.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Objects.h"
#include "Pictures.h"

typedef
	struct Panels_MethodsDesc *Panels_Methods;

typedef
	struct Panels_MethodsDesc {
		void (*RestoreBackGround)();
		void (*RestoreCaret)();
		void (*RestoreArea)();
		void (*UpdateCaret)();
		void (*TrackCaret)();
		void (*TrackSelection)();
		void (*TrackSelectChild)();
		void (*DragSelection)();
		void (*TrackMouse)();
		void (*ConsumeChar)();
		void (*TranslateToGadget)();
		BOOLEAN (*AcceptChild)();
		void (*InsertChild)();
		void (*InsertFrames)();
		void (*RemoveChild)();
		void (*RemoveFrames)();
	} Panels_MethodsDesc;

typedef
	struct Panels_PanelDesc *Panels_Panel;

typedef
	struct Panels_PanelDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		BOOLEAN focused;
		INTEGER focusx, focusy;
		LONGINT time;
		Display3_Mask back;
		INTEGER rx, ry, rr, rt, borderW;
		Panels_Methods do_;
		SET state0;
		INTEGER grid, col;
		Pictures_Picture pict;
	} Panels_PanelDesc;


extern Panels_Methods Panels_methods;
extern INTEGER Panels_defaultgrid, Panels_newfocusX, Panels_newfocusY;
extern Objects_Object Panels_recall;

extern long *Panels_PanelDesc__typ;
extern long *Panels_MethodsDesc__typ;

extern BOOLEAN Panels_AcceptChild();
extern void Panels_Align();
extern void Panels_BoundingBox();
extern void Panels_ChangeBackdrop();
extern void Panels_ConsumeChar();
extern void Panels_CopyObjList();
extern void Panels_CopyPanel();
extern void Panels_DemoteChild();
extern void Panels_DragSelection();
extern void Panels_DrawHull();
extern void Panels_GetHull();
extern void Panels_GetPanelSelection();
extern void Panels_GetSelection();
extern void Panels_GrowHull();
extern void Panels_InitPanel();
extern void Panels_InsertChild();
extern void Panels_InsertFrames();
extern void Panels_InvalidateMasks();
extern BOOLEAN Panels_IsChild();
extern void Panels_KillChildren();
extern void Panels_LoadPanel();
extern void Panels_Locate();
extern BOOLEAN Panels_NewChildrenOK();
extern void Panels_NewHandler();
extern void Panels_NewPanel();
extern void Panels_NewPictPanel();
extern void Panels_PanelHandler();
extern void Panels_PromoteChild();
extern void Panels_Recall();
extern void Panels_RemoveChild();
extern void Panels_RemoveFrames();
extern void Panels_ResetHull();
extern void Panels_RestoreArea();
extern void Panels_RestoreBackGround();
extern void Panels_RestoreCaret();
extern void Panels_RestoreRegion();
extern void Panels_SelectArea();
extern void Panels_SetChildren();
extern void Panels_StorePanel();
extern Display_Frame Panels_ThisChild();
extern void Panels_ToBack();
extern void Panels_ToChild();
extern void Panels_ToChildren();
extern void Panels_ToFront();
extern void Panels_TrackCaret();
extern void Panels_TrackMouse();
extern void Panels_TrackSelectChild();
extern void Panels_TrackSelection();
extern void Panels_TranslateChildren();
extern void Panels_TranslateToGadget();
extern void Panels_UpdateCaret();
extern void Panels_UpdateMasks();
extern void *Panels__init();


#endif
