/* Ofront 1.1 */

#ifndef Display3__h
#define Display3__h

#include "SYSTEM.h"
#include "Display.h"
#include "Objects.h"

typedef
	void (*Display3_EnumProc)();

typedef
	struct Display3_MaskDesc *Display3_Mask;

typedef
	struct Display3_MaskDesc {
		INTEGER x, y, X, Y, W, H;
		LONGINT _prvt0;
		char _prvt1[12];
	} Display3_MaskDesc;

typedef
	struct Display3_OverlapMsg { /* Display_FrameMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
		Display3_Mask M;
	} Display3_OverlapMsg;

typedef
	struct Display3_UpdateMaskMsg { /* Display_FrameMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
	} Display3_UpdateMaskMsg;


extern LONGINT Display3_selectpat;
extern INTEGER Display3_FG, Display3_BG, Display3_red, Display3_green, Display3_blue, Display3_black, Display3_white, Display3_topC, Display3_bottomC, Display3_upC, Display3_downC, Display3_groupC, Display3_invertC, Display3_textC, Display3_textbackC, Display3_textmode;

extern long *Display3_OverlapMsg__typ;
extern long *Display3_UpdateMaskMsg__typ;
extern long *Display3_MaskDesc__typ;

extern void Display3_Add();
extern void Display3_AdjustMask();
extern void Display3_CenterString();
extern void Display3_Circle();
extern void Display3_Copy();
extern void Display3_CopyMask();
extern void Display3_CopyPattern();
extern void Display3_Dot();
extern void Display3_Ellipse();
extern void Display3_Enum();
extern void Display3_EnumInvert();
extern void Display3_EnumRect();
extern void Display3_FillPattern();
extern void Display3_FilledRect3D();
extern void Display3_Intersect();
extern void Display3_IntersectMasks();
extern void Display3_Line();
extern void Display3_Open();
extern void Display3_Pict();
extern void Display3_Poly();
extern void Display3_Rect();
extern void Display3_Rect3D();
extern BOOLEAN Display3_Rectangular();
extern void Display3_ReplConst();
extern void Display3_ReplPict();
extern void Display3_Shift();
extern void Display3_String();
extern void Display3_StringSize();
extern void Display3_Subtract();
extern void Display3_SubtractMasks();
extern BOOLEAN Display3_Visible();
extern void *Display3__init();


#endif
