/* Ofront 1.1 */

#ifndef TimeStamps__h
#define TimeStamps__h

#include "SYSTEM.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Objects.h"

typedef
	struct TimeStamps_FrameDesc *TimeStamps_Frame;

typedef
	struct TimeStamps_FrameDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		char _prvt0[26];
	} TimeStamps_FrameDesc;



extern long *TimeStamps_FrameDesc__typ;

extern void TimeStamps_Copy();
extern void TimeStamps_Handle();
extern void TimeStamps_New();
extern void *TimeStamps__init();


#endif
