/* Ofront 1.1 */

#ifndef Telnet__h
#define Telnet__h

#include "SYSTEM.h"




extern void Telnet_Clear();
extern void Telnet_Close();
extern void Telnet_Open();
extern void Telnet_OpenLog();
extern void Telnet_Reset();
extern void Telnet_Send();
extern void *Telnet__init();


#endif
