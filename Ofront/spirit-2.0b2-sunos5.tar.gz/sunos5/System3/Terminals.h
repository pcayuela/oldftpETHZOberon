/* Ofront 1.1 */

#ifndef Terminals__h
#define Terminals__h

#include "SYSTEM.h"
#include "Texts.h"

typedef
	struct Terminals_Char {
		CHAR ch;
		SHORTINT attr;
	} Terminals_Char;

struct Terminals__1 {
	INTEGER len;
	Terminals_Char ch[133];
};

typedef
	void (*Terminals_Breaker)();

typedef
	struct Terminals__1 *Terminals_Line;

typedef
	struct Terminals_Location {
		INTEGER line, col;
	} Terminals_Location;

typedef
	void (*Terminals_Notifier)();

typedef
	void (*Terminals_Sender)();

typedef
	struct Terminals_TerminalDesc *Terminals_Terminal;

typedef
	struct Terminals_TerminalDesc {
		SHORTINT attr;
		INTEGER width, height;
		char _prvt0[4];
		Terminals_Location cursor;
		Terminals_Notifier notify;
		Terminals_Line line[59];
		SET flags;
		char _prvt1[435];
		CHAR answerback[32];
		char _prvt2[8];
		Texts_Writer cache;
		Texts_Text text;
		LONGINT pin;
	} Terminals_TerminalDesc;



extern long *Terminals_Char__typ;
extern long *Terminals__1__typ;
extern long *Terminals_Location__typ;
extern long *Terminals_TerminalDesc__typ;

extern void Terminals_Flush();
extern void Terminals_Open();
extern void Terminals_Receive();
extern void Terminals_Reset();
extern void Terminals_Send();
extern void Terminals_SendString();
extern void Terminals_SendText();
extern void *Terminals__init();


#endif
