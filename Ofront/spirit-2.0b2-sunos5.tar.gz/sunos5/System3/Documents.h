/* Ofront 1.1 */

#ifndef Documents__h
#define Documents__h

#include "SYSTEM.h"
#include "Attributes.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Links.h"
#include "Objects.h"

typedef
	struct Documents_DocumentDesc *Documents_Document;

typedef
	struct Documents_DocumentDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		CHAR name[128];
		void (*Load)();
		void (*Store)();
		char _prvt0[4];
	} Documents_DocumentDesc;

typedef
	struct Documents_LocateMsg { /* Display_FrameMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
		Documents_Document doc;
		INTEGER X, Y;
	} Documents_LocateMsg;


extern INTEGER Documents_Id;
extern void (*Documents_historyHook)();

extern long *Documents_DocumentDesc__typ;
extern long *Documents_LocateMsg__typ;

extern void Documents_Copy();
extern void Documents_Handler();
extern void Documents_Init();
extern void Documents_LoadAttachments();
extern Documents_Document Documents_MarkedDoc();
extern void Documents_New();
extern Documents_Document Documents_Open();
extern void Documents_StoreAttachments();
extern void Documents_TitleToFilename();
extern void *Documents__init();


#endif
