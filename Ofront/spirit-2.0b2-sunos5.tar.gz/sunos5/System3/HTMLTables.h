/* Ofront 1.1 */

#ifndef HTMLTables__h
#define HTMLTables__h

#include "SYSTEM.h"




extern void HTMLTables_NewCAPTION();
extern void HTMLTables_NewTABLE();
extern void HTMLTables_NewTD();
extern void HTMLTables_NewTH();
extern void HTMLTables_NewTR();
extern void *HTMLTables__init();


#endif
