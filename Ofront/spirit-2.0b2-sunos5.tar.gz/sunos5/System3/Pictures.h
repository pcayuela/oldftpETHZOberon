/* Ofront 1.1 */

#ifndef Pictures__h
#define Pictures__h

#include "SYSTEM.h"
#include "Display.h"
#include "Objects.h"

typedef
	struct Pictures_PictureDesc *Pictures_Picture;

typedef
	struct Pictures_PictureDesc { /* Objects_ObjDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		INTEGER width, height, depth;
		char _prvt0[778];
	} Pictures_PictureDesc;

typedef
	struct Pictures_UpdateMsg { /* Display_FrameMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
		INTEGER id, u, v, w, h;
		Pictures_Picture pict;
	} Pictures_UpdateMsg;


extern LONGINT Pictures_dots;
extern INTEGER Pictures_colorD;

extern long *Pictures_PictureDesc__typ;
extern long *Pictures_UpdateMsg__typ;

extern LONGINT Pictures_Address();
extern void Pictures_Copy();
extern void Pictures_CopyBlock();
extern void Pictures_CopyPattern();
extern void Pictures_Create();
extern void Pictures_DisplayBlock();
extern void Pictures_Dot();
extern INTEGER Pictures_Get();
extern void Pictures_GetColor();
extern void Pictures_GetRun();
extern void Pictures_Load();
extern void Pictures_NewPicture();
extern void Pictures_Open();
extern void Pictures_Print();
extern void Pictures_ReplConst();
extern void Pictures_ReplPattern();
extern void Pictures_SetColor();
extern void Pictures_Store();
extern void Pictures_Update();
extern void *Pictures__init();


#endif
