/* Ofront 1.1 */

#ifndef Portraits__h
#define Portraits__h

#include "SYSTEM.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Objects.h"

typedef
	struct Portraits_PortraitDesc *Portraits_Portrait;

typedef
	struct Portraits_PortraitDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
	} Portraits_PortraitDesc;



extern long *Portraits_PortraitDesc__typ;

extern void Portraits_Copy();
extern void Portraits_Handle();
extern void Portraits_New();
extern void *Portraits__init();


#endif
