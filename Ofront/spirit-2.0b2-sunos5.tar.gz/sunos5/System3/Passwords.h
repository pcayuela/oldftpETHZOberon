/* Ofront 1.1 */

#ifndef Passwords__h
#define Passwords__h

#include "SYSTEM.h"


extern INTEGER Passwords_res;


extern void Passwords_SearchEntry();
extern void *Passwords__init();


#endif
