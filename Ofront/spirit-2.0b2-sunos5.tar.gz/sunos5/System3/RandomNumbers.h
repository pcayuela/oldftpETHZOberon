/* Ofront 1.1 */

#ifndef RandomNumbers__h
#define RandomNumbers__h

#include "SYSTEM.h"




extern REAL RandomNumbers_Exp();
extern void RandomNumbers_InitSeed();
extern REAL RandomNumbers_Uniform();
extern void *RandomNumbers__init();


#endif
