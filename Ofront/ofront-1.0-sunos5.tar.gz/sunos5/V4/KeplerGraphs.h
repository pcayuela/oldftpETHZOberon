/* Ofront 1.0 */

#ifndef KeplerGraphs__h
#define KeplerGraphs__h

#include "SYSTEM.h"

typedef
	struct KeplerGraphs_ObjectDesc {
		char _prvt0[1];
	} KeplerGraphs_ObjectDesc;

extern void KeplerGraphs_Object_Draw();
extern void KeplerGraphs_Object_Read();
extern void KeplerGraphs_Object_Write();
#define __KeplerGraphs_Object_Draw(self, P) __SEND(__TYPEOF(self), 0, void, (self, P))
#define __KeplerGraphs_Object_Read(self, R, R__typ) __SEND(__TYPEOF(self), 1, void, (self, R, R__typ))
#define __KeplerGraphs_Object_Write(self, R, R__typ) __SEND(__TYPEOF(self), 2, void, (self, R, R__typ))

typedef
	struct KeplerGraphs_StarDesc *KeplerGraphs_Star;

typedef
	struct KeplerGraphs_ConsDesc *KeplerGraphs_Constellation;

typedef
	struct KeplerGraphs_ConsDesc { /* KeplerGraphs_ObjectDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
	} KeplerGraphs_ConsDesc;

extern void KeplerGraphs_Constellation_Read();
extern INTEGER KeplerGraphs_Constellation_State();
extern void KeplerGraphs_Constellation_Write();
#define __KeplerGraphs_Constellation_State(self) __SEND(__TYPEOF(self), 3, INTEGER, (self))

typedef
	struct KeplerGraphs_GraphDesc *KeplerGraphs_Graph;

typedef
	void (*KeplerGraphs_Notifier)();

typedef
	struct KeplerGraphs_GraphDesc { /* KeplerGraphs_ObjectDesc */
		KeplerGraphs_Constellation cons;
		char _prvt0[4];
		KeplerGraphs_Star stars;
		char _prvt1[4];
		LONGINT seltime;
		KeplerGraphs_Notifier notify;
	} KeplerGraphs_GraphDesc;

extern void KeplerGraphs_Graph_All();
extern void KeplerGraphs_Graph_Append();
extern void KeplerGraphs_Graph_CopySelection();
extern void KeplerGraphs_Graph_Delete();
extern void KeplerGraphs_Graph_DeleteSelection();
extern void KeplerGraphs_Graph_Draw();
extern void KeplerGraphs_Graph_FlipSelection();
extern void KeplerGraphs_Graph_Move();
extern void KeplerGraphs_Graph_MoveSelection();
extern void KeplerGraphs_Graph_Read();
extern void KeplerGraphs_Graph_SendToBack();
extern void KeplerGraphs_Graph_Write();
extern void KeplerGraphs_Graph_WriteSel();
#define __KeplerGraphs_Graph_All(G, op) __SEND(__TYPEOF(G), 3, void, (G, op))
#define __KeplerGraphs_Graph_Append(G, o) __SEND(__TYPEOF(G), 4, void, (G, o))
#define __KeplerGraphs_Graph_CopySelection(G, from, dx, dy) __SEND(__TYPEOF(G), 5, void, (G, from, dx, dy))
#define __KeplerGraphs_Graph_Delete(G, o) __SEND(__TYPEOF(G), 6, void, (G, o))
#define __KeplerGraphs_Graph_DeleteSelection(G, minstate) __SEND(__TYPEOF(G), 7, void, (G, minstate))
#define __KeplerGraphs_Graph_FlipSelection(G, p) __SEND(__TYPEOF(G), 8, void, (G, p))
#define __KeplerGraphs_Graph_Move(G, s, dx, dy) __SEND(__TYPEOF(G), 9, void, (G, s, dx, dy))
#define __KeplerGraphs_Graph_MoveSelection(G, dx, dy) __SEND(__TYPEOF(G), 10, void, (G, dx, dy))
#define __KeplerGraphs_Graph_SendToBack(G, o) __SEND(__TYPEOF(G), 11, void, (G, o))
#define __KeplerGraphs_Graph_WriteSel(G, R, R__typ) __SEND(__TYPEOF(G), 12, void, (G, R, R__typ))

typedef
	KeplerGraphs_ObjectDesc *KeplerGraphs_Object;

typedef
	struct KeplerGraphs_PlanetDesc *KeplerGraphs_Planet;

typedef
	struct KeplerGraphs_StarDesc { /* KeplerGraphs_ObjectDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
	} KeplerGraphs_StarDesc;

extern void KeplerGraphs_Star_Draw();
extern void KeplerGraphs_Star_Read();
extern void KeplerGraphs_Star_Write();

typedef
	struct KeplerGraphs_PlanetDesc { /* KeplerGraphs_StarDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
	} KeplerGraphs_PlanetDesc;

extern void KeplerGraphs_Planet_Calc();
extern void KeplerGraphs_Planet_Draw();
extern void KeplerGraphs_Planet_Read();
extern void KeplerGraphs_Planet_Write();
#define __KeplerGraphs_Planet_Calc(self) __SEND(__TYPEOF(self), 3, void, (self))


extern KeplerGraphs_Graph KeplerGraphs_loading;

extern long *KeplerGraphs_ObjectDesc__typ;
extern long *KeplerGraphs_StarDesc__typ;
extern long *KeplerGraphs_ConsDesc__typ;
extern long *KeplerGraphs_PlanetDesc__typ;
extern long *KeplerGraphs_GraphDesc__typ;

extern void KeplerGraphs_GetType();
extern KeplerGraphs_Graph KeplerGraphs_Old();
extern void KeplerGraphs_ReadObj();
extern void KeplerGraphs_Recall();
extern void KeplerGraphs_Reset();
extern void KeplerGraphs_WriteObj();
extern void *KeplerGraphs__init();


#endif
