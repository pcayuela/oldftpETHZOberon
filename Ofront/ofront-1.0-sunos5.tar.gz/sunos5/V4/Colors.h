/* Ofront 1.0 */

#ifndef Colors__h
#define Colors__h

#include "SYSTEM.h"




extern void Colors_Get();
extern void Colors_Load();
extern void Colors_Open();
extern void Colors_OpenHLS();
extern void Colors_OpenRGB();
extern void Colors_Set();
extern void Colors_Store();
extern void *Colors__init();


#endif
