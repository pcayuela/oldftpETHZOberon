/* Ofront 1.0 */

#ifndef MenuElems__h
#define MenuElems__h

#include "SYSTEM.h"




extern void MenuElems_Alloc();
extern void MenuElems_Insert();
extern void MenuElems_Update();
extern void *MenuElems__init();


#endif
