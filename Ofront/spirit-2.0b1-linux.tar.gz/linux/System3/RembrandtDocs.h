/* Ofront 1.0 */

#ifndef RembrandtDocs__h
#define RembrandtDocs__h

#include "SYSTEM.h"
#include "Rembrandt.h"




extern void RembrandtDocs_Dec();
extern void RembrandtDocs_Grid();
extern void RembrandtDocs_Inc();
extern void RembrandtDocs_InitDoc();
extern Rembrandt_Frame RembrandtDocs_MarkedFrame();
extern void RembrandtDocs_NewDoc();
extern void RembrandtDocs_Open();
extern void RembrandtDocs_OpenPict();
extern void *RembrandtDocs__init();


#endif
