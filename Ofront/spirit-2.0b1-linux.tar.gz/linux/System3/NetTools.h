/* Ofront 1.0 */

#ifndef NetTools__h
#define NetTools__h

#include "SYSTEM.h"
#include "Documents.h"
#include "HyperDocs.h"
#include "NetSystem.h"
#include "Objects.h"

typedef
	struct NetTools_ProxyMsg { /* HyperDocs_LinkSchemeMsg */
		LONGINT stamp;
		Objects_Object dlink;
		LONGINT key;
		INTEGER res;
		CHAR host[64];
		Documents_Document D;
		INTEGER port;
	} NetTools_ProxyMsg;

typedef
	void (*NetTools_ReadWriteNotifier)();

typedef
	struct NetTools_SessionDesc *NetTools_Session;

typedef
	struct NetTools_SessionDesc {
		NetSystem_Connection C;
		CHAR reply[1024];
		INTEGER status, res;
	} NetTools_SessionDesc;


extern CHAR NetTools_CRLF[4];
extern LONGINT NetTools_curlen, NetTools_TimeOut;
extern Objects_Object NetTools_progM;
extern CHAR NetTools_ISOToOberon[256], NetTools_OberonToISO[256];

extern long *NetTools_ProxyMsg__typ;
extern long *NetTools_SessionDesc__typ;

extern BOOLEAN NetTools_Connect();
extern BOOLEAN NetTools_Connected();
extern void NetTools_Disconnect();
extern void NetTools_ESC();
extern void NetTools_GetHostPort();
extern LONGINT NetTools_NetLen();
extern void NetTools_ProgMNotify();
extern BOOLEAN NetTools_QueryBool();
extern void NetTools_QueryEMail();
extern void NetTools_ReadData();
extern void NetTools_ReadText();
extern void NetTools_SendString();
extern void NetTools_SendText();
extern void NetTools_SplitHostPort();
extern void NetTools_UnESC();
extern BOOLEAN NetTools_UseProxy();
extern BOOLEAN NetTools_UserBreak();
extern void *NetTools__init();


#endif
