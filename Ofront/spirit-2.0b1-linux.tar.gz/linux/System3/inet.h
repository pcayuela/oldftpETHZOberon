/* Ofront 1.0 */

#ifndef inet__h
#define inet__h

#include "SYSTEM.h"




extern void *inet__init();


#endif
