/* Ofront 1.0 */

#ifndef Books__h
#define Books__h

#include "SYSTEM.h"
#include "Books0.h"
#include "Display.h"
#include "Display3.h"
#include "Documents.h"
#include "Objects.h"
#include "Panels.h"
#include "TextGadgets.h"
#include "TextGadgets0.h"
#include "Texts.h"

typedef
	struct Books_ChainDesc *Books_Chain;

typedef
	struct Books_ChainDesc {
		LONGINT _prvt0;
		char _prvt1[8];
	} Books_ChainDesc;

typedef
	struct Books_PanelDesc *Books_Panel;

typedef
	struct Books_PanelDesc { /* Panels_PanelDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		BOOLEAN focused;
		INTEGER focusx, focusy;
		LONGINT time;
		Display3_Mask back;
		INTEGER rx, ry, rr, rt, borderW;
		Panels_Methods do_;
		SET state0;
		INTEGER grid, col;
		Pictures_Picture pict;
		Documents_Document doc;
		CHAR iconStr[64];
		Books0_TextList texts, cur;
		Texts_Text cmds, notes;
		Books_Chain useStack;
		Books0_ImpList imps;
		SET options;
		char _prvt0[4];
		INTEGER noteH;
	} Books_PanelDesc;

typedef
	struct Books_TGFrameDesc *Books_TGFrame;

typedef
	struct Books_TGFrameDesc { /* TextGadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		INTEGER absX, absY, border;
		void (*ClipMask)();
		SET state0;
		Texts_Text text;
		LONGINT org, time;
		char _prvt0[4];
		INTEGER left, right, top, bottom;
		TextGadgets0_Line trailer;
		TextGadgets0_Methods do_;
		BOOLEAN car;
		TextGadgets0_Loc carpos;
		BOOLEAN sel;
		TextGadgets0_Loc selbeg, selend;
		INTEGER col, invertC;
		char _prvt1[68];
		SET control;
		char _prvt2[4];
		LONGINT lastPos;
		Books_Panel panel;
	} Books_TGFrameDesc;


extern LONGINT Books_newPos, Books_newInd;

extern long *Books_TGFrameDesc__typ;
extern long *Books_PanelDesc__typ;
extern long *Books_ChainDesc__typ;

extern void Books_ChapDown();
extern void Books_ChapUp();
extern void Books_CopyText();
extern LONGINT Books_GetInd();
extern Books0_TextList Books_GetIndex();
extern void Books_GetNote();
extern void Books_GetPanel();
extern void Books_GetText();
extern void Books_GotoText();
extern void Books_History();
extern void Books_NewPanel();
extern void Books_NewText();
extern void Books_Pop();
extern void Books_Push();
extern void Books_ReDisplay();
extern void Books_ResizeControls();
extern void Books_ShowFootNote();
extern void Books_ShowText();
extern void *Books__init();


#endif
