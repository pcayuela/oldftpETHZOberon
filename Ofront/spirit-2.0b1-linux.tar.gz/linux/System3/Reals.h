/* Ofront 1.0 */

#ifndef Reals__h
#define Reals__h

#include "SYSTEM.h"




extern LONGINT Reals_Expo();
extern LONGINT Reals_ExpoL();
extern LONGINT Reals_Int();
extern void Reals_IntL();
extern REAL Reals_Real();
extern LONGREAL Reals_RealL();
extern void Reals_SetExpo();
extern void Reals_SetExpoL();
extern LONGREAL Reals_Ten();
extern void *Reals__init();


#endif
