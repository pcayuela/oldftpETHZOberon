/* Ofront 1.0 */

#ifndef Sisiphus__h
#define Sisiphus__h

#include "SYSTEM.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Objects.h"

struct Sisiphus__2 { /* Gadgets_FrameDesc */
	LONGINT stamp;
	Objects_Object dlink, slink;
	Objects_Library lib;
	INTEGER ref;
	Objects_Handler handle;
	Display_Frame next, dsc;
	INTEGER X, Y, W, H;
	Attributes_Attr attr;
	Links_Link link;
	SET state;
	Display3_Mask mask;
	Objects_Object obj;
	INTEGER col;
};

typedef
	struct Sisiphus__2 *Sisiphus_Frame;



extern long *Sisiphus__2__typ;

extern void Sisiphus_CopyFrame();
extern void Sisiphus_FrameHandler();
extern void Sisiphus_New();
extern void *Sisiphus__init();


#endif
