/* Ofront 1.0 */

#ifndef PSPrinter__h
#define PSPrinter__h

#include "SYSTEM.h"
#include "Printer.h"

typedef
	CHAR PSPrinter_Name[32];

typedef
	struct PSPrinter_PSPrinterDesc *PSPrinter_PSPrinter;

typedef
	struct PSPrinter_PSPrinterDesc { /* Printer_PrinterDesc */
		INTEGER res, Height, Width, Depth, FrameX, FrameY, FrameW, FrameH;
		LONGINT Unit;
		void (*InitMetrics)();
		void (*Open)();
		void (*Close)();
		void (*Page)();
		void (*ReplConst)();
		void (*ReplPattern)();
		void (*Line)();
		void (*Circle)();
		void (*Ellipse)();
		void (*Spline)();
		void (*Picture)();
		void (*UseListFont)();
		void (*String)();
		void (*ContString)();
		void (*UseColor)();
		void (*Escape)();
	} PSPrinter_PSPrinterDesc;



extern long *PSPrinter_PSPrinterDesc__typ;

extern void PSPrinter_Circle();
extern void PSPrinter_Close();
extern void PSPrinter_ContString();
extern void PSPrinter_Ellipse();
extern void PSPrinter_Escape();
extern void PSPrinter_InitMetrics();
extern void PSPrinter_Install();
extern void PSPrinter_Line();
extern Printer_Printer PSPrinter_NewPrinter();
extern void PSPrinter_Open();
extern void PSPrinter_Page();
extern void PSPrinter_Picture();
extern void PSPrinter_ReplConst();
extern void PSPrinter_ReplPattern();
extern void PSPrinter_Spline();
extern void PSPrinter_String();
extern void PSPrinter_UseColor();
extern void PSPrinter_UseListFont();
extern void *PSPrinter__init();


#endif
