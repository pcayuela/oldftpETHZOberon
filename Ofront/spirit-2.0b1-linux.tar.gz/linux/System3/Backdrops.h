/* Ofront 1.0 */

#ifndef Backdrops__h
#define Backdrops__h

#include "SYSTEM.h"




extern void Backdrops_Bows();
extern void Backdrops_Bricks();
extern void Backdrops_Cells();
extern void Backdrops_Clouds();
extern void Backdrops_Coins();
extern void Backdrops_EmptyPicture();
extern void Backdrops_Fractal();
extern void Backdrops_LoadPalette();
extern void Backdrops_Marble();
extern void Backdrops_Molecules();
extern void Backdrops_Plasma();
extern void Backdrops_Preview();
extern void Backdrops_Reduce();
extern void Backdrops_SetBackground();
extern void Backdrops_SetColor();
extern void Backdrops_SetMarbleColor();
extern void Backdrops_SetNoColor();
extern void Backdrops_SetSkyColor();
extern void Backdrops_SetVal();
extern void Backdrops_Spirals();
extern void Backdrops_Surface();
extern void Backdrops_Textils();
extern void Backdrops_Threads();
extern void Backdrops_Trees();
extern void *Backdrops__init();


#endif
