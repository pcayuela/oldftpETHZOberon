/* Ofront 1.0 */

#ifndef PanelDocs__h
#define PanelDocs__h

#include "SYSTEM.h"
#include "Gadgets.h"




extern void PanelDocs_DocHandle();
extern void PanelDocs_InitDoc();
extern void PanelDocs_LoadPanel();
extern void PanelDocs_NewDoc();
extern Gadgets_Frame PanelDocs_OpenPanel();
extern void PanelDocs_StorePanel();
extern void *PanelDocs__init();


#endif
