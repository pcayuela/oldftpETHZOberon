/* Ofront 1.0 */

#ifndef Rembrandt0__h
#define Rembrandt0__h

#include "SYSTEM.h"
#include "Attributes.h"
#include "Display3.h"
#include "Display.h"
#include "Gadgets.h"
#include "Oberon.h"
#include "Objects.h"

struct Rembrandt0__1 {
	INTEGER r, g, b;
};

typedef
	struct Rembrandt0_ColFrameDesc *Rembrandt0_ColFrame;

typedef
	struct Rembrandt0_ColFrameDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		INTEGER col;
	} Rembrandt0_ColFrameDesc;

typedef
	struct Rembrandt0_ColorDesc *Rembrandt0_Color;

typedef
	struct Rembrandt0_ColorDesc { /* Gadgets_ObjDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Attributes_Attr attr;
		Links_Link link;
		INTEGER col;
	} Rembrandt0_ColorDesc;


extern Oberon_Marker Rembrandt0_Cross;
extern Rembrandt0_Color Rembrandt0_color;
extern INTEGER Rembrandt0_noc, Rembrandt0_maxnoc;
extern struct Rembrandt0__1 Rembrandt0_coltable[256];

extern long *Rembrandt0_ColFrameDesc__typ;
extern long *Rembrandt0_ColorDesc__typ;
extern long *Rembrandt0__1__typ;

extern void Rembrandt0_AllocatePictureMem();
extern void Rembrandt0_ChangeColor();
extern void Rembrandt0_CopyBlock();
extern void Rembrandt0_Darken();
extern void Rembrandt0_Floyd();
extern void Rembrandt0_HandleColFrame();
extern void Rembrandt0_HandleColor();
extern void Rembrandt0_InitSeed();
extern void Rembrandt0_Lighten();
extern INTEGER Rembrandt0_NearestColor();
extern void Rembrandt0_NewColFrame();
extern void Rembrandt0_NewColorObj();
extern void Rembrandt0_Reduce();
extern void Rembrandt0_ReplConst();
extern void Rembrandt0_ResetAll();
extern void Rembrandt0_ResetOne();
extern void Rembrandt0_SetColor();
extern REAL Rembrandt0_Uniform();
extern void *Rembrandt0__init();


#endif
