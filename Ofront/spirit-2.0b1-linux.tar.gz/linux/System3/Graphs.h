/* Ofront 1.0 */

#ifndef Graphs__h
#define Graphs__h

#include "SYSTEM.h"
#include "Attributes.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Objects.h"

typedef
	struct Graphs_GraphDesc *Graphs_Graph;

typedef
	struct Graphs_GraphDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		INTEGER col, beg, end;
		REAL x[360];
		REAL y[360];
	} Graphs_GraphDesc;



extern long *Graphs_GraphDesc__typ;

extern void Graphs_Clear();
extern void Graphs_CopyGraph();
extern void Graphs_GraphHandler();
extern void Graphs_NewGraph();
extern void *Graphs__init();


#endif
