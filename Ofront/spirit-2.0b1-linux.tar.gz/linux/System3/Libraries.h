/* Ofront 1.0 */

#ifndef Libraries__h
#define Libraries__h

#include "SYSTEM.h"




extern void Libraries_Free();
extern void Libraries_FreeObj();
extern void Libraries_GC();
extern void Libraries_GetObj();
extern void Libraries_GetView();
extern void Libraries_PutDoc();
extern void Libraries_PutModel();
extern void Libraries_PutObj();
extern void Libraries_ShowLibs();
extern void Libraries_ShowObjs();
extern void Libraries_Store();
extern void *Libraries__init();


#endif
