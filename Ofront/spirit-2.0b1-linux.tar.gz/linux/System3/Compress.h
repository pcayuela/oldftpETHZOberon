/* Ofront 1.0 */

#ifndef Compress__h
#define Compress__h

#include "SYSTEM.h"

typedef
	void (*Compress_EnumProc)();

typedef
	CHAR Compress_Name[32];

typedef
	struct Compress_Header {
		Compress_Name name;
		LONGINT length;
		char _prvt0[4];
		LONGINT date, time;
		char _prvt1[4];
	} Compress_Header;



extern long *Compress_Header__typ;

extern void Compress_Add();
extern void Compress_AddFile();
extern void Compress_CreateArchive();
extern void Compress_Delete();
extern void Compress_DeleteFile();
extern void Compress_Directory();
extern void Compress_Enumerate();
extern void Compress_Extract();
extern void Compress_ExtractAll();
extern void Compress_ExtractAllFiles();
extern void Compress_ExtractFile();
extern void Compress_NewDoc();
extern void Compress_Open();
extern void *Compress__init();


#endif
