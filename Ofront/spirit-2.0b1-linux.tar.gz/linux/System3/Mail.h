/* Ofront 1.0 */

#ifndef Mail__h
#define Mail__h

#include "SYSTEM.h"
#include "NetSystem.h"
#include "NetTools.h"

typedef
	struct Mail_POPSessionDesc *Mail_POPSession;

typedef
	struct Mail_POPSessionDesc { /* NetTools_SessionDesc */
		NetSystem_Connection C;
		CHAR reply[1024];
		INTEGER status, res;
	} Mail_POPSessionDesc;

typedef
	struct Mail_SMTPSessionDesc *Mail_SMTPSession;

typedef
	struct Mail_SMTPSessionDesc { /* NetTools_SessionDesc */
		NetSystem_Connection C;
		CHAR reply[1024];
		INTEGER status, res;
	} Mail_SMTPSessionDesc;


extern CHAR Mail_user[17], Mail_passwd[17];

extern long *Mail_POPSessionDesc__typ;
extern long *Mail_SMTPSessionDesc__typ;

extern void Mail_Cite();
extern void Mail_ClosePOP();
extern void Mail_CloseSMTP();
extern void Mail_Collect();
extern void Mail_CutLines();
extern void Mail_DBDirectory();
extern void Mail_DBShow();
extern void Mail_Delete();
extern void Mail_DeleteM();
extern void Mail_DeleteMail();
extern void Mail_Monitor();
extern void Mail_Mono();
extern void Mail_NewDoc();
extern void Mail_NewMailServerLinkScheme();
extern void Mail_NewMailToLinkScheme();
extern void Mail_NrOfMails();
extern void Mail_OpenPOP();
extern void Mail_OpenSMTP();
extern void Mail_Receive();
extern void Mail_ReceiveHead();
extern void Mail_ReceiveMail();
extern void Mail_Reply();
extern void Mail_Send();
extern void Mail_SendFiles();
extern void Mail_SendMail();
extern void Mail_ServerDirectory();
extern void Mail_ServerShow();
extern void Mail_SetUser();
extern LONGINT Mail_SplitMailServer();
extern LONGINT Mail_SplitMailTo();
extern void Mail_Undelete();
extern void *Mail__init();


#endif
