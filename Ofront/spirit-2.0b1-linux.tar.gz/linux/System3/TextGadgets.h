/* Ofront 1.0 */

#ifndef TextGadgets__h
#define TextGadgets__h

#include "SYSTEM.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Objects.h"
#include "TextGadgets0.h"
#include "Texts.h"

typedef
	struct TextGadgets_ControlDesc *TextGadgets_Control;

typedef
	struct TextGadgets_ControlDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
	} TextGadgets_ControlDesc;

typedef
	struct TextGadgets_FrameDesc *TextGadgets_Frame;

typedef
	struct TextGadgets_FrameDesc { /* TextGadgets0_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		INTEGER absX, absY, border;
		void (*ClipMask)();
		SET state0;
		Texts_Text text;
		LONGINT org, time;
		char _prvt0[4];
		INTEGER left, right, top, bottom;
		TextGadgets0_Line trailer;
		TextGadgets0_Methods do_;
		BOOLEAN car;
		TextGadgets0_Loc carpos;
		BOOLEAN sel;
		TextGadgets0_Loc selbeg, selend;
		INTEGER col, invertC;
		char _prvt1[68];
		SET control;
	} TextGadgets_FrameDesc;

typedef
	struct TextGadgets_StyleDesc *TextGadgets_Style;

typedef
	struct TextGadgets_StyleDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		Texts_Text text;
		SET mode;
		INTEGER leftM, width;
		SHORTINT noTabs;
		INTEGER tab[32];
	} TextGadgets_StyleDesc;


extern TextGadgets0_Methods TextGadgets_methods;
extern Objects_Handler TextGadgets_macroHook, TextGadgets_popupHook;

extern long *TextGadgets_StyleDesc__typ;
extern long *TextGadgets_ControlDesc__typ;
extern long *TextGadgets_FrameDesc__typ;

extern void TextGadgets_ControlHandler();
extern void TextGadgets_CopyControl();
extern void TextGadgets_CopyFrame();
extern void TextGadgets_CopyStyle();
extern TextGadgets_Style TextGadgets_FindStyle();
extern void TextGadgets_FrameHandler();
extern void TextGadgets_Init();
extern void TextGadgets_LocateString();
extern void TextGadgets_New();
extern void TextGadgets_NewControl();
extern void TextGadgets_NewNote();
extern void TextGadgets_NewStyle();
extern void TextGadgets_NewStyleProc();
extern void TextGadgets_StyleHandler();
extern TextGadgets_Style TextGadgets_newStyle();
extern void *TextGadgets__init();


#endif
