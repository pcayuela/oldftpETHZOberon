/* Ofront 1.0 */

#ifndef ProgressMeters__h
#define ProgressMeters__h

#include "SYSTEM.h"
#include "Attributes.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Objects.h"

typedef
	struct ProgressMeters_FrameDesc *ProgressMeters_Frame;

typedef
	struct ProgressMeters_FrameDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		char _prvt0[20];
	} ProgressMeters_FrameDesc;



extern long *ProgressMeters_FrameDesc__typ;

extern void ProgressMeters_CopyFrame();
extern void ProgressMeters_FrameHandler();
extern void ProgressMeters_InitFrame();
extern void ProgressMeters_NewFrame();
extern void *ProgressMeters__init();


#endif
