/* Ofront 1.0 */

#ifndef Inspectors__h
#define Inspectors__h

#include "SYSTEM.h"

typedef
	struct Inspectors_Layout {
		LONGINT _prvt0;
		char _prvt1[16];
	} Inspectors_Layout;



extern long *Inspectors_Layout__typ;

extern void Inspectors_Apply();
extern void Inspectors_ApplyModel();
extern void Inspectors_ApplyXY();
extern void Inspectors_Insert();
extern void Inspectors_Inspect();
extern void Inspectors_InspectModel();
extern void Inspectors_InspectXY();
extern void Inspectors_InspectorPHandler();
extern void Inspectors_NewDetailDoc();
extern void Inspectors_NewDoc();
extern void Inspectors_NewInspectorP();
extern void Inspectors_OpenLayout();
extern void Inspectors_WriteBoolean();
extern void Inspectors_WriteCaption();
extern void Inspectors_WriteCmd();
extern void Inspectors_WriteFrame();
extern void Inspectors_WriteHSpace();
extern void Inspectors_WriteInteger();
extern void Inspectors_WriteLn();
extern void Inspectors_WriteReal();
extern void Inspectors_WriteString();
extern void Inspectors_WriteTab();
extern void Inspectors_WriteVSpace();
extern void *Inspectors__init();


#endif
