/* Ofront 1.0 */

#ifndef Dates__h
#define Dates__h

#include "SYSTEM.h"
#include "Display.h"

typedef
	void (*Dates_AlarmHandler)();

typedef
	struct Dates_TickMsg { /* Display_FrameMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
		INTEGER id;
		LONGINT now;
	} Dates_TickMsg;


extern LONGINT Dates_error;

extern long *Dates_TickMsg__typ;

extern LONGINT Dates_Date();
extern void Dates_DateToString();
extern INTEGER Dates_DayOfWeek();
extern void Dates_DayToString();
extern INTEGER Dates_DaysOfMonth();
extern void Dates_HourMinuteSecond();
extern void Dates_InstallAlarm();
extern void Dates_IntToString();
extern void Dates_MonthToString();
extern LONGINT Dates_Now();
extern void Dates_RemoveAlarm();
extern void Dates_ShowAlarms();
extern LONGINT Dates_StringToDate();
extern LONGINT Dates_StringToInt();
extern LONGINT Dates_StringToTime();
extern LONGINT Dates_Time();
extern void Dates_TimeToString();
extern LONGINT Dates_Today();
extern void Dates_YearMonthDay();
extern void *Dates__init();


#endif
