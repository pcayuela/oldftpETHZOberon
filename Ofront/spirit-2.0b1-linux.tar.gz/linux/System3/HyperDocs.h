/* Ofront 1.0 */

#ifndef HyperDocs__h
#define HyperDocs__h

#include "SYSTEM.h"
#include "Attributes.h"
#include "Documents.h"
#include "Files.h"
#include "Gadgets.h"
#include "Objects.h"
#include "TextGadgets0.h"

typedef
	struct HyperDocs_ContentTypeDesc *HyperDocs_ContentType;

typedef
	struct HyperDocs_ContentTypeDesc {
		CHAR mime[64], prefix[64], extApp[64];
		char _prvt0[32];
		HyperDocs_ContentType next;
	} HyperDocs_ContentTypeDesc;

typedef
	struct HyperDocs_ContextDesc *HyperDocs_Context;

typedef
	struct HyperDocs_NodeDesc *HyperDocs_Node;

typedef
	struct HyperDocs_ContextDesc {
		HyperDocs_Node old, new;
		Documents_Document curDoc;
		BOOLEAN replace, history;
	} HyperDocs_ContextDesc;

typedef
	struct HyperDocs_LinkSchemeMsg { /* Objects_ObjMsg */
		LONGINT stamp;
		Objects_Object dlink;
		LONGINT key;
		INTEGER res;
	} HyperDocs_LinkSchemeMsg;

typedef
	struct HyperDocs_FetchMsg { /* HyperDocs_LinkSchemeMsg */
		LONGINT stamp;
		Objects_Object dlink;
		LONGINT key;
		INTEGER res;
		Files_Rider R;
	} HyperDocs_FetchMsg;

typedef
	struct HyperDocs_InfoMsg { /* HyperDocs_LinkSchemeMsg */
		LONGINT stamp;
		Objects_Object dlink;
		LONGINT key;
		INTEGER res;
		HyperDocs_ContentType type;
		LONGINT size;
	} HyperDocs_InfoMsg;

typedef
	struct HyperDocs_LinkSchemeDesc *HyperDocs_LinkScheme;

typedef
	struct HyperDocs_LinkSchemeDesc { /* Gadgets_ObjDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Attributes_Attr attr;
		Links_Link link;
		CHAR prefix[16];
		char _prvt0[4];
	} HyperDocs_LinkSchemeDesc;

typedef
	struct HyperDocs_NodeDesc {
		char _prvt0[4];
		LONGINT key, org;
		HyperDocs_Node old, prev;
	} HyperDocs_NodeDesc;

typedef
	struct HyperDocs_RegisterLinkMsg { /* HyperDocs_LinkSchemeMsg */
		LONGINT stamp;
		Objects_Object dlink;
		LONGINT key;
		INTEGER res;
		CHAR link[1024];
	} HyperDocs_RegisterLinkMsg;


extern HyperDocs_ContentType HyperDocs_contTypes;
extern HyperDocs_Context HyperDocs_context;
extern INTEGER HyperDocs_linkC;
extern TextGadgets0_Methods HyperDocs_linkMethods;

extern long *HyperDocs_LinkSchemeDesc__typ;
extern long *HyperDocs_LinkSchemeMsg__typ;
extern long *HyperDocs_RegisterLinkMsg__typ;
extern long *HyperDocs_InfoMsg__typ;
extern long *HyperDocs_FetchMsg__typ;
extern long *HyperDocs_ContentTypeDesc__typ;
extern long *HyperDocs_NodeDesc__typ;
extern long *HyperDocs_ContextDesc__typ;

extern void HyperDocs_Back();
extern LONGINT HyperDocs_BuildKey();
extern void HyperDocs_CacheDoc();
extern void HyperDocs_ClearCache();
extern void HyperDocs_ClearMemCache();
extern void HyperDocs_DocNameByKey();
extern void HyperDocs_FollowKeyLink();
extern void HyperDocs_FollowLink();
extern Documents_Document HyperDocs_GetCachedDoc();
extern HyperDocs_ContentType HyperDocs_GetContentType();
extern Objects_Object HyperDocs_LinkControl();
extern void HyperDocs_LinkNodeToDoc();
extern HyperDocs_LinkScheme HyperDocs_LinkSchemeByKey();
extern HyperDocs_LinkScheme HyperDocs_LinkSchemeByPrefix();
extern void HyperDocs_LinkSchemeHandler();
extern void HyperDocs_LoadLink();
extern void HyperDocs_LoadMimeDoc();
extern void HyperDocs_MakeTempName();
extern void HyperDocs_NewDoc();
extern void HyperDocs_NewLinkControl();
extern void HyperDocs_NewLinkScheme();
extern HyperDocs_Node HyperDocs_NodeByDoc();
extern LONGINT HyperDocs_RegisterLink();
extern void HyperDocs_Remember();
extern void HyperDocs_RememberOrg();
extern void HyperDocs_ReplaceCurDoc();
extern void HyperDocs_RetrieveLink();
extern LONGINT HyperDocs_SplitFileAdr();
extern void HyperDocs_StoreLink();
extern void HyperDocs_TempDocName();
extern void *HyperDocs__init();


#endif
