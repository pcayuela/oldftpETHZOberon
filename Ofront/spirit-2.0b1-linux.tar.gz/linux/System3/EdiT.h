/* Ofront 1.0 */

#ifndef EdiT__h
#define EdiT__h

#include "SYSTEM.h"




extern void EdiT_Grep();
extern void EdiT_Handle();
extern void EdiT_LocateLine();
extern void EdiT_Match();
extern void EdiT_Open();
extern void EdiT_Replace();
extern void EdiT_ReplaceAll();
extern void EdiT_Search();
extern void EdiT_SearchDiff();
extern void EdiT_Show();
extern void EdiT_StoreAscii();
extern void *EdiT__init();


#endif
