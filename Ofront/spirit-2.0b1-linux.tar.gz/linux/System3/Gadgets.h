/* Ofront 1.0 */

#ifndef Gadgets__h
#define Gadgets__h

#include "SYSTEM.h"
#include "Attributes.h"
#include "Display.h"
#include "Display3.h"
#include "Links.h"
#include "Objects.h"

typedef
	struct Gadgets_CmdMsg { /* Objects_ObjMsg */
		LONGINT stamp;
		Objects_Object dlink;
		CHAR cmd[128];
		INTEGER res;
	} Gadgets_CmdMsg;

typedef
	struct Gadgets_FrameDesc *Gadgets_Frame;

typedef
	struct Gadgets_FrameDesc { /* Display_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
	} Gadgets_FrameDesc;

typedef
	void (*Gadgets_MakeMaskHandler)();

typedef
	struct Gadgets_ObjDesc { /* Objects_ObjDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Attributes_Attr attr;
		Links_Link link;
	} Gadgets_ObjDesc;

typedef
	Gadgets_ObjDesc *Gadgets_Object;

typedef
	struct Gadgets_PriorityMsg { /* Display_FrameMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
		INTEGER id;
		BOOLEAN passon;
	} Gadgets_PriorityMsg;

typedef
	struct Gadgets_UpdateMsg { /* Display_FrameMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
		Objects_Object obj;
	} Gadgets_UpdateMsg;

typedef
	struct Gadgets_ViewDesc *Gadgets_View;

typedef
	struct Gadgets_ViewDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		INTEGER absX, absY, border;
		void (*ClipMask)();
	} Gadgets_ViewDesc;


extern Objects_Handler Gadgets_framehandle, Gadgets_objecthandle;
extern Gadgets_MakeMaskHandler Gadgets_MakeMask, Gadgets_MakePrinterMask;
extern Objects_Object Gadgets_context, Gadgets_executorObj, Gadgets_senderObj, Gadgets_receiverObj;

extern long *Gadgets_UpdateMsg__typ;
extern long *Gadgets_PriorityMsg__typ;
extern long *Gadgets_CmdMsg__typ;
extern long *Gadgets_ObjDesc__typ;
extern long *Gadgets_FrameDesc__typ;
extern long *Gadgets_ViewDesc__typ;

extern void Gadgets_AddAlias();
extern void Gadgets_Adjust();
extern void Gadgets_BindObj();
extern void Gadgets_Change();
extern void Gadgets_ChangeAttr();
extern void Gadgets_Copy();
extern void Gadgets_CopyFrame();
extern void Gadgets_CopyObject();
extern Objects_Object Gadgets_CopyPtr();
extern Objects_Object Gadgets_CreateObject();
extern Display_Frame Gadgets_CreateViewModel();
extern void Gadgets_Execute();
extern void Gadgets_ExecuteAttr();
extern Objects_Object Gadgets_FindObj();
extern Objects_Object Gadgets_FindPublicObj();
extern void Gadgets_GetAlias();
extern void Gadgets_GetObjName();
extern void Gadgets_GetSelection();
extern BOOLEAN Gadgets_InActiveArea();
extern void Gadgets_Insert();
extern void Gadgets_Integrate();
extern BOOLEAN Gadgets_IsLocked();
extern void Gadgets_Link();
extern void Gadgets_MoveFrame();
extern void Gadgets_NameObj();
extern void Gadgets_ReadRef();
extern BOOLEAN Gadgets_Recursive();
extern void Gadgets_Send();
extern void Gadgets_Set();
extern void Gadgets_SizeFrame();
extern void Gadgets_ThisFrame();
extern void Gadgets_TrackFrame();
extern void Gadgets_Update();
extern void Gadgets_WriteRef();
extern void *Gadgets__init();


#endif
