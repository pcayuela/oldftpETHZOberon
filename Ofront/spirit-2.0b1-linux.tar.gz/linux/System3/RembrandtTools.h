/* Ofront 1.0 */

#ifndef RembrandtTools__h
#define RembrandtTools__h

#include "SYSTEM.h"




extern void RembrandtTools_Assign();
extern void RembrandtTools_Circles();
extern void RembrandtTools_Clone();
extern void RembrandtTools_Erease();
extern void RembrandtTools_Fill();
extern void RembrandtTools_Filled();
extern void RembrandtTools_FlipH();
extern void RembrandtTools_FlipV();
extern BOOLEAN RembrandtTools_GetFilled();
extern INTEGER RembrandtTools_GetWidth();
extern void RembrandtTools_Lines();
extern void RembrandtTools_LoadColors();
extern void RembrandtTools_MakeIcon();
extern void RembrandtTools_PickColor();
extern void RembrandtTools_Points();
extern void RembrandtTools_Rectangles();
extern void RembrandtTools_Reduce();
extern void RembrandtTools_Rotate();
extern void RembrandtTools_Scale();
extern void RembrandtTools_SetDouble();
extern void RembrandtTools_SetFilled();
extern void RembrandtTools_SetSmearSpeed();
extern void RembrandtTools_SetSpraySpeed();
extern void RembrandtTools_SetSymmDeg45();
extern void RembrandtTools_SetSymmXaxis();
extern void RembrandtTools_SetSymmYaxis();
extern void RembrandtTools_SetWidth();
extern void RembrandtTools_Smear();
extern void RembrandtTools_SpecialDel();
extern void RembrandtTools_Spray();
extern void RembrandtTools_StoreColors();
extern void RembrandtTools_Width();
extern void *RembrandtTools__init();


#endif
