/* Ofront 1.0 */

#ifndef MenuViewers__h
#define MenuViewers__h

#include "SYSTEM.h"
#include "Display.h"
#include "Objects.h"
#include "Viewers.h"

typedef
	struct MenuViewers_ViewerDesc *MenuViewers_Viewer;

typedef
	struct MenuViewers_ViewerDesc { /* Viewers_ViewerDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		INTEGER state;
		INTEGER menuH;
	} MenuViewers_ViewerDesc;



extern long *MenuViewers_ViewerDesc__typ;

extern void MenuViewers_GetName();
extern void MenuViewers_Handle();
extern MenuViewers_Viewer MenuViewers_New();
extern void *MenuViewers__init();


#endif
