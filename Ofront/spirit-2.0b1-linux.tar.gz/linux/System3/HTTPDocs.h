/* Ofront 1.0 */

#ifndef HTTPDocs__h
#define HTTPDocs__h

#include "SYSTEM.h"
#include "Attributes.h"
#include "Documents.h"
#include "HyperDocs.h"
#include "Objects.h"
#include "Texts.h"

typedef
	struct HTTPDocs_BaseURL {
		LONGINT key, dockey;
		CHAR prefix[16];
		CHAR host[64];
		CHAR path[256];
		INTEGER port;
	} HTTPDocs_BaseURL;

typedef
	struct HTTPDocs_ContextDesc *HTTPDocs_Context;

typedef
	struct HTTPDocs_ContextDesc { /* HyperDocs_ContextDesc */
		HyperDocs_Node old, new;
		Documents_Document curDoc;
		BOOLEAN replace, history;
		Texts_Text query;
		CHAR method[8];
		CHAR referer[128];
		CHAR user[64], passwd[64];
	} HTTPDocs_ContextDesc;

typedef
	struct HTTPDocs_EntryDesc *HTTPDocs_Entry;

typedef
	struct HTTPDocs_ObjListDesc *HTTPDocs_ObjList;

typedef
	struct HTTPDocs_EntryDesc {
		LONGINT basekey, key, pos;
		Attributes_Attr attrs;
		Texts_Text text;
		HTTPDocs_ObjList ol;
		Objects_Object obj;
		HTTPDocs_Entry next, same;
		char _prvt0[8];
	} HTTPDocs_EntryDesc;

typedef
	struct HTTPDocs_ObjListDesc {
		Objects_Object obj;
		HTTPDocs_ObjList next;
	} HTTPDocs_ObjListDesc;

typedef
	struct HTTPDocs_ProxyDesc *HTTPDocs_Proxy;

typedef
	struct HTTPDocs_ProxyDesc {
		INTEGER _prvt0;
		char _prvt1[64];
	} HTTPDocs_ProxyDesc;


extern void (*HTTPDocs_parseHtml)();
extern HTTPDocs_Proxy HTTPDocs_httpProxy;
extern HyperDocs_Node HTTPDocs_curNode;
extern HTTPDocs_Entry HTTPDocs_entries;
extern INTEGER HTTPDocs_linkC, HTTPDocs_textC, HTTPDocs_textbackC;

extern long *HTTPDocs_ObjListDesc__typ;
extern long *HTTPDocs_EntryDesc__typ;
extern long *HTTPDocs_ContextDesc__typ;
extern long *HTTPDocs_ProxyDesc__typ;
extern long *HTTPDocs_BaseURL__typ;

extern BOOLEAN HTTPDocs_LinkPrefix();
extern void HTTPDocs_LoadDoc();
extern void HTTPDocs_LoadXBMDoc();
extern LONGINT HTTPDocs_MakeURL();
extern void HTTPDocs_NewDoc();
extern void HTTPDocs_NewLinkScheme();
extern LONGINT HTTPDocs_RegisterHTTPAdr();
extern void HTTPDocs_RequestDoc();
extern LONGINT HTTPDocs_SplitHTTPAdr();
extern void HTTPDocs_Stop();
extern void HTTPDocs_Wait();
extern void *HTTPDocs__init();


#endif
