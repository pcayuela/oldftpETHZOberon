/* Ofront 1.0 */

#ifndef FTPTool__h
#define FTPTool__h

#include "SYSTEM.h"




extern void FTPTool_ChangeDir();
extern void FTPTool_Close();
extern void FTPTool_CompactDir();
extern void FTPTool_CurDir();
extern void FTPTool_DeleteFiles();
extern void FTPTool_Dir();
extern void FTPTool_GetFiles();
extern void FTPTool_GetTexts();
extern void FTPTool_MakeDir();
extern void FTPTool_Open();
extern void FTPTool_PutFiles();
extern void FTPTool_PutTexts();
extern void FTPTool_RmDir();
extern void *FTPTool__init();


#endif
