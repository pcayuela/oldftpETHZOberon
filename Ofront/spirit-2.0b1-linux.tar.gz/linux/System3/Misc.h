/* Ofront 1.0 */

#ifndef Misc__h
#define Misc__h

#include "SYSTEM.h"
#include "Objects.h"


extern INTEGER Misc_docW, Misc_docH;


extern void Misc_CopyPublicObj();
extern void Misc_FindBeg();
extern BOOLEAN Misc_GetBoolAttr();
extern LONGINT Misc_GetIntAttr();
extern Objects_Object Misc_GetLink();
extern LONGREAL Misc_GetLongRealAttr();
extern void Misc_GetMarked();
extern void Misc_GetStrAttr();
extern BOOLEAN Misc_HasAttr();
extern BOOLEAN Misc_InMenu();
extern void Misc_PackDateTime();
extern void Misc_SetBoolAttr();
extern void Misc_SetIntAttr();
extern void Misc_SetLink();
extern void Misc_SetLongRealAttr();
extern void Misc_SetStrAttr();
extern void Misc_UnpackDateTime();
extern void Misc_WriteObj();
extern void *Misc__init();


#endif
