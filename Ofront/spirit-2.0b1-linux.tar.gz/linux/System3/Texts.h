/* Ofront 1.0 */

#ifndef Texts__h
#define Texts__h

#include "SYSTEM.h"
#include "Display.h"
#include "Objects.h"

typedef
	struct Texts_BufDesc {
		LONGINT len;
		char _prvt0[8];
	} Texts_BufDesc;

typedef
	Texts_BufDesc *Texts_Buffer;

typedef
	struct Texts_Finder {
		BOOLEAN eot;
		LONGINT pos;
		char _prvt0[4];
	} Texts_Finder;

typedef
	struct Texts_Reader {
		LONGINT _prvt0;
		char _prvt1[28];
		BOOLEAN eot;
		Objects_Library lib;
		SHORTINT col, voff;
	} Texts_Reader;

typedef
	struct Texts_Scanner { /* Texts_Reader */
		LONGINT _prvt0;
		char _prvt1[28];
		BOOLEAN eot;
		Objects_Library lib;
		SHORTINT col, voff;
		CHAR nextCh;
		INTEGER line, class;
		LONGINT i;
		REAL x;
		LONGREAL y;
		CHAR c;
		SHORTINT len;
		CHAR s[128];
	} Texts_Scanner;

typedef
	struct Texts_TextDesc *Texts_Text;

typedef
	struct Texts_TextDesc { /* Objects_ObjDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		LONGINT len;
		Objects_Library obs;
		char _prvt0[12];
	} Texts_TextDesc;

typedef
	struct Texts_UpdateMsg { /* Display_FrameMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
		Texts_Text text;
		LONGINT beg, end, len;
	} Texts_UpdateMsg;

typedef
	struct Texts_Writer {
		char _prvt0[20];
		Texts_Buffer buf;
		Objects_Library lib;
		SHORTINT col, voff;
	} Texts_Writer;


extern CHAR Texts_TextBlockId;

extern long *Texts_TextDesc__typ;
extern long *Texts_UpdateMsg__typ;
extern long *Texts_Finder__typ;
extern long *Texts_Reader__typ;
extern long *Texts_Scanner__typ;
extern long *Texts_BufDesc__typ;
extern long *Texts_Writer__typ;

extern void Texts_Append();
extern void Texts_ChangeLooks();
extern void Texts_Copy();
extern void Texts_Delete();
extern void Texts_FindObj();
extern void Texts_Handle();
extern void Texts_Insert();
extern void Texts_Load();
extern void Texts_New();
extern void Texts_Open();
extern void Texts_OpenBuf();
extern void Texts_OpenFinder();
extern void Texts_OpenReader();
extern void Texts_OpenScanner();
extern void Texts_OpenWriter();
extern LONGINT Texts_Pos();
extern void Texts_Read();
extern void Texts_Recall();
extern void Texts_Replace();
extern void Texts_Save();
extern void Texts_Scan();
extern void Texts_SetColor();
extern void Texts_SetFont();
extern void Texts_SetOffset();
extern void Texts_Store();
extern void Texts_Write();
extern void Texts_WriteDate();
extern void Texts_WriteHex();
extern void Texts_WriteInt();
extern void Texts_WriteLn();
extern void Texts_WriteLongReal();
extern void Texts_WriteLongRealFix();
extern void Texts_WriteLongRealHex();
extern void Texts_WriteReal();
extern void Texts_WriteRealFix();
extern void Texts_WriteRealHex();
extern void Texts_WriteString();
extern void *Texts__init();


#endif
