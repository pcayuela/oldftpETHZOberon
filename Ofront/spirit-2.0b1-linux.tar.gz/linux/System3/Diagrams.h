/* Ofront 1.0 */

#ifndef Diagrams__h
#define Diagrams__h

#include "SYSTEM.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Objects.h"

typedef
	struct Diagrams_FrameDesc *Diagrams_Frame;

typedef
	struct Diagrams_FrameDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		INTEGER col;
	} Diagrams_FrameDesc;

typedef
	struct Diagrams_UpdateMsg { /* Display_FrameMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
		INTEGER n;
	} Diagrams_UpdateMsg;



extern long *Diagrams_FrameDesc__typ;
extern long *Diagrams_UpdateMsg__typ;

extern void Diagrams_CopyFrame();
extern void Diagrams_FrameHandler();
extern void Diagrams_NewFrame();
extern void *Diagrams__init();


#endif
