/* Ofront 1.0 */

#ifndef Strings__h
#define Strings__h

#include "SYSTEM.h"




extern void Strings_Append();
extern void Strings_AppendCh();
extern void Strings_BoolToStr();
extern BOOLEAN Strings_CAPCompare();
extern BOOLEAN Strings_CAPPrefix();
extern void Strings_ChangeSuffix();
extern void Strings_DateToStr();
extern void Strings_GetPar();
extern void Strings_GetSuffix();
extern void Strings_IntToStr();
extern BOOLEAN Strings_IsDigit();
extern BOOLEAN Strings_IsHexDigit();
extern BOOLEAN Strings_IsLetter();
extern LONGINT Strings_Length();
extern void Strings_Lower();
extern CHAR Strings_LowerCh();
extern BOOLEAN Strings_Prefix();
extern void Strings_Search();
extern void Strings_StrToBool();
extern void Strings_StrToInt();
extern void Strings_StrToIntPos();
extern void Strings_TimeToStr();
extern void Strings_Upper();
extern CHAR Strings_UpperCh();
extern void *Strings__init();


#endif
