/* Ofront 1.0 */

#ifndef MathL__h
#define MathL__h

#include "SYSTEM.h"




extern LONGREAL MathL_arctan();
extern LONGREAL MathL_cos();
extern LONGREAL MathL_exp();
extern LONGREAL MathL_ln();
extern LONGREAL MathL_sin();
extern LONGREAL MathL_sqrt();
extern void *MathL__init();


#endif
