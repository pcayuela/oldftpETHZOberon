/* Ofront 1.0 */

#ifndef Objects__h
#define Objects__h

#include "SYSTEM.h"
#include "Files.h"

typedef
	struct Objects_ObjDesc *Objects_Object;

typedef
	struct Objects_ObjMsg {
		LONGINT stamp;
		Objects_Object dlink;
	} Objects_ObjMsg;

typedef
	CHAR Objects_Name[32];

typedef
	struct Objects_AttrMsg { /* Objects_ObjMsg */
		LONGINT stamp;
		Objects_Object dlink;
		INTEGER id;
		void (*Enum)();
		Objects_Name name;
		INTEGER res, class;
		LONGINT i;
		REAL x;
		LONGREAL y;
		CHAR c;
		BOOLEAN b;
		CHAR s[64];
	} Objects_AttrMsg;

typedef
	struct Objects_LibDesc *Objects_Library;

typedef
	struct Objects_BindMsg { /* Objects_ObjMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Objects_Library lib;
	} Objects_BindMsg;

typedef
	struct Objects_CopyMsg { /* Objects_ObjMsg */
		LONGINT stamp;
		Objects_Object dlink;
		INTEGER id;
		Objects_Object obj;
	} Objects_CopyMsg;

typedef
	struct Objects_Dictionary {
		LONGINT _prvt0;
		char _prvt1[4];
	} Objects_Dictionary;

typedef
	struct Objects_DummyDesc *Objects_Dummy;

typedef
	void (*Objects_Handler)();

typedef
	struct Objects_ObjDesc {
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
	} Objects_ObjDesc;

typedef
	struct Objects_DummyDesc { /* Objects_ObjDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Objects_Name GName;
	} Objects_DummyDesc;

typedef
	void (*Objects_EnumProc)();

typedef
	struct Objects_FileMsg { /* Objects_ObjMsg */
		LONGINT stamp;
		Objects_Object dlink;
		INTEGER id;
		LONGINT len;
		Files_Rider R;
	} Objects_FileMsg;

typedef
	struct Objects_FindMsg { /* Objects_ObjMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Objects_Name name;
		Objects_Object obj;
	} Objects_FindMsg;

typedef
	struct Objects_IndexDesc *Objects_Index;

typedef
	struct Objects_IndexDesc {
		char _prvt0[1];
	} Objects_IndexDesc;

typedef
	struct Objects_LibDesc {
		char _prvt0[4];
		Objects_Index ind;
		Objects_Name name;
		Objects_Dictionary dict;
		INTEGER maxref;
		void (*GenRef)();
		void (*GetObj)();
		void (*PutObj)();
		void (*FreeObj)();
		void (*Load)();
		void (*Store)();
	} Objects_LibDesc;

typedef
	struct Objects_LinkMsg { /* Objects_ObjMsg */
		LONGINT stamp;
		Objects_Object dlink;
		INTEGER id;
		void (*Enum)();
		Objects_Name name;
		INTEGER res;
		Objects_Object obj;
	} Objects_LinkMsg;

typedef
	Objects_Library (*Objects_NewProc)();


extern CHAR Objects_LibBlockId;
extern Objects_Object Objects_NewObj;

extern long *Objects_ObjMsg__typ;
extern long *Objects_ObjDesc__typ;
extern long *Objects_AttrMsg__typ;
extern long *Objects_LinkMsg__typ;
extern long *Objects_CopyMsg__typ;
extern long *Objects_BindMsg__typ;
extern long *Objects_FileMsg__typ;
extern long *Objects_FindMsg__typ;
extern long *Objects_DummyDesc__typ;
extern long *Objects_IndexDesc__typ;
extern long *Objects_Dictionary__typ;
extern long *Objects_LibDesc__typ;

extern void Objects_Enumerate();
extern void Objects_FreeLibrary();
extern void Objects_GetKey();
extern void Objects_GetName();
extern void Objects_GetRef();
extern void Objects_LoadLibrary();
extern void Objects_OpenLibrary();
extern void Objects_PutName();
extern void Objects_Register();
extern void Objects_Stamp();
extern void Objects_StoreLibrary();
extern Objects_Library Objects_ThisLibrary();
extern void *Objects__init();


#endif
