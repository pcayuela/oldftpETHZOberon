/* Ofront 1.0 */

#ifndef Links__h
#define Links__h

#include "SYSTEM.h"
#include "Objects.h"

typedef
	struct Links_LinkDesc *Links_Link;

typedef
	struct Links_LinkDesc {
		Links_Link next;
		CHAR name[32];
		Objects_Object obj;
	} Links_LinkDesc;



extern long *Links_LinkDesc__typ;

extern void Links_BindLinks();
extern void Links_Broadcast();
extern void Links_CopyLinks();
extern void Links_DeleteLink();
extern Links_Link Links_FindLink();
extern void Links_HandleLinkMsg();
extern void Links_InsertLink();
extern void Links_LoadLinks();
extern void Links_StoreLinks();
extern void *Links__init();


#endif
