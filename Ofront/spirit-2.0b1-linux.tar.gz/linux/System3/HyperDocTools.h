/* Ofront 1.0 */

#ifndef HyperDocTools__h
#define HyperDocTools__h

#include "SYSTEM.h"




extern void HyperDocTools_Apply();
extern void HyperDocTools_Fetch();
extern void HyperDocTools_History();
extern void HyperDocTools_Inspect();
extern void HyperDocTools_LinkIndex();
extern void HyperDocTools_LinkInfo();
extern void HyperDocTools_NewDocSession();
extern void HyperDocTools_StoreSession();
extern void *HyperDocTools__init();


#endif
