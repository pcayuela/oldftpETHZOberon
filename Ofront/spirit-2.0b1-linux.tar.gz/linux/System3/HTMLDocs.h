/* Ofront 1.0 */

#ifndef HTMLDocs__h
#define HTMLDocs__h

#include "SYSTEM.h"
#include "Attributes.h"
#include "Display.h"
#include "Display3.h"
#include "HTTPDocs.h"
#include "Lists.h"
#include "Objects.h"
#include "TextGadgets.h"
#include "Texts.h"

typedef
	struct HTMLDocs_ExtTagDesc *HTMLDocs_ExtTag;

typedef
	void (*HTMLDocs_TagHandler)();

typedef
	struct HTMLDocs_ExtTagDesc {
		char _prvt0[32];
		HTMLDocs_TagHandler handle;
		void (*start)(), (*stop)();
		char _prvt1[4];
	} HTMLDocs_ExtTagDesc;

typedef
	struct HTMLDocs_FormDesc *HTMLDocs_Form;

typedef
	struct HTMLDocs_FormDesc { /* TextGadgets_ControlDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		char _prvt0[4];
	} HTMLDocs_FormDesc;

typedef
	struct HTMLDocs_ItemDesc *HTMLDocs_Item;

typedef
	struct HTMLDocs_ItemDesc { /* Lists_ItemDesc */
		BOOLEAN sel;
		CHAR s[64];
		Lists_Item prev, next;
		CHAR value[64];
		BOOLEAN oldSel, hasVal;
	} HTMLDocs_ItemDesc;

typedef
	struct HTMLDocs_Reader {
		LONGINT _prvt0;
		char _prvt1[1084];
		BOOLEAN end;
	} HTMLDocs_Reader;

typedef
	struct HTMLDocs_TagAttrDesc *HTMLDocs_TagAttr;

typedef
	struct HTMLDocs_TagAttrDesc {
		LONGINT _prvt0;
		char _prvt1[28];
		CHAR value[512];
		char _prvt2[4];
	} HTMLDocs_TagAttrDesc;


extern Texts_Writer HTMLDocs_W, HTMLDocs_Wr;
extern CHAR HTMLDocs_ch;
extern BOOLEAN HTMLDocs_body;
extern HTTPDocs_BaseURL HTMLDocs_base;
extern Texts_Text HTMLDocs_OutT;
extern HTMLDocs_Form HTMLDocs_curForm;
extern INTEGER HTMLDocs_lines;
extern HTMLDocs_ExtTag HTMLDocs_newTag;

extern long *HTMLDocs_TagAttrDesc__typ;
extern long *HTMLDocs_FormDesc__typ;
extern long *HTMLDocs_ItemDesc__typ;
extern long *HTMLDocs_Reader__typ;
extern long *HTMLDocs_ExtTagDesc__typ;

extern void HTMLDocs_BindObj();
extern void HTMLDocs_CloseA();
extern void HTMLDocs_ExecAttrs();
extern void HTMLDocs_ExecNext();
extern Objects_Object HTMLDocs_FindLibObj();
extern void HTMLDocs_FixWorkers();
extern BOOLEAN HTMLDocs_GetAttr();
extern void HTMLDocs_GetAttrs();
extern Objects_Object HTMLDocs_GetImage();
extern Texts_Text HTMLDocs_GetText();
extern void HTMLDocs_LoadAllIcons();
extern void HTMLDocs_LoadIMG();
extern void HTMLDocs_LoadOBJ();
extern void HTMLDocs_Locate();
extern void HTMLDocs_NewDoc();
extern void HTMLDocs_NewForm();
extern void HTMLDocs_NewIcon();
extern void HTMLDocs_Read();
extern void HTMLDocs_ReadCharRef();
extern void HTMLDocs_Reset();
extern HTMLDocs_TagAttr HTMLDocs_SearchAttr();
extern void HTMLDocs_ShowHTML();
extern void HTMLDocs_SkipBlank();
extern void HTMLDocs_StoreValue();
extern void HTMLDocs_SubmitQuery();
extern void HTMLDocs_Write();
extern void HTMLDocs_WriteObj();
extern void HTMLDocs_WriteString();
extern void *HTMLDocs__init();


#endif
