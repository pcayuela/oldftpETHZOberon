/* Ofront 1.0 */

#ifndef TerminalGadgets__h
#define TerminalGadgets__h

#include "SYSTEM.h"
#include "Display.h"
#include "Display3.h"
#include "Fonts.h"
#include "Gadgets.h"
#include "Objects.h"
#include "Terminals.h"

typedef
	struct TerminalGadgets_FrameDesc *TerminalGadgets_Frame;

typedef
	struct TerminalGadgets_FrameDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		Terminals_Terminal text;
		Fonts_Font fnt;
		INTEGER cursorState, charW, lineH, textcol, profile;
		BOOLEAN hasSel;
		LONGINT selTime;
		Terminals_Location selFrom, selTo;
		char _prvt0[2];
	} TerminalGadgets_FrameDesc;

typedef
	struct TerminalGadgets_UpdateMsg { /* Display_FrameMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
		char _prvt0[20];
	} TerminalGadgets_UpdateMsg;



extern long *TerminalGadgets_FrameDesc__typ;
extern long *TerminalGadgets_UpdateMsg__typ;

extern void TerminalGadgets_Call();
extern void TerminalGadgets_Copy();
extern void TerminalGadgets_CopyFrame();
extern void TerminalGadgets_Edit();
extern void TerminalGadgets_GetSelection();
extern void TerminalGadgets_Handle();
extern void TerminalGadgets_Modify();
extern void TerminalGadgets_Neutralize();
extern void TerminalGadgets_NotifyDisplay();
extern void TerminalGadgets_Open();
extern void TerminalGadgets_TrackSelection();
extern void TerminalGadgets_TrackWord();
extern void TerminalGadgets_Update();
extern void *TerminalGadgets__init();


#endif
