/* Ofront 1.0 */

#ifndef Gages__h
#define Gages__h

#include "SYSTEM.h"
#include "Attributes.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Objects.h"

typedef
	struct Gages_FrameDesc *Gages_Frame;

typedef
	struct Gages_FrameDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		LONGINT points[128];
		char _prvt0[14];
	} Gages_FrameDesc;



extern long *Gages_FrameDesc__typ;

extern void Gages_NewDrv();
extern void Gages_NewFrame();
extern void Gages_NewLap();
extern void Gages_NewLoad();
extern void Gages_NewMem();
extern void *Gages__init();


#endif
