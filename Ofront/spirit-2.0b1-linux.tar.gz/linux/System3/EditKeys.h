/* Ofront 1.0 */

#ifndef EditKeys__h
#define EditKeys__h

#include "SYSTEM.h"




extern void EditKeys_Definitions();
extern void EditKeys_GetKeyCode();
extern void EditKeys_Handle();
extern void EditKeys_Install();
extern void EditKeys_Read();
extern void EditKeys_Reset();
extern void *EditKeys__init();


#endif
