/* Ofront 1.0 */

#ifndef ColorTools__h
#define ColorTools__h

#include "SYSTEM.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Objects.h"

typedef
	struct ColorTools_ColorPickerDesc *ColorTools_ColorPicker;

typedef
	struct ColorTools_ColorPickerDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		CHAR cmd[64];
		INTEGER colors[256];
		INTEGER col;
	} ColorTools_ColorPickerDesc;



extern long *ColorTools_ColorPickerDesc__typ;

extern void ColorTools_ChangeColor();
extern void ColorTools_ColorPickerHandler();
extern void ColorTools_CopyColorPicker();
extern void ColorTools_InitColorPicker();
extern void ColorTools_NewColorPicker();
extern void *ColorTools__init();


#endif
