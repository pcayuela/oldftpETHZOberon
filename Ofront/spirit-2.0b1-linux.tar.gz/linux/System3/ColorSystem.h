/* Ofront 1.0 */

#ifndef ColorSystem__h
#define ColorSystem__h

#include "SYSTEM.h"
#include "Attributes.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Objects.h"

typedef
	struct ColorSystem_ColorDesc *ColorSystem_Color;

typedef
	struct ColorSystem_ColorDesc { /* Gadgets_ObjDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Attributes_Attr attr;
		Links_Link link;
		INTEGER col;
	} ColorSystem_ColorDesc;

typedef
	struct ColorSystem_FrameDesc *ColorSystem_Frame;

typedef
	struct ColorSystem_FrameDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		INTEGER col;
	} ColorSystem_FrameDesc;



extern long *ColorSystem_ColorDesc__typ;
extern long *ColorSystem_FrameDesc__typ;

extern void ColorSystem_Copy();
extern void ColorSystem_HandleFrame();
extern void ColorSystem_HandleObj();
extern void ColorSystem_LoadColors();
extern void ColorSystem_NewFrame();
extern void ColorSystem_NewObj();
extern void ColorSystem_StoreColors();
extern void *ColorSystem__init();


#endif
