/* Ofront 1.0 */

#ifndef Views__h
#define Views__h

#include "SYSTEM.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Objects.h"

typedef
	struct Views_Block {
		Display3_Mask mask;
		char _prvt0[12];
	} Views_Block;

typedef
	struct Views_ViewDesc *Views_View;

typedef
	struct Views_ViewDesc { /* Gadgets_ViewDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		INTEGER absX, absY, border;
		void (*ClipMask)();
		INTEGER vx, vy;
		LONGINT time;
	} Views_ViewDesc;


extern INTEGER Views_background;

extern long *Views_ViewDesc__typ;
extern long *Views_Block__typ;

extern void Views_CopyView();
extern void Views_GetBlock();
extern void Views_InitView();
extern void Views_NewView();
extern void Views_RestoreBlock();
extern Views_View Views_ViewOf();
extern void *Views__init();


#endif
