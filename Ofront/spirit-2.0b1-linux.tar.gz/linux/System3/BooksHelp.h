/* Ofront 1.0 */

#ifndef BooksHelp__h
#define BooksHelp__h

#include "SYSTEM.h"
#include "Oberon.h"


extern Oberon_Marker BooksHelp_MagnifyHand;


extern void BooksHelp_NewIcon();
extern void BooksHelp_SetTutorial();
extern void *BooksHelp__init();


#endif
