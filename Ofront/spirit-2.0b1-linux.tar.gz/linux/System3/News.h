/* Ofront 1.0 */

#ifndef News__h
#define News__h

#include "SYSTEM.h"
#include "NetSystem.h"
#include "NetTools.h"

typedef
	struct News_Date {
		INTEGER day, month, year;
	} News_Date;

typedef
	struct News_SessionDesc *News_Session;

typedef
	struct News_SessionDesc { /* NetTools_SessionDesc */
		NetSystem_Connection C;
		CHAR reply[1024];
		INTEGER status, res;
	} News_SessionDesc;

typedef
	struct News_Time {
		INTEGER hour, min, sec;
	} News_Time;



extern long *News_Date__typ;
extern long *News_Time__typ;
extern long *News_SessionDesc__typ;

extern void News_AllGroups();
extern void News_ArticleByMsgId();
extern void News_ArticleByNr();
extern void News_Articles();
extern void News_Close();
extern void News_ConvertDate();
extern void News_ConvertTime();
extern void News_NewDoc();
extern void News_NewGroups();
extern void News_NewNNTPLinkScheme();
extern void News_NewNewsLinkScheme();
extern void News_Open();
extern void News_Reply();
extern void News_Send();
extern void News_SendArticle();
extern void News_ShowAllGroups();
extern void News_ShowNewGroups();
extern void News_StoreInitText();
extern void News_SubGroup();
extern void News_SubscribedGroups();
extern void News_UnsubGroup();
extern void *News__init();


#endif
