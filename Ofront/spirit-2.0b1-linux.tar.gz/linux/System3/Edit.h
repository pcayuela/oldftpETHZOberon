/* Ofront 1.0 */

#ifndef Edit__h
#define Edit__h

#include "SYSTEM.h"




extern void Edit_ChangeColor();
extern void Edit_ChangeFont();
extern void Edit_Clear();
extern void Edit_CopyFont();
extern void Edit_Error();
extern void Edit_Locate();
extern void Edit_Open();
extern void Edit_Print();
extern void Edit_Recall();
extern void Edit_Replace();
extern void Edit_ReplaceAll();
extern void Edit_Search();
extern void Edit_Show();
extern void Edit_Store();
extern void *Edit__init();


#endif
