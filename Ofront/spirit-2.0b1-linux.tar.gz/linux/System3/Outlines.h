/* Ofront 1.0 */

#ifndef Outlines__h
#define Outlines__h

#include "SYSTEM.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Objects.h"
#include "Texts.h"

typedef
	struct Outlines_OutlineDesc *Outlines_Outline;

typedef
	struct Outlines_OutlineDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		INTEGER fstate;
		LONGINT len;
		Texts_Buffer buf;
	} Outlines_OutlineDesc;



extern long *Outlines_OutlineDesc__typ;

extern void Outlines_Collapse();
extern void Outlines_CollapseAll();
extern void Outlines_CopyOutline();
extern void Outlines_Expand();
extern void Outlines_ExpandAll();
extern void Outlines_Insert();
extern Outlines_Outline Outlines_MakeOutline();
extern void Outlines_New();
extern void Outlines_NewOutline();
extern void Outlines_OutlineHandler();
extern void Outlines_Search();
extern void *Outlines__init();


#endif
