/* Ofront 1.0 */

#ifndef Find__h
#define Find__h

#include "SYSTEM.h"




extern void Find_All();
extern void Find_Domain();
extern void Find_Search();
extern void Find_SetDetOutput();
extern void Find_SetScanSub();
extern void *Find__init();


#endif
