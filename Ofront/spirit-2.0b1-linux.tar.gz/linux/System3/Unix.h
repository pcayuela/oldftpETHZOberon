/* Ofront 1.0 */

#ifndef Unix__h
#define Unix__h

#include "SYSTEM.h"

typedef
	struct Unix_Dirent {
		LONGINT _prvt0;
		char _prvt1[262];
	} Unix_Dirent;

typedef
	SET Unix_FdSet[8];

typedef
	struct Unix_Hostent *Unix_HostEntry;

typedef
	struct Unix_Hostent {
		LONGINT name, aliases, addrtype, length, addrlist;
	} Unix_Hostent;

typedef
	struct Unix_Iovec {
		LONGINT base, len;
	} Unix_Iovec;

typedef
	struct Unix_Timeval {
		LONGINT sec, usec;
	} Unix_Timeval;

typedef
	struct Unix_Itimerval {
		Unix_Timeval interval, value;
	} Unix_Itimerval;

typedef
	struct Unix_JmpBuf {
		LONGINT bx, si, di, bp, sp, pc, maskWasSaved, savedMask;
	} Unix_JmpBuf;

typedef
	CHAR *Unix_Name;

typedef
	struct Unix_Pollfd {
		LONGINT fd;
		INTEGER events, revents;
	} Unix_Pollfd;

typedef
	struct Unix_Rusage {
		Unix_Timeval utime, stime;
		LONGINT maxrss, ixrss, idrss, isrss, minflt, majflt, nswap, inblock, oublock, msgsnd, msgrcv, nsignals, nvcsw, nivcsw;
	} Unix_Rusage;

typedef
	struct Unix_SigContext {
		char _prvt0[1];
	} Unix_SigContext;

typedef
	Unix_SigContext *Unix_SigCtxPtr;

typedef
	void (*Unix_SignalHandler)();

typedef
	struct Unix_Sockaddr {
		INTEGER family, port;
		LONGINT internetAddr;
		CHAR pad[8];
	} Unix_Sockaddr;

typedef
	LONGINT Unix_SocketPair[2];

typedef
	struct Unix_Status {
		INTEGER dev;
		LONGINT ino;
		INTEGER mode, nlink, uid, gid, rdev;
		LONGINT size, blksize, blocks, atime, unused1, mtime, unused2, ctime, unused3, unused4, unused5;
	} Unix_Status;

typedef
	struct Unix_Timezone {
		LONGINT minuteswest, dsttime;
	} Unix_Timezone;



extern long *Unix_JmpBuf__typ;
extern long *Unix_Status__typ;
extern long *Unix_Timeval__typ;
extern long *Unix_Timezone__typ;
extern long *Unix_Itimerval__typ;
extern long *Unix_SigContext__typ;
extern long *Unix_Dirent__typ;
extern long *Unix_Rusage__typ;
extern long *Unix_Iovec__typ;
extern long *Unix_Pollfd__typ;
extern long *Unix_Sockaddr__typ;
extern long *Unix_Hostent__typ;

extern LONGINT Unix_errno();
extern void *Unix__init();

#define Unix_Accept(socket, addr, addr__typ, addrlen)	accept(socket, addr, addrlen)
#define Unix_Bind(socket, name, namelen)	bind(socket, &(name), namelen)
#define Unix_Chdir(path, path__len)	chdir(path)
#define Unix_Chmod(path, path__len, mode)	chmod(path, mode)
#define Unix_Close(fd)	close(fd)
#define Unix_Connect(socket, name, namelen)	connect(socket, &(name), namelen)
#define Unix_Dup(fd)	dup(fd)
#define Unix_Dup2(fd1, fd2)	dup(fd1, fd2)
#define Unix_Exit(n)	exit(n)
#define Unix_Fchmod(fd, mode)	fchmod(fd, mode)
#define Unix_Flock(fd, operation)	flock(fd, operation)
#define Unix_Fstat(fd, statbuf, statbuf__typ)	_fxstat(1, fd, statbuf)
#define Unix_Fsync(fd)	fsync(fd)
#define Unix_Ftruncate(fd, length)	ftruncate(fd, length)
#define Unix_Getegid()	getegid()
#define Unix_Geteuid()	geteuid()
#define Unix_Getgid()	getgid()
#define Unix_Gethostbyname(name, name__len)	(Unix_HostEntry)gethostbyname(name)
#define Unix_Gethostname(name, name__len)	gethostname(name, name__len)
#define Unix_Getpid()	getpid()
#define Unix_Getsockname(socket, name, name__typ, namelen)	getsockname(socket, name, namelen)
#define Unix_Gettimeofday(tv, tv__typ, tz, tz__typ)	gettimeofday(tv, tz)
#define Unix_Getuid()	getuid()
#define Unix_Ioctl(fd, request, arg)	ioctl(fd, request, arg)
#define Unix_Kill(pid, sig)	kill(pid, sig)
#define Unix_Listen(socket, backlog)	listen(socket, backlog)
#define Unix_Lseek(fd, offset, origin)	lseek(fd, offset, origin)
#define Unix_Open(name, name__len, flag, mode)	open(name, flag, mode)
#define Unix_Read(fd, buf, nbyte)	read(fd, buf, nbyte)
#define Unix_ReadBlk(fd, buf, buf__len)	read(fd, buf, buf__len)
#define Unix_Readblk(fd, buf, buf__len, len)	read(fd, buf, len)
#define Unix_Recv(socket, bufadr, buflen, flags)	recv(socket, bufadr, buflen, flags)
#define Unix_Rename(old, old__len, new, new__len)	rename(old, new)
#define Unix_Select(width, readfds, writefds, exceptfds, timeout, timeout__typ)	select(width, readfds, writefds, exceptfds, timeout)
#define Unix_Send(socket, bufadr, buflen, flags)	send(socket, bufadr, buflen, flags)
#define Unix_Sigsetmask(mask)	sigsetmask(mask)
#define Unix_Socket(af, type, protocol)	socket(af, type, protocol)
#define Unix_Stat(name, name__len, statbuf, statbuf__typ)	_xstat(1, name, statbuf)
#define Unix_Unlink(name, name__len)	unlink(name)
#define Unix_Write(fd, buf, nbyte)	write(fd, buf, nbyte)
#define Unix_WriteBlk(fd, buf, buf__len)	write(fd, buf, buf__len)

#endif
