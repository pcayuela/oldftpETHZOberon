/* Ofront 1.0 */

#ifndef NoteBooks__h
#define NoteBooks__h

#include "SYSTEM.h"
#include "Attributes.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Objects.h"

typedef
	struct NoteBooks_NoteBookDesc *NoteBooks_NoteBook;

typedef
	struct NoteBooks_NoteBookDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		Display_Frame pages;
		LONGINT time;
	} NoteBooks_NoteBookDesc;



extern long *NoteBooks_NoteBookDesc__typ;

extern void NoteBooks_Copy();
extern void NoteBooks_Handler();
extern void NoteBooks_InitNoteBook();
extern void NoteBooks_New();
extern void NoteBooks_Show();
extern void *NoteBooks__init();


#endif
