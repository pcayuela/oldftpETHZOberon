/* Ofront 1.0 */

#ifndef Icons__h
#define Icons__h

#include "SYSTEM.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Objects.h"

typedef
	struct Icons_IconDesc *Icons_Icon;

typedef
	struct Icons_IconDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		CHAR caption[64];
		char _prvt0[2];
	} Icons_IconDesc;

typedef
	struct Icons_IconizerDesc *Icons_Iconizer;

typedef
	struct Icons_IconizerDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		Display_Frame closedF, openF;
		BOOLEAN closed, popup, pin, sel, pos;
		char _prvt0[9];
	} Icons_IconizerDesc;

typedef
	struct Icons_ViewDesc *Icons_View;

typedef
	struct Icons_ViewDesc { /* Gadgets_ViewDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		INTEGER absX, absY, border;
		void (*ClipMask)();
	} Icons_ViewDesc;



extern long *Icons_ViewDesc__typ;
extern long *Icons_IconDesc__typ;
extern long *Icons_IconizerDesc__typ;

extern void Icons_Break();
extern void Icons_CopyIcon();
extern void Icons_CopyIconizer();
extern void Icons_CopyView();
extern void Icons_CreateIcon();
extern void Icons_Flip();
extern void Icons_IconHandler();
extern void Icons_IconizerHandler();
extern void Icons_InitView();
extern void Icons_InsertIcon();
extern void Icons_MakeIcon();
extern void Icons_MakeIconizer();
extern void Icons_NewIcon();
extern void Icons_NewIconizer();
extern void Icons_NewView();
extern void Icons_ViewHandle();
extern Icons_View Icons_ViewOf();
extern void *Icons__init();


#endif
