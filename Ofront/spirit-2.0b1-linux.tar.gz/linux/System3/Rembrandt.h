/* Ofront 1.0 */

#ifndef Rembrandt__h
#define Rembrandt__h

#include "SYSTEM.h"
#include "Attributes.h"
#include "Display3.h"
#include "Display.h"
#include "Gadgets.h"
#include "Oberon.h"
#include "Objects.h"
#include "Pictures.h"

typedef
	void (*Rembrandt_TrackMMProc)();

struct Rembrandt__4 {
	SHORTINT id;
	Rembrandt_TrackMMProc track;
};

typedef
	struct Rembrandt_FrameDesc *Rembrandt_Frame;

typedef
	struct Rembrandt_FrameDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		Pictures_Picture pict;
		char _prvt0[26];
		INTEGER selection, sx, sy, sw, sh;
		char _prvt1[20];
		BOOLEAN car;
		INTEGER cx, cy;
		char _prvt2[14];
		INTEGER col;
	} Rembrandt_FrameDesc;


extern Rembrandt_TrackMMProc Rembrandt_trackMM;
extern struct Rembrandt__4 Rembrandt_trackSelMM;
extern Oberon_Marker Rembrandt_cursor;
extern INTEGER Rembrandt_selcolor;

extern long *Rembrandt_FrameDesc__typ;
extern long *Rembrandt__4__typ;

extern void Rembrandt_BlockSelect();
extern void Rembrandt_ClipboardCopy();
extern void Rembrandt_ClipboardCut();
extern void Rembrandt_ClipboardPaste();
extern void Rembrandt_ClipboardStamp();
extern void Rembrandt_Copy();
extern void Rembrandt_CopyPalette();
extern void Rembrandt_DisplayLine();
extern void Rembrandt_DisplayText();
extern void Rembrandt_FrameAttributes();
extern void Rembrandt_FreehandSelect();
extern void Rembrandt_GetBorder();
extern void Rembrandt_GetGrid();
extern void Rembrandt_GetLocked();
extern void Rembrandt_GetSelectedPict();
extern void Rembrandt_GetSelectioninFrame();
extern void Rembrandt_GetZoom();
extern void Rembrandt_Handle();
extern void Rembrandt_Insert();
extern BOOLEAN Rembrandt_InsidePict();
extern void Rembrandt_MakePattern();
extern void Rembrandt_Move();
extern void Rembrandt_New();
extern void Rembrandt_NewP();
extern void Rembrandt_ObjectSelect();
extern void Rembrandt_PicttoScreen();
extern void Rembrandt_RemoveSelection();
extern void Rembrandt_RestorePict();
extern void Rembrandt_SavePicture();
extern void Rembrandt_ScreentoPict();
extern void Rembrandt_SetBorder();
extern void Rembrandt_SetGrid();
extern void Rembrandt_SetLocked();
extern void Rembrandt_SetZoom();
extern void Rembrandt_SizeRect();
extern void Rembrandt_TrackSelection();
extern void Rembrandt_Undo();
extern void *Rembrandt__init();


#endif
