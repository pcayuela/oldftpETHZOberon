/* Ofront 1.0 */

#ifndef Display__h
#define Display__h

#include "SYSTEM.h"
#include "Objects.h"

typedef
	struct Display_FrameDesc *Display_Frame;

typedef
	struct Display_FrameMsg { /* Objects_ObjMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
	} Display_FrameMsg;

typedef
	struct Display_ConsumeMsg { /* Display_FrameMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
		INTEGER id, u, v;
		Objects_Object obj;
	} Display_ConsumeMsg;

typedef
	struct Display_ControlMsg { /* Display_FrameMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
		INTEGER id;
	} Display_ControlMsg;

typedef
	struct Display_DisplayMsg { /* Display_FrameMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
		INTEGER id, u, v, w, h;
	} Display_DisplayMsg;

typedef
	struct Display_FrameDesc { /* Objects_ObjDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
	} Display_FrameDesc;

typedef
	struct Display_LocateMsg { /* Display_FrameMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
		Display_Frame loc;
		INTEGER X, Y, u, v;
	} Display_LocateMsg;

typedef
	struct Display_ModifyMsg { /* Display_FrameMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
		INTEGER id, mode, dX, dY, dW, dH, X, Y, W, H;
	} Display_ModifyMsg;

typedef
	void (*Display_MsgProc)();

typedef
	struct Display_PrintMsg { /* Display_FrameMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
		INTEGER id, pageno;
	} Display_PrintMsg;

typedef
	struct Display_SelectMsg { /* Display_FrameMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
		INTEGER id;
		LONGINT time;
		Display_Frame sel;
		Objects_Object obj;
	} Display_SelectMsg;


extern LONGINT Display_Unit;
extern INTEGER Display_Left, Display_ColLeft, Display_Bottom, Display_UBottom, Display_Width, Display_Height;
extern LONGINT Display_arrow, Display_star, Display_cross, Display_downArrow, Display_hook, Display_grey0, Display_grey1, Display_grey2, Display_ticks, Display_solid;
extern Display_MsgProc Display_Broadcast;

extern long *Display_FrameDesc__typ;
extern long *Display_FrameMsg__typ;
extern long *Display_ControlMsg__typ;
extern long *Display_ModifyMsg__typ;
extern long *Display_DisplayMsg__typ;
extern long *Display_PrintMsg__typ;
extern long *Display_LocateMsg__typ;
extern long *Display_SelectMsg__typ;
extern long *Display_ConsumeMsg__typ;

extern void Display_AdjustClip();
extern void Display_CopyBlock();
extern void Display_CopyPattern();
extern INTEGER Display_Depth();
extern void Display_Dot();
extern void Display_FillPattern();
extern void Display_GetClip();
extern void Display_GetColor();
extern void Display_GetDim();
extern LONGINT Display_Map();
extern LONGINT Display_NewPattern();
extern void Display_ReplConst();
extern void Display_ReplPattern();
extern void Display_ResetClip();
extern void Display_SetClip();
extern void Display_SetColor();
extern void Display_SetMode();
extern void *Display__init();


#endif
