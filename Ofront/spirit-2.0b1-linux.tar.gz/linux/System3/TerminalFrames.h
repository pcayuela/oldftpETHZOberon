/* Ofront 1.0 */

#ifndef TerminalFrames__h
#define TerminalFrames__h

#include "SYSTEM.h"
#include "Display.h"
#include "Fonts.h"
#include "Objects.h"
#include "Terminals.h"

typedef
	struct TerminalFrames_FrameDesc *TerminalFrames_Frame;

typedef
	struct TerminalFrames_FrameDesc { /* Display_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Terminals_Terminal text;
		Fonts_Font fnt;
		INTEGER cursorState, charW, lineH;
		BOOLEAN hasSel;
		LONGINT selTime;
		Terminals_Location selFrom, selTo;
	} TerminalFrames_FrameDesc;

typedef
	struct TerminalFrames_UpdateMsg { /* Display_FrameMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
		char _prvt0[20];
	} TerminalFrames_UpdateMsg;



extern long *TerminalFrames_FrameDesc__typ;
extern long *TerminalFrames_UpdateMsg__typ;

extern void TerminalFrames_Call();
extern void TerminalFrames_Copy();
extern void TerminalFrames_Edit();
extern void TerminalFrames_GetSelection();
extern void TerminalFrames_Handle();
extern void TerminalFrames_Modify();
extern void TerminalFrames_Neutralize();
extern TerminalFrames_Frame TerminalFrames_New();
extern void TerminalFrames_NotifyDisplay();
extern void TerminalFrames_Open();
extern void TerminalFrames_RemoveSelection();
extern void TerminalFrames_SetCursor();
extern void TerminalFrames_SetSelection();
extern void TerminalFrames_TrackSelection();
extern void TerminalFrames_TrackWord();
extern void TerminalFrames_Update();
extern void *TerminalFrames__init();


#endif
