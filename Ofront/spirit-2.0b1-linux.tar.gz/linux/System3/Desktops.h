/* Ofront 1.0 */

#ifndef Desktops__h
#define Desktops__h

#include "SYSTEM.h"
#include "Attributes.h"
#include "Display.h"
#include "Display3.h"
#include "Documents.h"
#include "Gadgets.h"
#include "Objects.h"
#include "Viewers.h"

typedef
	struct Desktops_DocGadgetDesc *Desktops_DocGadget;

typedef
	struct Desktops_DocGadgetDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		char _prvt0[4];
	} Desktops_DocGadgetDesc;

typedef
	struct Desktops_DocViewerDesc *Desktops_DocViewer;

typedef
	struct Desktops_DocViewerDesc { /* Viewers_ViewerDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		INTEGER state;
		INTEGER menuH;
		char _prvt0[4];
	} Desktops_DocViewerDesc;


extern INTEGER Desktops_menuH;

extern long *Desktops_DocGadgetDesc__typ;
extern long *Desktops_DocViewerDesc__typ;

extern void Desktops_ChangeBackdrop();
extern void Desktops_Close();
extern void Desktops_CloseDoc();
extern void Desktops_CopyDocGadget();
extern Documents_Document Desktops_CurDoc();
extern Display_Frame Desktops_CurMenu();
extern void Desktops_DocGadgetHandler();
extern void Desktops_DocViewerHandle();
extern void Desktops_Grow();
extern BOOLEAN Desktops_HasMenu();
extern void Desktops_Init();
extern void Desktops_InsertDoc();
extern Gadgets_Frame Desktops_Main();
extern Gadgets_Frame Desktops_Menu();
extern void Desktops_NewDocGadget();
extern Desktops_DocViewer Desktops_NewDocViewer();
extern Display_Frame Desktops_NewMenu();
extern Display_Frame Desktops_NewMenuFrame();
extern void Desktops_Open();
extern void Desktops_OpenDoc();
extern void Desktops_PrintDoc();
extern void Desktops_Recall();
extern void Desktops_ReplaceCurrentDoc();
extern void Desktops_ReplaceDoc();
extern void Desktops_ShowDoc();
extern void Desktops_Store();
extern void Desktops_StoreDoc();
extern void *Desktops__init();


#endif
