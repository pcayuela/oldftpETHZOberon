/* Ofront 1.0 */

#ifndef HTML__h
#define HTML__h

#include "SYSTEM.h"




extern void HTML_Compile();
extern void HTML_Show();
extern void *HTML__init();


#endif
