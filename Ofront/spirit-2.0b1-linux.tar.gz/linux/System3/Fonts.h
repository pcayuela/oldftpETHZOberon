/* Ofront 1.0 */

#ifndef Fonts__h
#define Fonts__h

#include "SYSTEM.h"
#include "Objects.h"

typedef
	struct Fonts_CharDesc *Fonts_Char;

typedef
	struct Fonts_CharDesc { /* Objects_ObjDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		INTEGER dx, x, y, w, h;
		LONGINT pat;
	} Fonts_CharDesc;

typedef
	struct Fonts_FontDesc *Fonts_Font;

typedef
	struct Fonts_FontDesc { /* Objects_LibDesc */
		char _prvt0[4];
		Objects_Index ind;
		Objects_Name name;
		Objects_Dictionary dict;
		INTEGER maxref;
		void (*GenRef)();
		void (*GetObj)();
		void (*PutObj)();
		void (*FreeObj)();
		void (*Load)();
		void (*Store)();
		SHORTINT type;
		INTEGER height, minX, maxX, minY, maxY;
	} Fonts_FontDesc;


extern CHAR Fonts_FontId;
extern Fonts_Font Fonts_Default;

extern long *Fonts_CharDesc__typ;
extern long *Fonts_FontDesc__typ;

extern void Fonts_GetChar();
extern Fonts_Font Fonts_This();
extern void *Fonts__init();


#endif
