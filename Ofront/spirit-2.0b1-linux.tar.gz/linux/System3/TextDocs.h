/* Ofront 1.0 */

#ifndef TextDocs__h
#define TextDocs__h

#include "SYSTEM.h"
#include "Texts.h"




extern void TextDocs_ChangeColor();
extern void TextDocs_ChangeFont();
extern void TextDocs_ChangeOffset();
extern void TextDocs_Clear();
extern void TextDocs_Controls();
extern void TextDocs_DocHandler();
extern Texts_Text TextDocs_GetText();
extern void TextDocs_InitDoc();
extern void TextDocs_InitLog();
extern void TextDocs_Locate();
extern void TextDocs_LogHandler();
extern void TextDocs_NewDoc();
extern void TextDocs_NewLog();
extern void TextDocs_Recall();
extern void TextDocs_Replace();
extern void TextDocs_ReplaceAll();
extern void TextDocs_Search();
extern void TextDocs_SearchColor();
extern void TextDocs_SearchDiff();
extern void TextDocs_SetCaret();
extern void TextDocs_Show();
extern void TextDocs_ShowText();
extern void *TextDocs__init();


#endif
