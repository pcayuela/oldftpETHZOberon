/* Ofront 1.1 */

#ifndef JPEG__h
#define JPEG__h

#include "SYSTEM.h"




extern void JPEG_Decode();
extern void JPEG_NewDoc();
extern void JPEG_Pict();
extern void *JPEG__init();


#endif
