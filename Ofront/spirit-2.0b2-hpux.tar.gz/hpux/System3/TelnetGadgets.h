/* Ofront 1.1 */

#ifndef TelnetGadgets__h
#define TelnetGadgets__h

#include "SYSTEM.h"




extern void TelnetGadgets_Close();
extern void TelnetGadgets_CloseCon();
extern void TelnetGadgets_NewDoc();
extern void TelnetGadgets_NewFrame();
extern void TelnetGadgets_NewLinkScheme();
extern void TelnetGadgets_Open();
extern void TelnetGadgets_OpenLog();
extern void TelnetGadgets_Reset();
extern void TelnetGadgets_Send();
extern void *TelnetGadgets__init();


#endif
