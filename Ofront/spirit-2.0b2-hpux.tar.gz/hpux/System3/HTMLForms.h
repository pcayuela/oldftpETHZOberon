/* Ofront 1.1 */

#ifndef HTMLForms__h
#define HTMLForms__h

#include "SYSTEM.h"




extern void HTMLForms_NewFORM();
extern void HTMLForms_NewINPUT();
extern void HTMLForms_NewOPTION();
extern void HTMLForms_NewSELECT();
extern void HTMLForms_NewTEXTAREA();
extern void *HTMLForms__init();


#endif
