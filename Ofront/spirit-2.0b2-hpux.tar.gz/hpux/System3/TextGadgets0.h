/* Ofront 1.1 */

#ifndef TextGadgets0__h
#define TextGadgets0__h

#include "SYSTEM.h"
#include "Attributes.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Objects.h"
#include "Texts.h"

typedef
	struct TextGadgets0_BackRd {
		Texts_Text text;
		char _prvt0[137];
	} TextGadgets0_BackRd;

typedef
	struct TextGadgets0_BoxDesc *TextGadgets0_Box;

typedef
	struct TextGadgets0_BoxDesc {
		TextGadgets0_Box next;
		LONGINT org;
		Display_Frame f;
		INTEGER x, voff;
	} TextGadgets0_BoxDesc;

typedef
	struct TextGadgets0_DrawDesc {
		LONGINT _prvt0;
		char _prvt1[64];
	} TextGadgets0_DrawDesc;

typedef
	struct TextGadgets0_FrameDesc *TextGadgets0_Frame;

typedef
	struct TextGadgets0_LineDesc *TextGadgets0_Line;

typedef
	struct TextGadgets0_MethodBlock *TextGadgets0_Methods;

typedef
	struct TextGadgets0_Loc {
		LONGINT org, pos;
		INTEGER x, y, dx;
		TextGadgets0_Line line;
	} TextGadgets0_Loc;

typedef
	struct TextGadgets0_FrameDesc { /* Gadgets_ViewDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		INTEGER absX, absY, border;
		void (*ClipMask)();
		SET state0;
		Texts_Text text;
		LONGINT org, time;
		char _prvt0[4];
		INTEGER left, right, top, bottom;
		TextGadgets0_Line trailer;
		TextGadgets0_Methods do_;
		BOOLEAN car;
		TextGadgets0_Loc carpos;
		BOOLEAN sel;
		TextGadgets0_Loc selbeg, selend;
		INTEGER col, invertC;
		char _prvt1[68];
	} TextGadgets0_FrameDesc;

typedef
	struct TextGadgets0_LineDesc {
		TextGadgets0_Line next;
		INTEGER base, w, h, dsr, asr, left, right;
		LONGINT len;
		TextGadgets0_Box box;
		BOOLEAN eot;
		LONGINT draw;
		INTEGER spaces;
		Objects_Object obj;
		LONGINT extra;
	} TextGadgets0_LineDesc;

typedef
	struct TextGadgets0_MethodBlock {
		void (*Background)();
		void (*Format)();
		BOOLEAN (*InSync)();
		void (*Display)();
		void (*LocateChar)();
		void (*LocatePos)();
		void (*LocateString)();
		void (*PrintFormat)();
		void (*Print)();
		void (*Call)();
	} TextGadgets0_MethodBlock;


extern INTEGER TextGadgets0_PrintertopY, TextGadgets0_PrinterbotY, TextGadgets0_PrinterleftX, TextGadgets0_PagenoX, TextGadgets0_HeaderY;

extern long *TextGadgets0_BackRd__typ;
extern long *TextGadgets0_Loc__typ;
extern long *TextGadgets0_BoxDesc__typ;
extern long *TextGadgets0_LineDesc__typ;
extern long *TextGadgets0_MethodBlock__typ;
extern long *TextGadgets0_DrawDesc__typ;
extern long *TextGadgets0_FrameDesc__typ;

extern void TextGadgets0_AdjustChild();
extern void TextGadgets0_Call();
extern void TextGadgets0_CopyFrame();
extern void TextGadgets0_CopyList();
extern void TextGadgets0_CopyOver();
extern void TextGadgets0_DeleteSelectedFrames();
extern void TextGadgets0_Dimensions();
extern void TextGadgets0_DrawChanges();
extern void TextGadgets0_Edit();
extern void TextGadgets0_EditSlider();
extern void TextGadgets0_FormatFrame();
extern void TextGadgets0_FrameHandler();
extern void TextGadgets0_GetSelectedFrames();
extern void TextGadgets0_GetSelection();
extern BOOLEAN TextGadgets0_InSync();
extern void TextGadgets0_InitFrame();
extern INTEGER TextGadgets0_LinesOf();
extern LONGINT TextGadgets0_LinesUp();
extern void TextGadgets0_Locate();
extern TextGadgets0_Box TextGadgets0_LocateBox();
extern void TextGadgets0_OpenBackRd();
extern void TextGadgets0_PrintText();
extern LONGINT TextGadgets0_RdPos();
extern void TextGadgets0_Read();
extern void TextGadgets0_RemoveCaret();
extern void TextGadgets0_RemoveChild();
extern void TextGadgets0_RemoveSelection();
extern void TextGadgets0_RestoreFrame();
extern void TextGadgets0_RestoreFrameArea();
extern void TextGadgets0_ScrollTo();
extern void TextGadgets0_SetCaret();
extern void TextGadgets0_SetSelection();
extern void TextGadgets0_ToBoxes();
extern void TextGadgets0_TrackCaret();
extern void TextGadgets0_TrackLine();
extern void TextGadgets0_TrackSelection();
extern void TextGadgets0_TrackWord();
extern void TextGadgets0_Update();
extern void TextGadgets0_UpdateChild();
extern void *TextGadgets0__init();


#endif
