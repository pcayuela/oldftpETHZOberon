/* Ofront 1.1 */

#ifndef Files__h
#define Files__h

#include "SYSTEM.h"

typedef
	struct Files_Handle *Files_File;

typedef
	struct Files_Handle {
		char _prvt0[216];
		LONGINT fd;
		char _prvt1[28];
	} Files_Handle;

typedef
	struct Files_Rider {
		LONGINT res;
		BOOLEAN eof;
		char _prvt0[15];
	} Files_Rider;



extern long *Files_Handle__typ;
extern long *Files_Rider__typ;

extern Files_File Files_Base();
extern void Files_ChangeDirectory();
extern void Files_Close();
extern void Files_Delete();
extern void Files_GetDate();
extern LONGINT Files_Length();
extern Files_File Files_New();
extern Files_File Files_Old();
extern LONGINT Files_Pos();
extern void Files_Purge();
extern void Files_Read();
extern void Files_ReadBool();
extern void Files_ReadBytes();
extern void Files_ReadInt();
extern void Files_ReadLInt();
extern void Files_ReadLReal();
extern void Files_ReadNum();
extern void Files_ReadReal();
extern void Files_ReadSet();
extern void Files_ReadString();
extern void Files_Register();
extern void Files_Rename();
extern void Files_Set();
extern void Files_Write();
extern void Files_WriteBool();
extern void Files_WriteBytes();
extern void Files_WriteInt();
extern void Files_WriteLInt();
extern void Files_WriteLReal();
extern void Files_WriteNum();
extern void Files_WriteReal();
extern void Files_WriteSet();
extern void Files_WriteString();
extern void *Files__init();


#endif
