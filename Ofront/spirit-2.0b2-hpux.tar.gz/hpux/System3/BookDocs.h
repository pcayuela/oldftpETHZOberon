/* Ofront 1.1 */

#ifndef BookDocs__h
#define BookDocs__h

#include "SYSTEM.h"
#include "Display.h"
#include "Fonts.h"
#include "Objects.h"

typedef
	struct BookDocs_InValMsg { /* Display_FrameMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
		CHAR name[64];
	} BookDocs_InValMsg;


extern Fonts_Font BookDocs_titleFont, BookDocs_textFont, BookDocs_noteFont, BookDocs_linkFont, BookDocs_callFont;
extern Fonts_Font BookDocs_sectionFonts[4];

extern long *BookDocs_InValMsg__typ;

extern void BookDocs_Contents();
extern void BookDocs_CopyToFile();
extern void BookDocs_DoLink();
extern void BookDocs_DoNote();
extern void BookDocs_DocHandler();
extern void BookDocs_History();
extern BOOLEAN BookDocs_Import();
extern void BookDocs_Index();
extern void BookDocs_NewDoc();
extern void BookDocs_Next();
extern void BookDocs_Pop();
extern void BookDocs_Prev();
extern void BookDocs_PrintDoc();
extern void BookDocs_Search();
extern BOOLEAN BookDocs_SkipHeader();
extern void BookDocs_WriteHeader();
extern void *BookDocs__init();


#endif
