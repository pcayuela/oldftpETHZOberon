/* Ofront 1.1 */

#ifndef Finder__h
#define Finder__h

#include "SYSTEM.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Objects.h"

typedef
	struct Finder_DocListDesc *Finder_DocList;

typedef
	struct Finder_DocListDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		char _prvt0[1];
	} Finder_DocListDesc;



extern long *Finder_DocListDesc__typ;

extern void Finder_BringToFront();
extern void Finder_DocListHandler();
extern void Finder_NewDocList();
extern void *Finder__init();


#endif
