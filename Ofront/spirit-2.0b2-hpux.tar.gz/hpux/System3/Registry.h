/* Ofront 1.1 */

#ifndef Registry__h
#define Registry__h

#include "SYSTEM.h"

typedef
	void (*Registry_EntryHandler)();


extern INTEGER Registry_res;


extern void Registry_Enumerate();
extern void Registry_Get();
extern void Registry_Set();
extern void *Registry__init();


#endif
