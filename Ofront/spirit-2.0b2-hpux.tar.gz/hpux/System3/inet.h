/* Ofront 1.1 */

#ifndef inet__h
#define inet__h

#include "SYSTEM.h"




extern void *inet__init();


#endif
