/* Ofront 1.1 */

#ifndef Suitcases__h
#define Suitcases__h

#include "SYSTEM.h"
#include "Attributes.h"
#include "Display.h"
#include "Display3.h"
#include "Files.h"
#include "Gadgets.h"
#include "Objects.h"

typedef
	struct Suitcases_FileObjDesc *Suitcases_FileObj;

typedef
	struct Suitcases_FileObjDesc { /* Gadgets_ObjDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Attributes_Attr attr;
		Links_Link link;
		Files_File F;
		LONGINT beg, len;
	} Suitcases_FileObjDesc;

typedef
	struct Suitcases_SuitcaseDesc *Suitcases_Suitcase;

typedef
	struct Suitcases_SuitcaseDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		INTEGER col;
		CHAR label[64];
	} Suitcases_SuitcaseDesc;



extern long *Suitcases_FileObjDesc__typ;
extern long *Suitcases_SuitcaseDesc__typ;

extern void Suitcases_CopySuitcase();
extern void Suitcases_FileObjHandler();
extern void Suitcases_InitSuitcase();
extern void Suitcases_MakeFileSuitcase();
extern void Suitcases_MakeTextSuitcase();
extern void Suitcases_NewFileObj();
extern void Suitcases_NewSuitcase();
extern void Suitcases_OpenFileObj();
extern void Suitcases_PackFiles();
extern void Suitcases_PackText();
extern void Suitcases_SuitcaseHandler();
extern void Suitcases_UnpackFileObj();
extern void *Suitcases__init();


#endif
