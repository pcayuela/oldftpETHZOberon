/* Ofront 1.1 */

#ifndef BartSimpson__h
#define BartSimpson__h

#include "SYSTEM.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Objects.h"

typedef
	struct BartSimpson_FrameDesc *BartSimpson_Frame;

typedef
	struct BartSimpson_FrameDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		char _prvt0[10];
	} BartSimpson_FrameDesc;

typedef
	struct BartSimpson_MouseCoordDesc *BartSimpson_MouseCoord;

typedef
	struct BartSimpson_MouseCoordDesc { /* Gadgets_ObjDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Attributes_Attr attr;
		Links_Link link;
		char _prvt0[4];
	} BartSimpson_MouseCoordDesc;

typedef
	struct BartSimpson_MoveMsg { /* Display_FrameMsg */
		LONGINT stamp;
		Objects_Object dlink;
		Display_Frame F;
		INTEGER x, y, res;
	} BartSimpson_MoveMsg;



extern long *BartSimpson_MouseCoordDesc__typ;
extern long *BartSimpson_FrameDesc__typ;
extern long *BartSimpson_MoveMsg__typ;

extern void BartSimpson_CopyFrame();
extern void BartSimpson_Deinstall();
extern void BartSimpson_FrameHandler();
extern void BartSimpson_MouseHandler();
extern void BartSimpson_NewBart();
extern void BartSimpson_NewMouse();
extern void BartSimpson_ShowBartli();
extern void *BartSimpson__init();


#endif
