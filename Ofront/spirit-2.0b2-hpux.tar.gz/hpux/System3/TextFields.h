/* Ofront 1.1 */

#ifndef TextFields__h
#define TextFields__h

#include "SYSTEM.h"
#include "Attributes.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Objects.h"
#include "Texts.h"

typedef
	struct TextFields_CaptionDesc *TextFields_Caption;

typedef
	struct TextFields_CaptionDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		BOOLEAN focused, underlined;
		Texts_Text text;
		char _prvt0[4];
	} TextFields_CaptionDesc;

typedef
	struct TextFields_TextFieldDesc *TextFields_TextField;

typedef
	struct TextFields_TextFieldDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		INTEGER selbeg, selend;
		LONGINT time;
		INTEGER carpos, carx, cary;
		CHAR val[64];
		BOOLEAN consistent;
		INTEGER col;
		char _prvt0[2];
	} TextFields_TextFieldDesc;



extern long *TextFields_CaptionDesc__typ;
extern long *TextFields_TextFieldDesc__typ;

extern void TextFields_CalcSize();
extern void TextFields_CaptionHandler();
extern void TextFields_CopyCaption();
extern void TextFields_CopyTextField();
extern void TextFields_InitCaption();
extern void TextFields_InitTextField();
extern void TextFields_MakeCaption();
extern void TextFields_NewCaption();
extern void TextFields_NewTextField();
extern void TextFields_TextFieldHandler();
extern void *TextFields__init();


#endif
