/* Ofront 1.1 */

#ifndef XYplane__h
#define XYplane__h

#include "SYSTEM.h"


extern INTEGER XYplane_X, XYplane_Y, XYplane_W, XYplane_H;


extern void XYplane_Clear();
extern void XYplane_Dot();
extern BOOLEAN XYplane_IsDot();
extern CHAR XYplane_Key();
extern void XYplane_Open();
extern void XYplane_XYhandle();
extern void *XYplane__init();


#endif
