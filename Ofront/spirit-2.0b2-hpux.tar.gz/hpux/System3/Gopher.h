/* Ofront 1.1 */

#ifndef Gopher__h
#define Gopher__h

#include "SYSTEM.h"




extern void Gopher_Info();
extern void Gopher_NewDoc();
extern void Gopher_NewLinkScheme();
extern void *Gopher__init();


#endif
