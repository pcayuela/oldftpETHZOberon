/* Ofront 1.1 */

#ifndef In__h
#define In__h

#include "SYSTEM.h"


extern BOOLEAN In_Done;


extern void In_Char();
extern void In_Int();
extern void In_LongInt();
extern void In_LongReal();
extern void In_Name();
extern void In_Open();
extern void In_Real();
extern void In_String();
extern void *In__init();


#endif
