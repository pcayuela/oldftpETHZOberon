/* Ofront 1.1 */

#ifndef FTP__h
#define FTP__h

#include "SYSTEM.h"
#include "NetSystem.h"
#include "NetTools.h"

typedef
	void (*FTP_EnumProc)();

typedef
	struct FTP_SessionDesc *FTP_Session;

typedef
	struct FTP_SessionDesc { /* NetTools_SessionDesc */
		NetSystem_Connection C;
		CHAR reply[1024];
		INTEGER status, res;
		char _prvt0[521];
	} FTP_SessionDesc;


extern CHAR FTP_user[32];
extern CHAR FTP_passwd[64];

extern long *FTP_SessionDesc__typ;

extern void FTP_ChangeDir();
extern void FTP_ChangeDocDir();
extern void FTP_Close();
extern void FTP_DeleteDocFile();
extern void FTP_DeleteFile();
extern void FTP_EnumDir();
extern void FTP_GetCurDir();
extern void FTP_GetDocFile();
extern void FTP_GetFile();
extern void FTP_GetText();
extern void FTP_MakeDir();
extern void FTP_NewDoc();
extern void FTP_NewLinkScheme();
extern void FTP_Open();
extern void FTP_PutDocFile();
extern void FTP_PutDocText();
extern void FTP_PutFile();
extern void FTP_PutText();
extern LONGINT FTP_RegisterFTPAdr();
extern void FTP_RmDir();
extern void FTP_SetUser();
extern void FTP_ShowASCII();
extern LONGINT FTP_SplitFTPAdr();
extern void *FTP__init();


#endif
