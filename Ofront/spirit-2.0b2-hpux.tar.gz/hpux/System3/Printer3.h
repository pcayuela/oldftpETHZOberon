/* Ofront 1.1 */

#ifndef Printer3__h
#define Printer3__h

#include "SYSTEM.h"


extern LONGINT Printer3_Pattern[9];


extern void Printer3_CenterString();
extern void Printer3_Circle();
extern void Printer3_Dot();
extern void Printer3_Ellipse();
extern void Printer3_FillPattern();
extern void Printer3_FilledRect3D();
extern void Printer3_Line();
extern void Printer3_Pict();
extern void Printer3_Poly();
extern void Printer3_Rect();
extern void Printer3_Rect3D();
extern void Printer3_ReplConst();
extern void Printer3_ReplPict();
extern void Printer3_String();
extern void Printer3_StringSize();
extern void *Printer3__init();


#endif
