/* Ofront 1.1 */

#ifndef BasicGadgets__h
#define BasicGadgets__h

#include "SYSTEM.h"
#include "Attributes.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Objects.h"

typedef
	struct BasicGadgets_BooleanDesc *BasicGadgets_Boolean;

typedef
	struct BasicGadgets_BooleanDesc { /* Gadgets_ObjDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Attributes_Attr attr;
		Links_Link link;
		BOOLEAN val;
	} BasicGadgets_BooleanDesc;

typedef
	struct BasicGadgets_ButtonDesc *BasicGadgets_Button;

typedef
	struct BasicGadgets_ButtonDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		CHAR caption[32];
		BOOLEAN val, popout;
		INTEGER setval;
		Objects_Object look;
		char _prvt0[8];
	} BasicGadgets_ButtonDesc;

typedef
	struct BasicGadgets_CheckBoxDesc *BasicGadgets_CheckBox;

typedef
	struct BasicGadgets_CheckBoxDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		BOOLEAN val;
		INTEGER setval;
	} BasicGadgets_CheckBoxDesc;

typedef
	struct BasicGadgets_IntegerDesc *BasicGadgets_Integer;

typedef
	struct BasicGadgets_IntegerDesc { /* Gadgets_ObjDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Attributes_Attr attr;
		Links_Link link;
		LONGINT val;
	} BasicGadgets_IntegerDesc;

typedef
	struct BasicGadgets_RealDesc *BasicGadgets_Real;

typedef
	struct BasicGadgets_RealDesc { /* Gadgets_ObjDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Attributes_Attr attr;
		Links_Link link;
		LONGREAL val;
	} BasicGadgets_RealDesc;

typedef
	struct BasicGadgets_SliderDesc *BasicGadgets_Slider;

typedef
	struct BasicGadgets_SliderDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		LONGINT min, max, val;
		char _prvt0[4];
	} BasicGadgets_SliderDesc;

typedef
	struct BasicGadgets_StringDesc *BasicGadgets_String;

typedef
	struct BasicGadgets_StringDesc { /* Gadgets_ObjDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Attributes_Attr attr;
		Links_Link link;
		CHAR val[64];
	} BasicGadgets_StringDesc;



extern long *BasicGadgets_BooleanDesc__typ;
extern long *BasicGadgets_StringDesc__typ;
extern long *BasicGadgets_IntegerDesc__typ;
extern long *BasicGadgets_RealDesc__typ;
extern long *BasicGadgets_ButtonDesc__typ;
extern long *BasicGadgets_CheckBoxDesc__typ;
extern long *BasicGadgets_SliderDesc__typ;

extern void BasicGadgets_BooleanHandler();
extern void BasicGadgets_Break();
extern void BasicGadgets_ButtonHandler();
extern void BasicGadgets_CheckBoxHandler();
extern void BasicGadgets_CopyBoolean();
extern void BasicGadgets_CopyButton();
extern void BasicGadgets_CopyCheckBox();
extern void BasicGadgets_CopyInteger();
extern void BasicGadgets_CopyReal();
extern void BasicGadgets_CopySlider();
extern void BasicGadgets_CopyString();
extern void BasicGadgets_InitBoolean();
extern void BasicGadgets_InitButton();
extern void BasicGadgets_InitCheckBox();
extern void BasicGadgets_InitInteger();
extern void BasicGadgets_InitReal();
extern void BasicGadgets_InitSlider();
extern void BasicGadgets_InitString();
extern void BasicGadgets_IntegerHandler();
extern void BasicGadgets_NewBoolean();
extern void BasicGadgets_NewButton();
extern void BasicGadgets_NewCheckBox();
extern void BasicGadgets_NewInteger();
extern void BasicGadgets_NewReal();
extern void BasicGadgets_NewSlider();
extern void BasicGadgets_NewString();
extern void BasicGadgets_RealHandler();
extern void BasicGadgets_SetValue();
extern void BasicGadgets_SetValues();
extern void BasicGadgets_SliderHandler();
extern void BasicGadgets_StringHandler();
extern void *BasicGadgets__init();


#endif
