/* Ofront 1.1 */

#ifndef TextFrames__h
#define TextFrames__h

#include "SYSTEM.h"
#include "Display.h"
#include "Objects.h"
#include "Texts.h"

typedef
	struct TextFrames_FrameDesc *TextFrames_Frame;

typedef
	struct TextFrames_Location {
		LONGINT org, pos;
		INTEGER dx, x, y;
		char _prvt0[6];
	} TextFrames_Location;

typedef
	struct TextFrames_FrameDesc { /* Display_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Texts_Text text;
		LONGINT org;
		INTEGER col, lsp, left, right, top, bot, markH;
		LONGINT time;
		INTEGER mark, car, sel;
		TextFrames_Location carloc, selbeg, selend;
		char _prvt0[4];
	} TextFrames_FrameDesc;


extern INTEGER TextFrames_menuH, TextFrames_barW, TextFrames_left, TextFrames_right, TextFrames_top, TextFrames_bot, TextFrames_lsp;

extern long *TextFrames_Location__typ;
extern long *TextFrames_FrameDesc__typ;

extern void TextFrames_Call();
extern void TextFrames_Copy();
extern void TextFrames_CopyOver();
extern void TextFrames_Defocus();
extern void TextFrames_Edit();
extern void TextFrames_Extend();
extern void TextFrames_GetAttr();
extern void TextFrames_GetCaret();
extern void TextFrames_GetSelection();
extern void TextFrames_Handle();
extern void TextFrames_LocateLine();
extern void TextFrames_Mark();
extern void TextFrames_Modify();
extern void TextFrames_Neutralize();
extern TextFrames_Frame TextFrames_NewMenu();
extern TextFrames_Frame TextFrames_NewText();
extern void TextFrames_Open();
extern LONGINT TextFrames_Pos();
extern void TextFrames_Reduce();
extern void TextFrames_RemoveCaret();
extern void TextFrames_RemoveSelection();
extern void TextFrames_Restore();
extern void TextFrames_SetCaret();
extern void TextFrames_SetSelection();
extern void TextFrames_Show();
extern void TextFrames_Suspend();
extern Texts_Text TextFrames_Text();
extern void TextFrames_TrackCaret();
extern void TextFrames_TrackLine();
extern void TextFrames_TrackSelection();
extern void TextFrames_TrackWord();
extern void TextFrames_Update();
extern void TextFrames_Write();
extern void *TextFrames__init();


#endif
