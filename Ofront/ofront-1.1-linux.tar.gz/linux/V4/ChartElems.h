/* Ofront 1.1 */

#ifndef ChartElems__h
#define ChartElems__h

#include "SYSTEM.h"




extern void ChartElems_Alloc();
extern void ChartElems_Insert();
extern void *ChartElems__init();


#endif
