/* Ofront 1.1 */

#ifndef Modules__h
#define Modules__h

#include "SYSTEM.h"

typedef
	struct Modules_CmdDesc *Modules_Cmd;

typedef
	void (*Modules_Command)();

typedef
	struct Modules_CmdDesc {
		Modules_Cmd next;
		CHAR name[24];
		Modules_Command cmd;
	} Modules_CmdDesc;

typedef
	struct Modules_ModuleDesc *Modules_Module;

typedef
	CHAR Modules_ModuleName[20];

typedef
	struct Modules_ModuleDesc {
		Modules_Module next;
		Modules_ModuleName name;
		LONGINT refcnt;
		Modules_Cmd cmds;
		LONGINT types;
		void (*enumPtrs)();
		char _prvt0[8];
	} Modules_ModuleDesc;


extern INTEGER Modules_res;
extern CHAR Modules_resMsg[256];
extern Modules_ModuleName Modules_imported, Modules_importing;

extern long *Modules_ModuleDesc__typ;
extern long *Modules_CmdDesc__typ;

extern Modules_Command Modules_ThisCommand();
extern Modules_Module Modules_ThisMod();
extern void *Modules__init();

#define Modules_modules()	(Modules_Module)SYSTEM_modules

#endif
