/* Ofront 1.1 */

#ifndef Kepler4__h
#define Kepler4__h

#include "SYSTEM.h"
#include "Fonts.h"
#include "KeplerFrames.h"
#include "KeplerGraphs.h"

typedef
	struct Kepler4_GalaxyDesc *Kepler4_Galaxy;

typedef
	struct Kepler4_GalaxyDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
		KeplerGraphs_Graph G;
	} Kepler4_GalaxyDesc;

extern void Kepler4_Galaxy_Draw();
extern void Kepler4_Galaxy_Read();
extern void Kepler4_Galaxy_Write();

typedef
	struct Kepler4_IconDesc *Kepler4_Icon;

typedef
	struct Kepler4_IconDesc { /* KeplerFrames_ButtonDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
		CHAR cmd[32], par[32];
		Fonts_Font fnt;
		char _prvt0[4];
	} Kepler4_IconDesc;

extern void Kepler4_Icon_Draw();
extern void Kepler4_Icon_Execute();
extern void Kepler4_Icon_Read();
extern void Kepler4_Icon_Write();



extern long *Kepler4_IconDesc__typ;
extern long *Kepler4_GalaxyDesc__typ;

extern void Kepler4_NewButton();
extern void Kepler4_NewGalaxy();
extern void Kepler4_NewIcon();
extern void Kepler4_UpdateButton();
extern void *Kepler4__init();


#endif
