/* Ofront 1.1 */

#ifndef Kepler__h
#define Kepler__h

#include "SYSTEM.h"




extern void Kepler_AlignToGrid();
extern void Kepler_AlignX();
extern void Kepler_AlignY();
extern void Kepler_Constellations();
extern void Kepler_Delete();
extern void Kepler_Join();
extern void Kepler_Open();
extern void Kepler_Print();
extern void Kepler_Recall();
extern void Kepler_Reset();
extern void Kepler_ScalePoints();
extern void Kepler_SendBack();
extern void Kepler_SetGrid();
extern void Kepler_SetScale();
extern void Kepler_Split();
extern void Kepler_Store();
extern void *Kepler__init();


#endif
