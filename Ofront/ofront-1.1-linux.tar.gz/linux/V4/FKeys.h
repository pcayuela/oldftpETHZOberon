/* Ofront 1.1 */

#ifndef FKeys__h
#define FKeys__h

#include "SYSTEM.h"




extern void FKeys_Get();
extern void FKeys_InternationalKey();
extern void FKeys_Set();
extern void FKeys_SetCommand();
extern void *FKeys__init();


#endif
