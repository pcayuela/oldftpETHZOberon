/* Ofront 1.1 */

#ifndef Kepler9__h
#define Kepler9__h

#include "SYSTEM.h"
#include "KeplerGraphs.h"

typedef
	struct Kepler9_CircleIntersection *Kepler9_CircleInter;

typedef
	struct Kepler9_CircleIntersection { /* KeplerGraphs_PlanetDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
		SHORTINT sign;
	} Kepler9_CircleIntersection;

extern void Kepler9_CircleInter_Calc();
extern void Kepler9_CircleInter_Read();
extern void Kepler9_CircleInter_Write();

typedef
	struct Kepler9_CircleLineIntersection *Kepler9_CircleLineInter;

typedef
	struct Kepler9_CircleLineIntersection { /* KeplerGraphs_PlanetDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
		SHORTINT sign;
	} Kepler9_CircleLineIntersection;

extern void Kepler9_CircleLineInter_Calc();
extern void Kepler9_CircleLineInter_Read();
extern void Kepler9_CircleLineInter_Write();

typedef
	struct Kepler9_ExtensionDesc *Kepler9_Extension;

typedef
	struct Kepler9_ExtensionDesc { /* KeplerGraphs_PlanetDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
	} Kepler9_ExtensionDesc;

extern void Kepler9_Extension_Calc();

typedef
	struct Kepler9_IntersectionDesc *Kepler9_Intersection;

typedef
	struct Kepler9_IntersectionDesc { /* KeplerGraphs_PlanetDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
	} Kepler9_IntersectionDesc;

extern void Kepler9_Intersection_Calc();

typedef
	struct Kepler9_ParallelDesc *Kepler9_Parallel;

typedef
	struct Kepler9_ParallelDesc { /* KeplerGraphs_PlanetDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
	} Kepler9_ParallelDesc;

extern void Kepler9_Parallel_Calc();

typedef
	struct Kepler9_RightAngleDesc *Kepler9_RightAngle;

typedef
	struct Kepler9_RightAngleDesc { /* KeplerGraphs_PlanetDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
	} Kepler9_RightAngleDesc;

extern void Kepler9_RightAngle_Calc();

typedef
	struct Kepler9_TangentDesc *Kepler9_Tangent;

typedef
	struct Kepler9_TangentDesc { /* KeplerGraphs_PlanetDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
		SHORTINT sign;
	} Kepler9_TangentDesc;

extern void Kepler9_Tangent_Calc();
extern void Kepler9_Tangent_Read();
extern void Kepler9_Tangent_Write();



extern long *Kepler9_ParallelDesc__typ;
extern long *Kepler9_RightAngleDesc__typ;
extern long *Kepler9_IntersectionDesc__typ;
extern long *Kepler9_ExtensionDesc__typ;
extern long *Kepler9_TangentDesc__typ;
extern long *Kepler9_CircleIntersection__typ;
extern long *Kepler9_CircleLineIntersection__typ;

extern void Kepler9_NewCircleIntersection();
extern void Kepler9_NewCircleLineIntersect();
extern void Kepler9_NewExtension();
extern void Kepler9_NewLineIntersection();
extern void Kepler9_NewParallel();
extern void Kepler9_NewRightAngle();
extern void Kepler9_NewTangent();
extern void *Kepler9__init();


#endif
