/* Ofront 1.1 */

#ifndef Mailer__h
#define Mailer__h

#include "SYSTEM.h"


extern CHAR Mailer_MAIL[110], Mailer_MBOX[110];


extern void Mailer_Append();
extern void Mailer_CutLines();
extern void Mailer_Delete();
extern void Mailer_Mailbox();
extern void Mailer_Mono();
extern void Mailer_Post();
extern void Mailer_Quote();
extern void Mailer_Reply();
extern void Mailer_Send();
extern void Mailer_Show();
extern void Mailer_Store();
extern void *Mailer__init();


#endif
