/* Ofront 1.1 */

#ifndef System__h
#define System__h

#include "SYSTEM.h"




extern void System_ChangeDirectory();
extern void System_ClearLog();
extern void System_Close();
extern void System_CloseTrack();
extern void System_Collect();
extern void System_Copy();
extern void System_CopyFiles();
extern void System_DeleteFiles();
extern void System_Directory();
extern void System_Execute();
extern void System_Grow();
extern void System_Open();
extern void System_OpenLog();
extern void System_Quit();
extern void System_Recall();
extern void System_RenameFiles();
extern void System_SetColor();
extern void System_SetFont();
extern void System_SetOffset();
extern void System_SetUser();
extern void System_ShowCommands();
extern void System_ShowModules();
extern void System_Time();
extern void System_Trap();
extern void System_Watch();
extern void *System__init();


#endif
