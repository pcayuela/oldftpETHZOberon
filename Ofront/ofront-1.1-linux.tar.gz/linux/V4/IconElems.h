/* Ofront 1.1 */

#ifndef IconElems__h
#define IconElems__h

#include "SYSTEM.h"




extern void IconElems_Insert();
extern void IconElems_New();
extern void IconElems_Stop();
extern void *IconElems__init();


#endif
