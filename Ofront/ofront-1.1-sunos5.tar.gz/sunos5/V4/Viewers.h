/* Ofront 1.1 */

#ifndef Viewers__h
#define Viewers__h

#include "SYSTEM.h"
#include "Display.h"

typedef
	struct Viewers_ViewerDesc *Viewers_Viewer;

typedef
	struct Viewers_ViewerDesc { /* Display_FrameDesc */
		Display_Frame dsc, next;
		INTEGER X, Y, W, H;
		Display_Handler handle;
		INTEGER state;
	} Viewers_ViewerDesc;

typedef
	struct Viewers_ViewerMsg { /* Display_FrameMsg */
		INTEGER id, X, Y, W, H, state;
	} Viewers_ViewerMsg;


extern INTEGER Viewers_curW, Viewers_minH;

extern long *Viewers_ViewerDesc__typ;
extern long *Viewers_ViewerMsg__typ;

extern void Viewers_Broadcast();
extern void Viewers_Change();
extern void Viewers_Close();
extern void Viewers_CloseTrack();
extern void Viewers_InitTrack();
extern void Viewers_Locate();
extern Viewers_Viewer Viewers_Next();
extern void Viewers_Open();
extern void Viewers_OpenTrack();
extern void Viewers_Recall();
extern Viewers_Viewer Viewers_This();
extern void *Viewers__init();


#endif
