/* Ofront 1.1 */

#ifndef Unix__h
#define Unix__h

#include "SYSTEM.h"

typedef
	struct Unix_Dirent {
		LONGINT ino, off, fileno;
		INTEGER reclen;
		CHAR name[1];
	} Unix_Dirent;

typedef
	struct Unix_FLock {
		INTEGER type, whence;
		LONGINT start, len, sysid, pid;
		LONGINT pad[4];
	} Unix_FLock;

typedef
	SET Unix_FdSet[8];

typedef
	struct Unix_Hostent *Unix_HostEntry;

typedef
	struct Unix_Hostent {
		LONGINT name, aliases, addrtype, length, addrlist;
	} Unix_Hostent;

typedef
	struct Unix_Iovec {
		LONGINT base, len;
	} Unix_Iovec;

typedef
	struct Unix_Timeval {
		LONGINT sec, usec;
	} Unix_Timeval;

typedef
	struct Unix_Itimerval {
		Unix_Timeval interval, value;
	} Unix_Itimerval;

typedef
	struct Unix_JmpBuf {
		LONGINT _prvt0;
		char _prvt1[76];
	} Unix_JmpBuf;

typedef
	CHAR *Unix_Name;

typedef
	LONGINT Unix_PipeFd[2];

typedef
	struct Unix_Pollfd {
		LONGINT fd;
		INTEGER events, revents;
	} Unix_Pollfd;

typedef
	struct Unix_Timestruc {
		LONGINT sec, nsec;
	} Unix_Timestruc;

typedef
	struct Unix_Rusage {
		Unix_Timestruc utime, stime;
		LONGINT maxrss, ixrss, idrss, isrss, minflt, majflt, nswap, inblock, oublock, msgsnd, msgrcv, nsignals, nvcsw, nivcsw;
	} Unix_Rusage;

typedef
	struct Unix_SigContext {
		char _prvt0[1];
	} Unix_SigContext;

typedef
	Unix_SigContext *Unix_SigCtxPtr;

typedef
	void (*Unix_SignalHandler)();

typedef
	struct Unix_Sockaddr {
		INTEGER family, port;
		LONGINT internetAddr;
		CHAR pad[8];
	} Unix_Sockaddr;

typedef
	struct Unix_Status {
		LONGINT dev;
		LONGINT pad1[3];
		LONGINT ino, mode, nlink, uid, gid, rdev;
		LONGINT pad2[2];
		LONGINT size, pad3, atime, atimensec, mtime, mtimensec, ctime, ctimensec, blksize, blocks;
		CHAR fstype[16];
		LONGINT pad4[8];
	} Unix_Status;

typedef
	struct Unix_TimeDesc *Unix_Time;

typedef
	struct Unix_TimeDesc {
		LONGINT sec, min, hour, mday, mon, year, wday, yday, isdst, zone, gmtoff;
	} Unix_TimeDesc;

typedef
	struct Unix_Timezone {
		LONGINT minuteswest, dsttime;
	} Unix_Timezone;

typedef
	struct Unix_Tms {
		LONGINT utime, stime, cutime, cstime;
	} Unix_Tms;



extern long *Unix_JmpBuf__typ;
extern long *Unix_Status__typ;
extern long *Unix_FLock__typ;
extern long *Unix_Timeval__typ;
extern long *Unix_Timestruc__typ;
extern long *Unix_TimeDesc__typ;
extern long *Unix_Timezone__typ;
extern long *Unix_Itimerval__typ;
extern long *Unix_Tms__typ;
extern long *Unix_Dirent__typ;
extern long *Unix_Rusage__typ;
extern long *Unix_Iovec__typ;
extern long *Unix_Pollfd__typ;
extern long *Unix_SigContext__typ;
extern long *Unix_Sockaddr__typ;
extern long *Unix_Hostent__typ;

extern LONGINT Unix_Flock();
extern LONGINT Unix_Gethostname();
extern LONGINT Unix_errno();
extern void *Unix__init();

#define Unix_Accept(socket, addr, addr__typ, addrlen)	accept(socket, addr, addrlen)
#define Unix_Bind(socket, name, namelen)	bind(socket, &(name), namelen)
#define Unix_Chdir(path, path__len)	chdir(path)
#define Unix_Chmod(path, path__len, mode)	chmod(path, mode)
#define Unix_Close(fd)	close(fd)
#define Unix_Connect(socket, name, namelen)	connect(socket, &(name), namelen)
#define Unix_Dup(fd)	dup(fd)
#define Unix_Dup2(fd1, fd2)	dup(fd1, fd2)
#define Unix_Exit(n)	exit(n)
#define Unix_Fchmod(fd, mode)	fchmod(fd, mode)
#define Unix_Fstat(fd, statbuf, statbuf__typ)	fstat(fd, statbuf)
#define Unix_Fsync(fd)	fsync(fd)
#define Unix_Ftruncate(fd, length)	ftruncate(fd, length)
#define Unix_Getegid()	getegid()
#define Unix_Geteuid()	geteuid()
#define Unix_Getgid()	getgid()
#define Unix_Gethostbyname(name, name__len)	(Unix_HostEntry)gethostbyname(name)
#define Unix_Getpid()	getpid()
#define Unix_Getsockname(socket, name, name__typ, namelen)	getsockname(socket, name, namelen)
#define Unix_Gettimeofday(tv, tv__typ, tz, tz__typ)	gettimeofday(tv, tz)
#define Unix_Getuid()	getuid()
#define Unix_Ioctl(fd, request, arg)	ioctl(fd, request, arg)
#define Unix_Kill(pid, sig)	kill(pid, sig)
#define Unix_Listen(socket, backlog)	listen(socket, backlog)
#define Unix_Lseek(fd, offset, origin)	lseek(fd, offset, origin)
#define Unix_Open(name, name__len, flag, mode)	open(name, flag, mode)
#define Unix_Read(fd, buf, nbyte)	read(fd, buf, nbyte)
#define Unix_ReadBlk(fd, buf, buf__len)	read(fd, buf, buf__len)
#define Unix_Readblk(fd, buf, buf__len, len)	read(fd, buf, len)
#define Unix_Recv(socket, bufadr, buflen, flags)	recv(socket, bufadr, buflen, flags)
#define Unix_Rename(old, old__len, new, new__len)	rename(old, new)
#define Unix_Select(width, readfds, writefds, exceptfds, timeout, timeout__typ)	select(width, readfds, writefds, exceptfds, timeout)
#define Unix_Send(socket, bufadr, buflen, flags)	send(socket, bufadr, buflen, flags)
#define Unix_Sigsetmask(mask)	sigsetmask(mask)
#define Unix_Socket(af, type, protocol)	socket(af, type, protocol)
#define Unix_Stat(name, name__len, statbuf, statbuf__typ)	stat(name, statbuf)
#define Unix_Sysinfo(command, buf, buf__len)	sysinfo(command, buf, buf__len)
#define Unix_Unlink(name, name__len)	unlink(name)
#define Unix_Write(fd, buf, nbyte)	write(fd, buf, nbyte)
#define Unix_WriteBlk(fd, buf, buf__len)	write(fd, buf, buf__len)

#endif
