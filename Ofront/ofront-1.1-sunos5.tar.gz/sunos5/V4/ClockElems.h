/* Ofront 1.1 */

#ifndef ClockElems__h
#define ClockElems__h

#include "SYSTEM.h"




extern void ClockElems_Insert();
extern void ClockElems_New();
extern void *ClockElems__init();


#endif
