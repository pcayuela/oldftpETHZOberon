/* Ofront 1.1 */

#ifndef Reals__h
#define Reals__h

#include "SYSTEM.h"




extern void Reals_Convert();
extern void Reals_ConvertH();
extern void Reals_ConvertHL();
extern void Reals_ConvertL();
extern INTEGER Reals_Expo();
extern INTEGER Reals_ExpoL();
extern void Reals_SetExpo();
extern void Reals_SetExpoL();
extern REAL Reals_Ten();
extern LONGREAL Reals_TenL();
extern void *Reals__init();


#endif
