/* Ofront 1.1 */

#ifndef FoldElems__h
#define FoldElems__h

#include "SYSTEM.h"
#include "Texts.h"

typedef
	BOOLEAN (*FoldElems_CheckProc)();

typedef
	struct FoldElems_ElemDesc *FoldElems_Elem;

typedef
	struct FoldElems_ElemDesc { /* Texts_ElemDesc */
		char _prvt0[20];
		LONGINT W, H;
		Texts_Handler handle;
		char _prvt1[4];
		SHORTINT mode;
		Texts_Buffer hidden;
		BOOLEAN visible;
	} FoldElems_ElemDesc;

typedef
	struct FoldElems_PrepSwitchMsg { /* Texts_ElemMsg */
		char _prvt0[1];
	} FoldElems_PrepSwitchMsg;


extern LONGINT FoldElems_elemW, FoldElems_elemH;

extern long *FoldElems_ElemDesc__typ;
extern long *FoldElems_PrepSwitchMsg__typ;

extern void FoldElems_Collapse();
extern void FoldElems_CollapseAll();
extern void FoldElems_Echo();
extern void FoldElems_Expand();
extern void FoldElems_ExpandAll();
extern void FoldElems_FindElem();
extern void FoldElems_FoldHandler();
extern void FoldElems_Insert();
extern void FoldElems_InsertCollapsed();
extern void FoldElems_Marks();
extern void FoldElems_New();
extern void FoldElems_Restore();
extern void FoldElems_Search();
extern void FoldElems_Switch();
extern FoldElems_Elem FoldElems_Twin();
extern void *FoldElems__init();


#endif
