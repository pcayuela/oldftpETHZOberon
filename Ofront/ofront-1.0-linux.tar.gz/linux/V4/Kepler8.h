/* Ofront 1.0 */

#ifndef Kepler8__h
#define Kepler8__h

#include "SYSTEM.h"
#include "KeplerGraphs.h"

typedef
	struct Kepler8_AttrRectDesc *Kepler8_AttrRect;

typedef
	struct Kepler8_AttrRectDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
		INTEGER texture, lineWidth, shadow, shadowWidth, corner;
	} Kepler8_AttrRectDesc;

extern void Kepler8_AttrRect_Draw();
extern void Kepler8_AttrRect_Read();
extern void Kepler8_AttrRect_Write();

typedef
	struct Kepler8_CircleIntersectDesc *Kepler8_CircleIntersect;

typedef
	struct Kepler8_CircleIntersectDesc { /* KeplerGraphs_PlanetDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
	} Kepler8_CircleIntersectDesc;

extern void Kepler8_CircleIntersect_Calc();

typedef
	struct Kepler8_EllipIntersectDesc *Kepler8_EllipIntersect;

typedef
	struct Kepler8_EllipIntersectDesc { /* KeplerGraphs_PlanetDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
	} Kepler8_EllipIntersectDesc;

extern void Kepler8_EllipIntersect_Calc();

typedef
	struct Kepler8_FilledCircleDesc *Kepler8_FilledCircle;

typedef
	struct Kepler8_FilledCircleDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
		INTEGER texture;
	} Kepler8_FilledCircleDesc;

extern void Kepler8_FilledCircle_Draw();
extern void Kepler8_FilledCircle_Read();
extern void Kepler8_FilledCircle_Write();

typedef
	struct Kepler8_RectIntersectDesc *Kepler8_RectIntersect;

typedef
	struct Kepler8_RectIntersectDesc { /* KeplerGraphs_PlanetDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
	} Kepler8_RectIntersectDesc;

extern void Kepler8_RectIntersect_Calc();



extern long *Kepler8_RectIntersectDesc__typ;
extern long *Kepler8_CircleIntersectDesc__typ;
extern long *Kepler8_EllipIntersectDesc__typ;
extern long *Kepler8_AttrRectDesc__typ;
extern long *Kepler8_FilledCircleDesc__typ;

extern void Kepler8_ChangeAttrRect();
extern void Kepler8_GetAttrRect();
extern void Kepler8_NewAttrRect();
extern void Kepler8_NewCircleIntersect();
extern void Kepler8_NewEllipseIntersect();
extern void Kepler8_NewFilledCircle();
extern void Kepler8_NewRectIntersect();
extern void *Kepler8__init();


#endif
