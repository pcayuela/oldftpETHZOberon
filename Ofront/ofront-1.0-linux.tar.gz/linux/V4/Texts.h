/* Ofront 1.0 */

#ifndef Texts__h
#define Texts__h

#include "SYSTEM.h"
#include "Files.h"
#include "Fonts.h"

typedef
	struct Texts_BufDesc {
		LONGINT len;
		char _prvt0[4];
	} Texts_BufDesc;

typedef
	Texts_BufDesc *Texts_Buffer;

typedef
	struct Texts_ElemMsg {
		char _prvt0[1];
	} Texts_ElemMsg;

typedef
	struct Texts_ElemDesc *Texts_Elem;

typedef
	struct Texts_CopyMsg { /* Texts_ElemMsg */
		Texts_Elem e;
	} Texts_CopyMsg;

typedef
	struct Texts_RunDesc {
		LONGINT _prvt0;
		char _prvt1[15];
	} Texts_RunDesc;

typedef
	void (*Texts_Handler)();

typedef
	struct Texts_ElemDesc {
		char _prvt0[20];
		LONGINT W, H;
		Texts_Handler handle;
		char _prvt1[4];
	} Texts_ElemDesc;

typedef
	struct Texts_FileMsg { /* Texts_ElemMsg */
		INTEGER id;
		LONGINT pos;
		Files_Rider r;
	} Texts_FileMsg;

typedef
	struct Texts_IdentifyMsg { /* Texts_ElemMsg */
		CHAR mod[32], proc[32];
	} Texts_IdentifyMsg;

typedef
	void (*Texts_Notifier)();

typedef
	struct Texts_Reader {
		BOOLEAN eot;
		Fonts_Font fnt;
		SHORTINT col, voff;
		Texts_Elem elem;
		char _prvt0[32];
	} Texts_Reader;

typedef
	struct Texts_Scanner { /* Texts_Reader */
		BOOLEAN eot;
		Fonts_Font fnt;
		SHORTINT col, voff;
		Texts_Elem elem;
		char _prvt0[32];
		CHAR nextCh;
		INTEGER line, class;
		LONGINT i;
		REAL x;
		LONGREAL y;
		CHAR c;
		SHORTINT len;
		CHAR s[64];
	} Texts_Scanner;

typedef
	struct Texts_TextDesc *Texts_Text;

typedef
	struct Texts_TextDesc {
		LONGINT len;
		Texts_Notifier notify;
		char _prvt0[12];
	} Texts_TextDesc;

typedef
	struct Texts_Writer {
		Texts_Buffer buf;
		Fonts_Font fnt;
		SHORTINT col, voff;
		char _prvt0[26];
	} Texts_Writer;


extern Texts_Elem Texts_new;

extern long *Texts_RunDesc__typ;
extern long *Texts_ElemMsg__typ;
extern long *Texts_ElemDesc__typ;
extern long *Texts_FileMsg__typ;
extern long *Texts_CopyMsg__typ;
extern long *Texts_IdentifyMsg__typ;
extern long *Texts_BufDesc__typ;
extern long *Texts_TextDesc__typ;
extern long *Texts_Reader__typ;
extern long *Texts_Scanner__typ;
extern long *Texts_Writer__typ;

extern void Texts_Append();
extern void Texts_ChangeLooks();
extern void Texts_Close();
extern void Texts_Copy();
extern void Texts_CopyElem();
extern void Texts_Delete();
extern Texts_Text Texts_ElemBase();
extern LONGINT Texts_ElemPos();
extern void Texts_Insert();
extern void Texts_Load();
extern void Texts_Open();
extern void Texts_OpenBuf();
extern void Texts_OpenReader();
extern void Texts_OpenScanner();
extern void Texts_OpenWriter();
extern LONGINT Texts_Pos();
extern void Texts_Read();
extern void Texts_ReadElem();
extern void Texts_ReadPrevElem();
extern void Texts_Recall();
extern void Texts_Save();
extern void Texts_Scan();
extern void Texts_SetColor();
extern void Texts_SetFont();
extern void Texts_SetOffset();
extern void Texts_Store();
extern void Texts_Write();
extern void Texts_WriteDate();
extern void Texts_WriteElem();
extern void Texts_WriteHex();
extern void Texts_WriteInt();
extern void Texts_WriteLn();
extern void Texts_WriteLongReal();
extern void Texts_WriteLongRealHex();
extern void Texts_WriteReal();
extern void Texts_WriteRealFix();
extern void Texts_WriteRealHex();
extern void Texts_WriteString();
extern void *Texts__init();


#endif
