/* Ofront 1.0 */

#ifndef KeplerElems__h
#define KeplerElems__h

#include "SYSTEM.h"




extern void KeplerElems_Alloc();
extern void KeplerElems_Insert();
extern void KeplerElems_Update();
extern void *KeplerElems__init();


#endif
