/* Ofront 1.0 */

#ifndef ErrorElems__h
#define ErrorElems__h

#include "SYSTEM.h"
#include "Fonts.h"
#include "Texts.h"

typedef
	struct ErrorElems_ElemDesc *ErrorElems_Elem;

typedef
	struct ErrorElems_ElemDesc { /* Texts_ElemDesc */
		char _prvt0[20];
		LONGINT W, H;
		Texts_Handler handle;
		char _prvt1[4];
		INTEGER err;
		CHAR msg[128];
		char _prvt2[1];
	} ErrorElems_ElemDesc;


extern Fonts_Font ErrorElems_font;

extern long *ErrorElems_ElemDesc__typ;

extern void ErrorElems_Copy();
extern void ErrorElems_Delete();
extern void ErrorElems_Disp();
extern void ErrorElems_Edit();
extern void ErrorElems_Expand();
extern void ErrorElems_Handle();
extern void ErrorElems_InsertAt();
extern void ErrorElems_LocateNext();
extern void ErrorElems_Mark();
extern void ErrorElems_Prepare();
extern void ErrorElems_Print();
extern void ErrorElems_Reduce();
extern void ErrorElems_ShowErrMsg();
extern void ErrorElems_Unmark();
extern void *ErrorElems__init();


#endif
