/* Ofront 1.0 */

#ifndef Printer__h
#define Printer__h

#include "SYSTEM.h"


extern INTEGER Printer_res, Printer_PageWidth, Printer_PageHeight;


extern void Printer_Circle();
extern void Printer_Close();
extern void Printer_ContString();
extern void Printer_Ellipse();
extern void Printer_Line();
extern void Printer_Open();
extern void Printer_Page();
extern void Printer_Picture();
extern void Printer_ReplConst();
extern void Printer_ReplPattern();
extern void Printer_Spline();
extern void Printer_String();
extern void Printer_UseColor();
extern void Printer_UseListFont();
extern void *Printer__init();


#endif
