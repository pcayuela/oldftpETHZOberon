/* Ofront 1.0 */

#ifndef Display1__h
#define Display1__h

#include "SYSTEM.h"




extern void Display1_Circle();
extern void Display1_Ellipse();
extern void Display1_GetPatternSize();
extern void Display1_Line();
extern LONGINT Display1_ThisPattern();
extern void *Display1__init();


#endif
