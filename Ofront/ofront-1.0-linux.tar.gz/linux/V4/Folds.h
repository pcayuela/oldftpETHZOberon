/* Ofront 1.0 */

#ifndef Folds__h
#define Folds__h

#include "SYSTEM.h"




extern void Folds_Compile();
extern void Folds_SetProfile();
extern void Folds_ShowError();
extern void *Folds__init();


#endif
