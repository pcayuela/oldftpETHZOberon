/* Ofront 1.0 */

#ifndef Miscellaneous__h
#define Miscellaneous__h

#include "SYSTEM.h"




extern void Miscellaneous_Cleanup();
extern void Miscellaneous_ConvertBlanks();
extern void Miscellaneous_ConvertTabs();
extern void Miscellaneous_Copy();
extern void Miscellaneous_CountLines();
extern void Miscellaneous_Cut();
extern void Miscellaneous_Paste();
extern void *Miscellaneous__init();


#endif
