/* Ofront 1.0 */

#ifndef CmdlnTexts__h
#define CmdlnTexts__h

#include "SYSTEM.h"
#include "Files.h"

typedef
	struct CmdlnTexts_BufDesc {
		LONGINT len;
		char _prvt0[4];
	} CmdlnTexts_BufDesc;

typedef
	CmdlnTexts_BufDesc *CmdlnTexts_Buffer;

typedef
	struct CmdlnTexts_ElemMsg {
		char _prvt0[1];
	} CmdlnTexts_ElemMsg;

typedef
	struct CmdlnTexts_ElemDesc *CmdlnTexts_Elem;

typedef
	struct CmdlnTexts_CopyMsg { /* CmdlnTexts_ElemMsg */
		CmdlnTexts_Elem e;
	} CmdlnTexts_CopyMsg;

typedef
	struct CmdlnTexts_RunDesc {
		LONGINT _prvt0;
		char _prvt1[15];
	} CmdlnTexts_RunDesc;

typedef
	void (*CmdlnTexts_Handler)();

typedef
	struct CmdlnTexts_ElemDesc {
		char _prvt0[20];
		LONGINT W, H;
		CmdlnTexts_Handler handle;
		char _prvt1[4];
	} CmdlnTexts_ElemDesc;

typedef
	struct CmdlnTexts_FileMsg { /* CmdlnTexts_ElemMsg */
		INTEGER id;
		LONGINT pos;
		Files_Rider r;
	} CmdlnTexts_FileMsg;

typedef
	struct CmdlnTexts_FontDesc {
		char _prvt0[32];
	} CmdlnTexts_FontDesc;

typedef
	CmdlnTexts_FontDesc *CmdlnTexts_FontsFont;

typedef
	struct CmdlnTexts_IdentifyMsg { /* CmdlnTexts_ElemMsg */
		CHAR mod[32], proc[32];
	} CmdlnTexts_IdentifyMsg;

typedef
	struct CmdlnTexts_Reader {
		BOOLEAN eot;
		CmdlnTexts_FontsFont fnt;
		SHORTINT col, voff;
		CmdlnTexts_Elem elem;
		char _prvt0[32];
	} CmdlnTexts_Reader;

typedef
	struct CmdlnTexts_Scanner { /* CmdlnTexts_Reader */
		BOOLEAN eot;
		CmdlnTexts_FontsFont fnt;
		SHORTINT col, voff;
		CmdlnTexts_Elem elem;
		char _prvt0[32];
		CHAR nextCh;
		INTEGER line, class;
		LONGINT i;
		REAL x;
		LONGREAL y;
		CHAR c;
		SHORTINT len;
		CHAR s[64];
	} CmdlnTexts_Scanner;

typedef
	struct CmdlnTexts_TextDesc *CmdlnTexts_Text;

typedef
	struct CmdlnTexts_TextDesc {
		LONGINT len;
		char _prvt0[12];
	} CmdlnTexts_TextDesc;

typedef
	struct CmdlnTexts_Writer {
		CmdlnTexts_Buffer buf;
		CmdlnTexts_FontsFont fnt;
		SHORTINT col, voff;
		char _prvt0[26];
	} CmdlnTexts_Writer;


extern CmdlnTexts_Elem CmdlnTexts_new;

extern long *CmdlnTexts_FontDesc__typ;
extern long *CmdlnTexts_RunDesc__typ;
extern long *CmdlnTexts_ElemMsg__typ;
extern long *CmdlnTexts_ElemDesc__typ;
extern long *CmdlnTexts_FileMsg__typ;
extern long *CmdlnTexts_CopyMsg__typ;
extern long *CmdlnTexts_IdentifyMsg__typ;
extern long *CmdlnTexts_BufDesc__typ;
extern long *CmdlnTexts_TextDesc__typ;
extern long *CmdlnTexts_Reader__typ;
extern long *CmdlnTexts_Scanner__typ;
extern long *CmdlnTexts_Writer__typ;

extern void CmdlnTexts_Append();
extern void CmdlnTexts_ChangeLooks();
extern void CmdlnTexts_Close();
extern void CmdlnTexts_Copy();
extern void CmdlnTexts_CopyElem();
extern void CmdlnTexts_Delete();
extern CmdlnTexts_Text CmdlnTexts_ElemBase();
extern LONGINT CmdlnTexts_ElemPos();
extern void CmdlnTexts_Insert();
extern void CmdlnTexts_Load();
extern void CmdlnTexts_Open();
extern void CmdlnTexts_OpenBuf();
extern void CmdlnTexts_OpenReader();
extern void CmdlnTexts_OpenScanner();
extern void CmdlnTexts_OpenWriter();
extern LONGINT CmdlnTexts_Pos();
extern void CmdlnTexts_Read();
extern void CmdlnTexts_ReadElem();
extern void CmdlnTexts_ReadPrevElem();
extern void CmdlnTexts_Recall();
extern void CmdlnTexts_Save();
extern void CmdlnTexts_Scan();
extern void CmdlnTexts_SetColor();
extern void CmdlnTexts_SetFont();
extern void CmdlnTexts_SetOffset();
extern void CmdlnTexts_Store();
extern void CmdlnTexts_Write();
extern void CmdlnTexts_WriteDate();
extern void CmdlnTexts_WriteElem();
extern void CmdlnTexts_WriteHex();
extern void CmdlnTexts_WriteInt();
extern void CmdlnTexts_WriteLn();
extern void CmdlnTexts_WriteLongReal();
extern void CmdlnTexts_WriteLongRealHex();
extern void CmdlnTexts_WriteReal();
extern void CmdlnTexts_WriteRealFix();
extern void CmdlnTexts_WriteRealHex();
extern void CmdlnTexts_WriteString();
extern void *CmdlnTexts__init();


#endif
