/* Ofront 1.1 */

#ifndef TextFrames__h
#define TextFrames__h

#include "SYSTEM.h"
#include "Display.h"
#include "Fonts.h"
#include "Texts.h"

typedef
	struct TextFrames_DisplayMsg { /* Texts_ElemMsg */
		BOOLEAN prepare;
		Fonts_Font fnt;
		SHORTINT col;
		LONGINT pos;
		Display_Frame frame;
		INTEGER X0, Y0;
		LONGINT indent;
		Display_Frame elemFrame;
	} TextFrames_DisplayMsg;

typedef
	struct TextFrames_FocusMsg { /* Texts_ElemMsg */
		BOOLEAN focus;
		Display_Frame elemFrame, frame;
	} TextFrames_FocusMsg;

typedef
	struct TextFrames_FrameDesc *TextFrames_Frame;

typedef
	struct TextFrames_Location {
		LONGINT org, pos;
		INTEGER x, y, dx, dy;
		char _prvt0[4];
	} TextFrames_Location;

typedef
	struct TextFrames_FrameDesc { /* Display_FrameDesc */
		Display_Frame dsc, next;
		INTEGER X, Y, W, H;
		Display_Handler handle;
		Texts_Text text;
		LONGINT org;
		INTEGER col, left, right, top, bot, markH, barW;
		LONGINT time;
		BOOLEAN hasCar, hasSel, showsParcs;
		TextFrames_Location carloc, selbeg, selend;
		Display_Frame focus;
		char _prvt0[4];
	} TextFrames_FrameDesc;

typedef
	struct TextFrames_InsertElemMsg { /* Display_FrameMsg */
		Texts_Elem e;
	} TextFrames_InsertElemMsg;

typedef
	struct TextFrames_NotifyMsg { /* Display_FrameMsg */
		Display_Frame frame;
	} TextFrames_NotifyMsg;

typedef
	struct TextFrames_ParcDesc *TextFrames_Parc;

typedef
	struct TextFrames_ParcDesc { /* Texts_ElemDesc */
		char _prvt0[20];
		LONGINT W, H;
		Texts_Handler handle;
		char _prvt1[4];
		LONGINT left, first, width, lead, lsp, dsr;
		SET opts;
		INTEGER nofTabs;
		LONGINT tab[32];
	} TextFrames_ParcDesc;

typedef
	struct TextFrames_TrackMsg { /* Texts_ElemMsg */
		INTEGER X, Y;
		SET keys;
		Fonts_Font fnt;
		SHORTINT col;
		LONGINT pos;
		Display_Frame frame;
		INTEGER X0, Y0;
	} TextFrames_TrackMsg;

typedef
	struct TextFrames_UpdateMsg { /* Display_FrameMsg */
		INTEGER id;
		Texts_Text text;
		LONGINT beg, end;
	} TextFrames_UpdateMsg;


extern INTEGER TextFrames_menuH, TextFrames_barW, TextFrames_left, TextFrames_right, TextFrames_top, TextFrames_bot;
extern TextFrames_Parc TextFrames_defParc;

extern long *TextFrames_ParcDesc__typ;
extern long *TextFrames_Location__typ;
extern long *TextFrames_FrameDesc__typ;
extern long *TextFrames_DisplayMsg__typ;
extern long *TextFrames_TrackMsg__typ;
extern long *TextFrames_FocusMsg__typ;
extern long *TextFrames_NotifyMsg__typ;
extern long *TextFrames_UpdateMsg__typ;
extern long *TextFrames_InsertElemMsg__typ;

extern void TextFrames_Handle();
extern void TextFrames_LocateChar();
extern void TextFrames_LocateLine();
extern void TextFrames_LocatePos();
extern void TextFrames_LocateWord();
extern void TextFrames_Mark();
extern TextFrames_Frame TextFrames_NewMenu();
extern TextFrames_Frame TextFrames_NewText();
extern void TextFrames_NotifyDisplay();
extern void TextFrames_Open();
extern void TextFrames_ParcBefore();
extern LONGINT TextFrames_Pos();
extern void TextFrames_RemoveCaret();
extern void TextFrames_RemoveSelection();
extern void TextFrames_SetCaret();
extern void TextFrames_SetSelection();
extern void TextFrames_Show();
extern Texts_Text TextFrames_Text();
extern void TextFrames_TrackCaret();
extern void TextFrames_TrackLine();
extern void TextFrames_TrackSelection();
extern void TextFrames_TrackWord();
extern void *TextFrames__init();


#endif
