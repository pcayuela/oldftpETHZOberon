/* Ofront 1.1 */

#ifndef TextPreview__h
#define TextPreview__h

#include "SYSTEM.h"




extern void TextPreview_PageCount();
extern void TextPreview_Paginate();
extern void TextPreview_Synch();
extern void TextPreview_This();
extern void *TextPreview__init();


#endif
