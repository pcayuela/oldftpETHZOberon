/* Ofront 1.0 */

#ifndef TextPrinter__h
#define TextPrinter__h

#include "SYSTEM.h"
#include "Fonts.h"
#include "Texts.h"

typedef
	struct TextPrinter_PrintMsg { /* Texts_ElemMsg */
		BOOLEAN prepare;
		LONGINT indent;
		Fonts_Font fnt;
		SHORTINT col;
		LONGINT pos;
		INTEGER X0, Y0, pno;
	} TextPrinter_PrintMsg;



extern long *TextPrinter_PrintMsg__typ;

extern LONGINT TextPrinter_DX();
extern Fonts_Font TextPrinter_Font();
extern SHORTINT TextPrinter_FontNo();
extern void TextPrinter_Get();
extern void TextPrinter_GetChar();
extern void TextPrinter_InitFonts();
extern void TextPrinter_PlaceBody();
extern void TextPrinter_PlaceHeader();
extern void TextPrinter_PrintDraft();
extern void *TextPrinter__init();


#endif
