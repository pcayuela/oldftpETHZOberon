/* Ofront 1.0 */

#ifndef Kepler7__h
#define Kepler7__h

#include "SYSTEM.h"
#include "Display.h"
#include "KeplerFrames.h"
#include "KeplerGraphs.h"
#include "TextFrames.h"
#include "Texts.h"

typedef
	struct Kepler7_FrameDesc *Kepler7_Frame;

typedef
	struct Kepler7_TextDesc *Kepler7_Text;

typedef
	struct Kepler7_FrameDesc { /* TextFrames_FrameDesc */
		Display_Frame dsc, next;
		INTEGER X, Y, W, H;
		Display_Handler handle;
		Texts_Text text;
		LONGINT org;
		INTEGER col, left, right, top, bot, markH, barW;
		LONGINT time;
		BOOLEAN hasCar, hasSel, showsParcs;
		TextFrames_Location carloc, selbeg, selend;
		Display_Frame focus;
		char _prvt0[4];
		Kepler7_Text keplerText;
		KeplerGraphs_Graph graph;
	} Kepler7_FrameDesc;

typedef
	struct Kepler7_TextDesc { /* KeplerFrames_ButtonDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
		CHAR cmd[32], par[32];
		Texts_Text text;
	} Kepler7_TextDesc;

extern void Kepler7_Text_Draw();
extern void Kepler7_Text_HandleMouse();
extern void Kepler7_Text_Read();
extern void Kepler7_Text_Write();



extern long *Kepler7_TextDesc__typ;
extern long *Kepler7_FrameDesc__typ;

extern void Kepler7_NewText();
extern void Kepler7_Update();
extern void *Kepler7__init();


#endif
