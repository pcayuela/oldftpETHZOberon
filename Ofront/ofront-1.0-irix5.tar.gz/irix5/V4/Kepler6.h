/* Ofront 1.0 */

#ifndef Kepler6__h
#define Kepler6__h

#include "SYSTEM.h"
#include "KeplerGraphs.h"

typedef
	struct Kepler6_BezierDesc *Kepler6_Bezier;

typedef
	struct Kepler6_BezierDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
	} Kepler6_BezierDesc;

extern void Kepler6_Bezier_Draw();

typedef
	struct Kepler6_CRSplineDesc *Kepler6_CRSpline;

typedef
	struct Kepler6_CRSplineDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
	} Kepler6_CRSplineDesc;

extern void Kepler6_CRSpline_Draw();



extern long *Kepler6_CRSplineDesc__typ;
extern long *Kepler6_BezierDesc__typ;

extern void Kepler6_NewBezier();
extern void Kepler6_NewCRSpline();
extern void Kepler6_NewClosedBezier();
extern void Kepler6_NewClosedCRSpline();
extern void *Kepler6__init();


#endif
