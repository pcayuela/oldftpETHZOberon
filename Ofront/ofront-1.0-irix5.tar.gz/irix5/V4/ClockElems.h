/* Ofront 1.0 */

#ifndef ClockElems__h
#define ClockElems__h

#include "SYSTEM.h"




extern void ClockElems_Insert();
extern void ClockElems_New();
extern void *ClockElems__init();


#endif
