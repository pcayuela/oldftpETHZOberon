/* Ofront 1.0 */

#ifndef StyleElems__h
#define StyleElems__h

#include "SYSTEM.h"
#include "Fonts.h"
#include "TextFrames.h"
#include "Texts.h"

typedef
	CHAR StyleElems_Name[32];

typedef
	struct StyleElems_ParcDesc *StyleElems_Parc;

typedef
	struct StyleElems_ParcDesc { /* TextFrames_ParcDesc */
		char _prvt0[20];
		LONGINT W, H;
		Texts_Handler handle;
		char _prvt1[4];
		LONGINT left, first, width, lead, lsp, dsr;
		SET opts;
		INTEGER nofTabs;
		LONGINT tab[32];
		StyleElems_Name name;
		char _prvt2[4];
	} StyleElems_ParcDesc;

typedef
	struct StyleElems_UpdateMsg { /* Texts_ElemMsg */
		INTEGER id;
		LONGINT pos;
		StyleElems_Name name, newName;
		StyleElems_Parc parc;
	} StyleElems_UpdateMsg;


extern Fonts_Font StyleElems_font;

extern long *StyleElems_ParcDesc__typ;
extern long *StyleElems_UpdateMsg__typ;

extern void StyleElems_Alloc();
extern void StyleElems_Broadcast();
extern void StyleElems_ChangeName();
extern void StyleElems_ChangeSetting();
extern void StyleElems_Copy();
extern void StyleElems_Draw();
extern void StyleElems_Edit();
extern void StyleElems_Handle();
extern void StyleElems_Insert();
extern void StyleElems_Load();
extern void StyleElems_Prepare();
extern void StyleElems_Rename();
extern void StyleElems_RenameAll();
extern void StyleElems_Search();
extern void StyleElems_SetAttr();
extern void StyleElems_Store();
extern void StyleElems_Synch();
extern void *StyleElems__init();


#endif
