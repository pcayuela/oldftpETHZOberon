/* Ofront 1.0 */

#ifndef Input__h
#define Input__h

#include "SYSTEM.h"


extern LONGINT Input_TimeUnit;


extern INTEGER Input_Available();
extern void Input_Mouse();
extern void Input_Read();
extern void Input_SetMouseLimits();
extern LONGINT Input_Time();
extern void *Input__init();


#endif
