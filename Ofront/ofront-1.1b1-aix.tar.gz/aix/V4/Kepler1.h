/* Ofront 1.1 */

#ifndef Kepler1__h
#define Kepler1__h

#include "SYSTEM.h"
#include "Fonts.h"
#include "KeplerFrames.h"
#include "KeplerGraphs.h"

typedef
	struct Kepler1_AttrDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
		INTEGER width, a1, a2;
	} Kepler1_AttrDesc;

extern void Kepler1_AttrLine_Draw();
extern void Kepler1_AttrLine_Read();
extern void Kepler1_AttrLine_Write();

typedef
	Kepler1_AttrDesc *Kepler1_AttrLine;

typedef
	struct Kepler1_CircleDesc *Kepler1_Circle;

typedef
	struct Kepler1_CircleDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
	} Kepler1_CircleDesc;

extern void Kepler1_Circle_Draw();

typedef
	struct Kepler1_EllipseDesc *Kepler1_Ellipse;

typedef
	struct Kepler1_EllipseDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
	} Kepler1_EllipseDesc;

extern void Kepler1_Ellipse_Draw();

typedef
	struct Kepler1_H90ShapeDesc *Kepler1_H90Shape;

typedef
	struct Kepler1_H90ShapeDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
	} Kepler1_H90ShapeDesc;

extern void Kepler1_H90Shape_Draw();

typedef
	struct Kepler1_HShapeDesc *Kepler1_HShape;

typedef
	struct Kepler1_HShapeDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
	} Kepler1_HShapeDesc;

extern void Kepler1_HShape_Draw();

typedef
	struct Kepler1_LineDesc *Kepler1_Line;

typedef
	struct Kepler1_LineDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
	} Kepler1_LineDesc;

extern void Kepler1_Line_Draw();

typedef
	struct Kepler1_RectangleDesc *Kepler1_Rectangle;

typedef
	struct Kepler1_RectangleDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
	} Kepler1_RectangleDesc;

extern void Kepler1_Rectangle_Draw();

typedef
	struct Kepler1_StringDesc *Kepler1_String;

typedef
	struct Kepler1_StringDesc { /* KeplerFrames_CaptionDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
		CHAR s[128];
		Fonts_Font fnt;
		SHORTINT align;
	} Kepler1_StringDesc;

typedef
	struct Kepler1_TextureDesc *Kepler1_Texture;

typedef
	struct Kepler1_TextureDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
		INTEGER pat;
	} Kepler1_TextureDesc;

extern void Kepler1_Texture_Draw();
extern void Kepler1_Texture_Read();
extern void Kepler1_Texture_Write();

typedef
	struct Kepler1_TriangleDesc *Kepler1_Triangle;

typedef
	struct Kepler1_TriangleDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
		INTEGER pat;
	} Kepler1_TriangleDesc;

extern void Kepler1_Triangle_Draw();
extern void Kepler1_Triangle_Read();
extern void Kepler1_Triangle_Write();



extern long *Kepler1_RectangleDesc__typ;
extern long *Kepler1_TextureDesc__typ;
extern long *Kepler1_LineDesc__typ;
extern long *Kepler1_CircleDesc__typ;
extern long *Kepler1_EllipseDesc__typ;
extern long *Kepler1_StringDesc__typ;
extern long *Kepler1_HShapeDesc__typ;
extern long *Kepler1_H90ShapeDesc__typ;
extern long *Kepler1_AttrDesc__typ;
extern long *Kepler1_TriangleDesc__typ;

extern void Kepler1_ChangeAlign();
extern void Kepler1_ChangeAttrLine();
extern void Kepler1_ChangeFont();
extern void Kepler1_GetAttrLine();
extern void Kepler1_NewAttrLine();
extern void Kepler1_NewCircle();
extern void Kepler1_NewEllipse();
extern void Kepler1_NewH90Shape();
extern void Kepler1_NewHShape();
extern void Kepler1_NewLine();
extern void Kepler1_NewRectangle();
extern void Kepler1_NewString();
extern void Kepler1_NewTexture();
extern void Kepler1_NewTriangle();
extern void *Kepler1__init();


#endif
