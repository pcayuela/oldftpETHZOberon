/* Ofront 1.1 */

#ifndef ParcElems__h
#define ParcElems__h

#include "SYSTEM.h"
#include "TextFrames.h"
#include "Texts.h"

typedef
	struct ParcElems_StateMsg { /* Texts_ElemMsg */
		INTEGER id;
		LONGINT pos;
		TextFrames_Frame frame;
		Texts_Scanner par;
		Texts_Text log;
	} ParcElems_StateMsg;



extern long *ParcElems_StateMsg__typ;

extern void ParcElems_Alloc();
extern void ParcElems_ChangedParc();
extern void ParcElems_CopyParc();
extern void ParcElems_Draw();
extern void ParcElems_Edit();
extern void ParcElems_GetAttr();
extern void ParcElems_Handle();
extern void ParcElems_LoadParc();
extern void ParcElems_ParcExtent();
extern void ParcElems_Prepare();
extern void ParcElems_SetAttr();
extern void ParcElems_StoreParc();
extern void *ParcElems__init();


#endif
