/* Ofront 1.1 */

#ifndef Fonts__h
#define Fonts__h

#include "SYSTEM.h"
#include "Display.h"

typedef
	struct Fonts_FontDesc *Fonts_Font;

typedef
	CHAR Fonts_Name[32];

typedef
	struct Fonts_FontDesc {
		Fonts_Name name;
		INTEGER height, minX, maxX, minY, maxY;
		Display_Font raster;
		char _prvt0[4];
	} Fonts_FontDesc;


extern Fonts_Font Fonts_Default;

extern long *Fonts_FontDesc__typ;

extern Fonts_Font Fonts_This();
extern void *Fonts__init();


#endif
