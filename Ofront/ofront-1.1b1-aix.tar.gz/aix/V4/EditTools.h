/* Ofront 1.1 */

#ifndef EditTools__h
#define EditTools__h

#include "SYSTEM.h"
#include "TextFrames.h"




extern void EditTools_Change();
extern void EditTools_ChangeFamily();
extern void EditTools_ChangeFont();
extern void EditTools_ChangeFontFamily();
extern void EditTools_ChangeFontSize();
extern void EditTools_ChangeFontStyle();
extern void EditTools_ChangeSize();
extern void EditTools_ChangeStyle();
extern void EditTools_Cleanup();
extern void EditTools_ConvertToAscii();
extern void EditTools_Count();
extern void EditTools_DeleteElems();
extern void EditTools_DeleteMonsters();
extern void EditTools_GetAttr();
extern void EditTools_IncFontSize();
extern void EditTools_IncSize();
extern void EditTools_InsertCR();
extern void EditTools_LocateLine();
extern void EditTools_Refresh();
extern void EditTools_RemoveCR();
extern void EditTools_RemoveElems();
extern void EditTools_SearchAttr();
extern void EditTools_SearchDiff();
extern TextFrames_Frame EditTools_SelectedFrame();
extern void EditTools_ShowAliens();
extern void EditTools_StoreAscii();
extern void EditTools_ToAscii();
extern void EditTools_UnmarkMenu();
extern void EditTools_Words();
extern void *EditTools__init();


#endif
