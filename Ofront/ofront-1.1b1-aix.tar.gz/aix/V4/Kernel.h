/* Ofront 1.1 */

#ifndef Kernel__h
#define Kernel__h

#include "SYSTEM.h"
#include "Unix.h"

typedef
	void (*Kernel_KeyCmd)();

typedef
	void (*Kernel_ObjFinalizer)();


extern Unix_MSTsave Kernel_trapEnv;
extern LONGINT Kernel_nofiles;
extern Unix_FdSet Kernel_readSet, Kernel_readySet;
extern Kernel_KeyCmd Kernel_FKey[16];
extern BOOLEAN Kernel_littleEndian;
extern LONGINT Kernel_TimeUnit;
extern CHAR Kernel_LIB[256], Kernel_CWD[256];
extern CHAR Kernel_OBERON[1024];


extern void Kernel_GetClock();
extern void Kernel_InstallTermHandler();
extern LONGINT Kernel_LargestAvailable();
extern void Kernel_Select();
extern void Kernel_SetClock();
extern LONGINT Kernel_Time();
extern void *Kernel__init();

#define Kernel_Exit(n)	exit(n)
#define Kernel_GC(markStack)	SYSTEM_GC(markStack)
#define Kernel_Lock()	SYSTEM_lock++
#define Kernel_RegisterObject(obj, finalize)	SYSTEM_REGFIN(obj, finalize)
#define Kernel_SetHalt(p)	SYSTEM_Halt = p
#define Kernel_Unlock()	SYSTEM_lock--; if (SYSTEM_interrupted && SYSTEM_lock == 0) __HALT(-9)
#define Kernel_allocated()	SYSTEM_allocated
#define Kernel_free(adr)	(void)free(adr)
#define Kernel_heapsize()	SYSTEM_heapsize
#define Kernel_malloc(size)	(LONGINT)malloc(size)
#define Kernel_siglongjmp(env, env__typ, val)	siglongjmp(env, val)
#define Kernel_sigsetjmp(env, env__typ, savemask)	sigsetjmp(env, savemask)

#endif
