/* Ofront 1.1 */

#ifndef Kepler5__h
#define Kepler5__h

#include "SYSTEM.h"
#include "KeplerGraphs.h"

typedef
	struct Kepler5_StarDesc *Kepler5_FocusStar;

typedef
	struct Kepler5_StarDesc2 *Kepler5_FocusStar2;

typedef
	struct Kepler5_PlanetDesc *Kepler5_Planet;

typedef
	struct Kepler5_PlanetDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
	} Kepler5_PlanetDesc;

extern void Kepler5_Planet_Draw();

typedef
	struct Kepler5_SelStarDesc *Kepler5_SelStar;

typedef
	struct Kepler5_SelStarDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
	} Kepler5_SelStarDesc;

extern void Kepler5_SelStar_Draw();

typedef
	struct Kepler5_StarDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
	} Kepler5_StarDesc;

extern void Kepler5_FocusStar_Draw();

typedef
	struct Kepler5_StarDesc2 { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
	} Kepler5_StarDesc2;

extern void Kepler5_FocusStar2_Draw();



extern long *Kepler5_StarDesc__typ;
extern long *Kepler5_StarDesc2__typ;
extern long *Kepler5_SelStarDesc__typ;
extern long *Kepler5_PlanetDesc__typ;

extern void Kepler5_NewFocusStar();
extern void Kepler5_NewFocusStar2();
extern void Kepler5_NewPlanet();
extern void Kepler5_NewSelStar();
extern void *Kepler5__init();


#endif
