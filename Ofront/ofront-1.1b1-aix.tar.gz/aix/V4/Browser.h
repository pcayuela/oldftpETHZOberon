/* Ofront 1.1 */

#ifndef Browser__h
#define Browser__h

#include "SYSTEM.h"




extern void Browser_ShowDef();
extern void *Browser__init();


#endif
