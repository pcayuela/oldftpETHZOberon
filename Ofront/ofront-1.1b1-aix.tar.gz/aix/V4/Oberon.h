/* Ofront 1.1 */

#ifndef Oberon__h
#define Oberon__h

#include "SYSTEM.h"
#include "Display.h"
#include "Fonts.h"
#include "Texts.h"
#include "Viewers.h"

typedef
	struct Oberon_ControlMsg { /* Display_FrameMsg */
		INTEGER id, X, Y;
	} Oberon_ControlMsg;

typedef
	struct Oberon_CopyMsg { /* Display_FrameMsg */
		Display_Frame F;
	} Oberon_CopyMsg;

typedef
	struct Oberon_CopyOverMsg { /* Display_FrameMsg */
		Texts_Text text;
		LONGINT beg, end;
	} Oberon_CopyOverMsg;

typedef
	void (*Oberon_Painter)();

typedef
	struct Oberon_Marker {
		Oberon_Painter Fade, Draw;
	} Oberon_Marker;

typedef
	struct Oberon_Cursor {
		Oberon_Marker marker;
		BOOLEAN on;
		INTEGER X, Y;
	} Oberon_Cursor;

typedef
	void (*Oberon_Handler)();

typedef
	struct Oberon_InputMsg { /* Display_FrameMsg */
		INTEGER id;
		SET keys;
		INTEGER X, Y;
		CHAR ch;
		Fonts_Font fnt;
		SHORTINT col, voff;
	} Oberon_InputMsg;

typedef
	struct Oberon_ParRec *Oberon_ParList;

typedef
	struct Oberon_ParRec {
		Viewers_Viewer vwr;
		Display_Frame frame;
		Texts_Text text;
		LONGINT pos;
	} Oberon_ParRec;

typedef
	struct Oberon_SelectionMsg { /* Display_FrameMsg */
		LONGINT time;
		Texts_Text text;
		LONGINT beg, end;
	} Oberon_SelectionMsg;

typedef
	struct Oberon_TaskDesc *Oberon_Task;

typedef
	struct Oberon_TaskDesc {
		LONGINT _prvt0;
		BOOLEAN safe;
		LONGINT time;
		Oberon_Handler handle;
	} Oberon_TaskDesc;


extern CHAR Oberon_User[12];
extern Oberon_Marker Oberon_Arrow, Oberon_Star;
extern Oberon_Cursor Oberon_Mouse, Oberon_Pointer;
extern Viewers_Viewer Oberon_FocusViewer;
extern Texts_Text Oberon_Log;
extern Oberon_ParList Oberon_Par;
extern Oberon_Task Oberon_CurTask;
extern Fonts_Font Oberon_CurFnt;
extern SHORTINT Oberon_CurCol, Oberon_CurOff;
extern LONGINT Oberon_Password;

extern long *Oberon_Marker__typ;
extern long *Oberon_Cursor__typ;
extern long *Oberon_ParRec__typ;
extern long *Oberon_InputMsg__typ;
extern long *Oberon_SelectionMsg__typ;
extern long *Oberon_ControlMsg__typ;
extern long *Oberon_CopyOverMsg__typ;
extern long *Oberon_CopyMsg__typ;
extern long *Oberon_TaskDesc__typ;

extern void Oberon_AllocateSystemViewer();
extern void Oberon_AllocateUserViewer();
extern void Oberon_Call();
extern void Oberon_Collect();
extern INTEGER Oberon_DisplayHeight();
extern INTEGER Oberon_DisplayWidth();
extern void Oberon_DrawCursor();
extern void Oberon_FadeCursor();
extern void Oberon_GetClock();
extern void Oberon_GetSelection();
extern void Oberon_Install();
extern void Oberon_Loop();
extern Viewers_Viewer Oberon_MarkedViewer();
extern void Oberon_OpenCursor();
extern void Oberon_OpenDisplay();
extern void Oberon_OpenTrack();
extern void Oberon_PassFocus();
extern void Oberon_Remove();
extern void Oberon_RemoveMarks();
extern void Oberon_SetClock();
extern void Oberon_SetColor();
extern void Oberon_SetFont();
extern void Oberon_SetOffset();
extern void Oberon_SetUser();
extern INTEGER Oberon_SystemTrack();
extern LONGINT Oberon_Time();
extern INTEGER Oberon_UserTrack();
extern void *Oberon__init();


#endif
