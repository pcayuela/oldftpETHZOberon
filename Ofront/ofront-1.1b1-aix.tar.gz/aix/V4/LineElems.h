/* Ofront 1.1 */

#ifndef LineElems__h
#define LineElems__h

#include "SYSTEM.h"
#include "Texts.h"

typedef
	struct LineElems_ElemDesc *LineElems_Elem;

typedef
	struct LineElems_ElemDesc { /* Texts_ElemDesc */
		char _prvt0[20];
		LONGINT W, H;
		Texts_Handler handle;
		char _prvt1[4];
		SET opts;
		char _prvt2[4];
	} LineElems_ElemDesc;



extern long *LineElems_ElemDesc__typ;

extern void LineElems_Alloc();
extern void LineElems_Copy();
extern void LineElems_Draw();
extern void LineElems_Handle();
extern void LineElems_Insert();
extern void LineElems_Load();
extern void LineElems_Prepare();
extern void LineElems_Print();
extern void LineElems_Store();
extern void *LineElems__init();


#endif
