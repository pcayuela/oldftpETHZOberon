/* Ofront 1.1 */

#ifndef Types__h
#define Types__h

#include "SYSTEM.h"
#include "Modules.h"

typedef
	struct Types_TypeDesc *Types_Type;

typedef
	struct Types_TypeDesc {
		char _prvt0[8];
		Modules_Module module;
		CHAR name[24];
		char _prvt1[72];
	} Types_TypeDesc;



extern long *Types_TypeDesc__typ;

extern Types_Type Types_BaseOf();
extern INTEGER Types_LevelOf();
extern void Types_NewObj();
extern Types_Type Types_This();
extern Types_Type Types_TypeOf();
extern void *Types__init();


#endif
