/* Ofront 1.1 */

#ifndef TextPFrames__h
#define TextPFrames__h

#include "SYSTEM.h"
#include "Display.h"
#include "TextFrames.h"
#include "Texts.h"

typedef
	struct TextPFrames_FrameDesc *TextPFrames_Frame;

typedef
	struct TextPFrames_Location {
		LONGINT org, pos;
		INTEGER x, y, dx, dy;
		char _prvt0[5];
	} TextPFrames_Location;

typedef
	struct TextPFrames_FrameDesc { /* TextFrames_FrameDesc */
		Display_Frame dsc, next;
		INTEGER X, Y, W, H;
		Display_Handler handle;
		Texts_Text text;
		LONGINT org;
		INTEGER col, left, right, top, bot, markH, barW;
		LONGINT time;
		BOOLEAN hasCar, hasSel, showsParcs;
		TextFrames_Location carloc, selbeg, selend;
		Display_Frame focus;
		char _prvt0[4];
		TextPFrames_Location CarLoc, SelBeg, SelEnd;
		char _prvt1[4108];
	} TextPFrames_FrameDesc;



extern long *TextPFrames_Location__typ;
extern long *TextPFrames_FrameDesc__typ;

extern void TextPFrames_BegOfLine();
extern void TextPFrames_Call();
extern void TextPFrames_Copy();
extern void TextPFrames_Edit();
extern void TextPFrames_GetPagination();
extern void TextPFrames_Handle();
extern void TextPFrames_LocateChar();
extern void TextPFrames_LocateLine();
extern void TextPFrames_LocatePage();
extern void TextPFrames_LocatePos();
extern void TextPFrames_LocateWord();
extern void TextPFrames_Neutralize();
extern TextPFrames_Frame TextPFrames_NewText();
extern void TextPFrames_NotifyElems();
extern void TextPFrames_Open();
extern void TextPFrames_PassSubFocus();
extern LONGINT TextPFrames_Pos();
extern void TextPFrames_RemoveCaret();
extern void TextPFrames_RemoveSelection();
extern void TextPFrames_Resize();
extern void TextPFrames_SetCaret();
extern void TextPFrames_SetPagination();
extern void TextPFrames_SetSelection();
extern void TextPFrames_Show();
extern Display_Frame TextPFrames_ThisSubFrame();
extern void TextPFrames_TouchElem();
extern void TextPFrames_TrackCaret();
extern void TextPFrames_TrackLine();
extern void TextPFrames_TrackSelection();
extern void TextPFrames_TrackWord();
extern void TextPFrames_Update();
extern void TextPFrames_Write();
extern void *TextPFrames__init();


#endif
