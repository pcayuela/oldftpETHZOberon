/* Ofront 1.1 */

#ifndef FontToBDF__h
#define FontToBDF__h

#include "SYSTEM.h"




extern void FontToBDF_Convert();
extern void *FontToBDF__init();


#endif
