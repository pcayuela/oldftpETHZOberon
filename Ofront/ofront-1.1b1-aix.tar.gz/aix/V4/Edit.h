/* Ofront 1.1 */

#ifndef Edit__h
#define Edit__h

#include "SYSTEM.h"




extern void Edit_ChangeBackgroundColor();
extern void Edit_ChangeColor();
extern void Edit_ChangeFont();
extern void Edit_ChangeOffset();
extern void Edit_ClearReplaceBuffer();
extern void Edit_Get();
extern void Edit_InsertParc();
extern void Edit_Locate();
extern void Edit_Open();
extern void Edit_Parcs();
extern void Edit_Print();
extern void Edit_Recall();
extern void Edit_Replace();
extern void Edit_ReplaceAll();
extern void Edit_Search();
extern void Edit_Set();
extern void Edit_Show();
extern void Edit_Store();
extern void *Edit__init();


#endif
