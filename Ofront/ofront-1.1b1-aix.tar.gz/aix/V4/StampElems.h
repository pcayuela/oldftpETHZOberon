/* Ofront 1.1 */

#ifndef StampElems__h
#define StampElems__h

#include "SYSTEM.h"




extern void StampElems_Alloc();
extern void StampElems_Insert();
extern void *StampElems__init();


#endif
