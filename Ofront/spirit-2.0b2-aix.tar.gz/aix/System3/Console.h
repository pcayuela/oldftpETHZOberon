/* Ofront 1.1 */

#ifndef Console__h
#define Console__h

#include "SYSTEM.h"




extern void Console_Bool();
extern void Console_Char();
extern void Console_Hex();
extern void Console_Int();
extern void Console_Ln();
extern void Console_String();
extern void *Console__init();


#endif
