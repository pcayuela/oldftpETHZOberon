/* Ofront 1.1 */

#ifndef FileDir__h
#define FileDir__h

#include "SYSTEM.h"

typedef
	void (*FileDir_EntryHandler)();

typedef
	void (*FileDir_FileEnumerator)();

typedef
	CHAR FileDir_FileName[64];


extern CHAR FileDir_PathChar;


extern void FileDir_Enumerate();
extern void FileDir_EnumerateFiles();
extern void FileDir_GetWorkingDirectory();
extern void FileDir_RelFileName();
extern BOOLEAN FileDir_SpecialChar();
extern void *FileDir__init();


#endif
