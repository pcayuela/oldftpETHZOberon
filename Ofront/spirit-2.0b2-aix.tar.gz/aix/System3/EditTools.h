/* Ofront 1.1 */

#ifndef EditTools__h
#define EditTools__h

#include "SYSTEM.h"




extern void EditTools_Change();
extern void EditTools_ChangeFamily();
extern void EditTools_ChangeFont();
extern void EditTools_ChangeFontFamily();
extern void EditTools_ChangeFontSize();
extern void EditTools_ChangeFontStyle();
extern void EditTools_ChangeSize();
extern void EditTools_ChangeStyle();
extern void EditTools_IncFontSize();
extern void EditTools_IncSize();
extern void EditTools_OpenAscii();
extern void EditTools_OpenUnix();
extern void EditTools_RemoveObjects();
extern void EditTools_StoreAscii();
extern void EditTools_StoreUnix();
extern void *EditTools__init();


#endif
