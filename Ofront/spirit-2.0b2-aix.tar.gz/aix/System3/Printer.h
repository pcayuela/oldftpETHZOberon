/* Ofront 1.1 */

#ifndef Printer__h
#define Printer__h

#include "SYSTEM.h"

typedef
	struct Printer_PrinterDesc *Printer_Printer;

typedef
	struct Printer_PrinterDesc {
		INTEGER res, Height, Width, Depth, FrameX, FrameY, FrameW, FrameH;
		LONGINT Unit;
		void (*InitMetrics)();
		void (*Open)();
		void (*Close)();
		void (*Page)();
		void (*ReplConst)();
		void (*ReplPattern)();
		void (*Line)();
		void (*Circle)();
		void (*Ellipse)();
		void (*Spline)();
		void (*Picture)();
		void (*UseListFont)();
		void (*String)();
		void (*ContString)();
		void (*UseColor)();
	} Printer_PrinterDesc;


extern INTEGER Printer_Height, Printer_Width, Printer_Depth, Printer_FrameX, Printer_FrameY, Printer_FrameW, Printer_FrameH;
extern LONGINT Printer_Unit;
extern INTEGER Printer_res;
extern Printer_Printer Printer_current;

extern long *Printer_PrinterDesc__typ;

extern void Printer_Circle();
extern void Printer_Close();
extern void Printer_ContString();
extern void Printer_Ellipse();
extern void Printer_Install();
extern void Printer_Line();
extern void Printer_Open();
extern void Printer_Page();
extern void Printer_Picture();
extern void Printer_ReplConst();
extern void Printer_ReplPattern();
extern void Printer_Spline();
extern void Printer_String();
extern void Printer_UseColor();
extern void Printer_UseListFont();
extern void *Printer__init();


#endif
