/* Ofront 1.1 */

#ifndef Attributes__h
#define Attributes__h

#include "SYSTEM.h"
#include "Objects.h"
#include "Texts.h"

typedef
	struct Attributes_AttrDesc *Attributes_Attr;

typedef
	struct Attributes_AttrDesc {
		Attributes_Attr next;
		CHAR name[32];
	} Attributes_AttrDesc;

typedef
	struct Attributes_BoolDesc *Attributes_BoolAttr;

typedef
	struct Attributes_BoolDesc { /* Attributes_AttrDesc */
		Attributes_Attr next;
		CHAR name[32];
		BOOLEAN b;
	} Attributes_BoolDesc;

typedef
	struct Attributes_CharDesc *Attributes_CharAttr;

typedef
	struct Attributes_CharDesc { /* Attributes_AttrDesc */
		Attributes_Attr next;
		CHAR name[32];
		CHAR c;
	} Attributes_CharDesc;

typedef
	struct Attributes_IntDesc *Attributes_IntAttr;

typedef
	struct Attributes_IntDesc { /* Attributes_AttrDesc */
		Attributes_Attr next;
		CHAR name[32];
		LONGINT i;
	} Attributes_IntDesc;

typedef
	void (*Attributes_MacroHandler)();

typedef
	struct Attributes_ReaderDesc *Attributes_Reader;

typedef
	struct Attributes_ReaderDesc {
		BOOLEAN substitute;
		Texts_Text text;
		BOOLEAN eot;
		char _prvt0[51];
	} Attributes_ReaderDesc;

typedef
	struct Attributes_RealDesc *Attributes_RealAttr;

typedef
	struct Attributes_RealDesc { /* Attributes_AttrDesc */
		Attributes_Attr next;
		CHAR name[32];
		LONGREAL r;
	} Attributes_RealDesc;

typedef
	struct Attributes_Scanner {
		Attributes_Reader R;
		BOOLEAN eot;
		CHAR nextCh;
		INTEGER class;
		LONGINT i;
		REAL x;
		LONGREAL y;
		CHAR c;
		SHORTINT len;
		CHAR s[128];
		Objects_Object o;
	} Attributes_Scanner;

typedef
	struct Attributes_StringDesc *Attributes_StringAttr;

typedef
	struct Attributes_StringDesc { /* Attributes_AttrDesc */
		Attributes_Attr next;
		CHAR name[32];
		CHAR s[64];
	} Attributes_StringDesc;



extern long *Attributes_ReaderDesc__typ;
extern long *Attributes_Scanner__typ;
extern long *Attributes_AttrDesc__typ;
extern long *Attributes_BoolDesc__typ;
extern long *Attributes_CharDesc__typ;
extern long *Attributes_IntDesc__typ;
extern long *Attributes_RealDesc__typ;
extern long *Attributes_StringDesc__typ;

extern void Attributes_AddMacro();
extern void Attributes_BoolToStr();
extern void Attributes_CopyAttributes();
extern void Attributes_DeleteAttr();
extern Attributes_Attr Attributes_FindAttr();
extern void Attributes_InsertAttr();
extern void Attributes_IntToStr();
extern void Attributes_LoadAttributes();
extern void Attributes_OpenReader();
extern void Attributes_OpenScanner();
extern LONGINT Attributes_Pos();
extern void Attributes_Read();
extern void Attributes_RealToStr();
extern void Attributes_Scan();
extern void Attributes_StoreAttributes();
extern void Attributes_StrToBool();
extern void Attributes_StrToInt();
extern void Attributes_StrToReal();
extern void Attributes_StrToTxt();
extern void Attributes_TxtToStr();
extern void Attributes_WriteAttr();
extern void *Attributes__init();


#endif
