/* Ofront 1.1 */

#ifndef BookCompiler__h
#define BookCompiler__h

#include "SYSTEM.h"




extern void BookCompiler_Browse();
extern void BookCompiler_Compile();
extern void BookCompiler_InsertCmd();
extern void BookCompiler_NewTextDoc();
extern void *BookCompiler__init();


#endif
