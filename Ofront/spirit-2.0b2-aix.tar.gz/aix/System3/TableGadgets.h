/* Ofront 1.1 */

#ifndef TableGadgets__h
#define TableGadgets__h

#include "SYSTEM.h"
#include "Display.h"
#include "Display3.h"
#include "Objects.h"
#include "Panels.h"
#include "Texts.h"

typedef
	struct TableGadgets_CellDesc *TableGadgets_Cell;

typedef
	struct TableGadgets_CellDesc {
		LONGINT pos, len;
		INTEGER rows, cols;
		char _prvt0[4];
		SET mode;
		char _prvt1[4];
		TableGadgets_Cell next;
	} TableGadgets_CellDesc;

typedef
	struct TableGadgets_FrameDesc *TableGadgets_Frame;

typedef
	struct TableGadgets_FrameDesc { /* Panels_PanelDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		BOOLEAN focused;
		INTEGER focusx, focusy;
		LONGINT time;
		Display3_Mask back;
		INTEGER rx, ry, rr, rt, borderW;
		Panels_Methods do_;
		SET state0;
		INTEGER grid, col;
		Pictures_Picture pict;
		BOOLEAN update;
		char _prvt0[7];
	} TableGadgets_FrameDesc;

typedef
	struct TableGadgets_RowDesc *TableGadgets_Row;

typedef
	struct TableGadgets_RowDesc {
		TableGadgets_Cell cells;
		TableGadgets_Row next;
		char _prvt0[2];
	} TableGadgets_RowDesc;

typedef
	struct TableGadgets_TableDesc *TableGadgets_Table;

typedef
	struct TableGadgets_TableDesc {
		TableGadgets_Row rows;
		char _prvt0[4];
		Texts_Text text;
		LONGINT cappos, caplen;
		char _prvt1[4];
		SET mode;
		INTEGER col;
	} TableGadgets_TableDesc;



extern long *TableGadgets_CellDesc__typ;
extern long *TableGadgets_RowDesc__typ;
extern long *TableGadgets_TableDesc__typ;
extern long *TableGadgets_FrameDesc__typ;

extern void TableGadgets_CopyFrame();
extern void TableGadgets_Create();
extern void TableGadgets_FrameHandler();
extern void TableGadgets_InitFrame();
extern void TableGadgets_LinkTable();
extern void TableGadgets_NewFrame();
extern void *TableGadgets__init();


#endif
