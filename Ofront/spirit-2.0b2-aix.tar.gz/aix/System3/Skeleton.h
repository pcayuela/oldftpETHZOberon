/* Ofront 1.1 */

#ifndef Skeleton__h
#define Skeleton__h

#include "SYSTEM.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Objects.h"

typedef
	struct Skeleton_FrameDesc *Skeleton_Frame;

typedef
	struct Skeleton_FrameDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		INTEGER col;
	} Skeleton_FrameDesc;



extern long *Skeleton_FrameDesc__typ;

extern void Skeleton_Copy();
extern void Skeleton_Handle();
extern void Skeleton_Init();
extern void Skeleton_New();
extern void *Skeleton__init();


#endif
