/* Ofront 1.1 */

#ifndef Cups__h
#define Cups__h

#include "SYSTEM.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Objects.h"

typedef
	struct Cups_CupDesc *Cups_Cup;

typedef
	struct Cups_CupDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		INTEGER coffee;
	} Cups_CupDesc;



extern long *Cups_CupDesc__typ;

extern void Cups_CopyCup();
extern void Cups_CupHandler();
extern void Cups_NewCup();
extern void *Cups__init();


#endif
