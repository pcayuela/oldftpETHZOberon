/* Ofront 1.1 */

#ifndef Unix__h
#define Unix__h

#include "SYSTEM.h"

typedef
	struct Unix_AdSpace {
		LONGINT alloc;
		LONGINT srval[16];
	} Unix_AdSpace;

typedef
	struct Unix_Dirent {
		LONGINT off, fileno;
		INTEGER reclen, namelen;
		CHAR name[256];
	} Unix_Dirent;

typedef
	SET Unix_FdSet[8];

typedef
	struct Unix_Flock {
		INTEGER type, whence;
		LONGINT start, len;
		INTEGER pidext;
		LONGINT vfs;
	} Unix_Flock;

typedef
	struct Unix_Hostent *Unix_HostEntry;

typedef
	struct Unix_Hostent {
		LONGINT name, aliases, addrtype, length, addrlist;
	} Unix_Hostent;

typedef
	struct Unix_MSTsave *Unix_MSTsavePtr;

typedef
	struct Unix_Label *Unix_LabelPtr;

typedef
	struct Unix_MSTsave {
		Unix_MSTsavePtr prev;
		Unix_LabelPtr kjmpbuf;
		LONGINT stackfix;
		CHAR intpri, backt;
		LONGINT curid, excpType, iar, msr, cr, lr, ctr, xer, mq, tid, fpscr;
		CHAR fpeu;
		LONGINT except[5];
		LONGINT bus, oiar, otoc, oarg1, excbranch;
		char _prvt0[36];
		Unix_AdSpace as;
		LONGINT gpr[32];
		LONGREAL fpr[32];
	} Unix_MSTsave;

typedef
	struct Unix_Label {
		Unix_LabelPtr prev;
		LONGINT iar, stack, toc, cr, intpri;
		LONGINT reg[19];
	} Unix_Label;

typedef
	CHAR *Unix_Name;

typedef
	struct Unix_Timeval {
		LONGINT sec, usec;
	} Unix_Timeval;

typedef
	struct Unix_Rusage {
		Unix_Timeval utime, stime;
		LONGINT maxrss, ixrss, ismrss, idrss, isrss, minflt, majflt, nswap, inblock, oublock, msgsnd, msgrcv, nsignals, nvcsw, nivcsw;
	} Unix_Rusage;

typedef
	void (*Unix_SignalHandler)();

typedef
	struct Unix_SigSet {
		SET losigs, hisigs;
	} Unix_SigSet;

typedef
	struct Unix_SigAction {
		Unix_SignalHandler handler;
		Unix_SigSet mask;
		SET flags;
	} Unix_SigAction;

typedef
	Unix_SigAction *Unix_SigActionPtr;

typedef
	struct Unix_SigContext {
		LONGINT onstack;
		Unix_SigSet mask;
		LONGINT uerror;
		Unix_MSTsave jmpbuf;
	} Unix_SigContext;

typedef
	Unix_SigContext *Unix_SigCtxPtr;

typedef
	struct Unix_SigStack {
		LONGINT sp, onstack;
	} Unix_SigStack;

typedef
	struct Unix_Sockaddr {
		INTEGER family, port;
		LONGINT internetAddr;
		CHAR pad[8];
	} Unix_Sockaddr;

typedef
	LONGINT Unix_SocketPair[2];

typedef
	struct Unix_Status {
		LONGINT dev, ino, mode;
		INTEGER nlink;
		LONGINT uid, gid, rdev, size, atime;
		char _prvt0[4];
		LONGINT mtime;
		char _prvt1[4];
		LONGINT ctime;
		char _prvt2[4];
		LONGINT blksize, blocks, vfstype, vfs, type, gen, flag;
		char _prvt3[8];
		INTEGER access;
		LONGINT spare4[5];
	} Unix_Status;

typedef
	struct Unix_Timezone {
		LONGINT minuteswest, dsttime;
	} Unix_Timezone;



extern long *Unix_Status__typ;
extern long *Unix_Flock__typ;
extern long *Unix_Timeval__typ;
extern long *Unix_Timezone__typ;
extern long *Unix_SigStack__typ;
extern long *Unix_SigSet__typ;
extern long *Unix_Label__typ;
extern long *Unix_AdSpace__typ;
extern long *Unix_MSTsave__typ;
extern long *Unix_SigContext__typ;
extern long *Unix_SigAction__typ;
extern long *Unix_Dirent__typ;
extern long *Unix_Rusage__typ;
extern long *Unix_Sockaddr__typ;
extern long *Unix_Hostent__typ;

extern LONGINT Unix_Gethostname();
extern LONGINT Unix_errno();
extern void *Unix__init();

#define Unix_Accept(socket, addr, addr__typ, addrlen)	accept(socket, addr, addrlen)
#define Unix_Bind(socket, name, namelen)	bind(socket, &(name), namelen)
#define Unix_Chdir(path, path__len)	chdir(path)
#define Unix_Chmod(path, path__len, mode)	chmod(path, mode)
#define Unix_Close(fd)	close(fd)
#define Unix_Connect(socket, name, namelen)	connect(socket, &(name), namelen)
#define Unix_Dup(fd)	dup(fd)
#define Unix_Dup2(fd1, fd2)	dup(fd1, fd2)
#define Unix_Exit(n)	exit(n)
#define Unix_Fchmod(fd, mode)	fchmod(fd, mode)
#define Unix_Fstat(fd, statbuf, statbuf__typ)	fstat(fd, statbuf)
#define Unix_Fsync(fd)	fsync(fd)
#define Unix_Ftruncate(fd, length)	ftruncate(fd, length)
#define Unix_Getegid()	getegid()
#define Unix_Geteuid()	geteuid()
#define Unix_Getgid()	getgid()
#define Unix_Gethostbyname(name, name__len)	(Unix_HostEntry)gethostbyname(name)
#define Unix_Getpid()	getpid()
#define Unix_Getsockname(socket, name, name__typ, namelen)	getsockname(socket, name, namelen)
#define Unix_Gettimeofday(tv, tv__typ, tz, tz__typ)	gettimeofday(tv, tz)
#define Unix_Getuid()	getuid()
#define Unix_Ioctl(fd, request, arg)	ioctl(fd, request, arg)
#define Unix_Kill(pid, sig)	kill(pid, sig)
#define Unix_Listen(socket, backlog)	listen(socket, backlog)
#define Unix_Lockfx(fd, operation, flock, flock__typ)	flock(fd, operation)
#define Unix_Lseek(fd, offset, origin)	lseek(fd, offset, origin)
#define Unix_Open(name, name__len, flag, mode)	open(name, flag, mode)
#define Unix_Read(fd, buf, nbyte)	read(fd, buf, nbyte)
#define Unix_ReadBlk(fd, buf, buf__len)	read(fd, buf, buf__len)
#define Unix_Readblk(fd, buf, buf__len, len)	read(fd, buf, len)
#define Unix_Recv(socket, bufadr, buflen, flags)	recv(socket, bufadr, buflen, flags)
#define Unix_Rename(old, old__len, new, new__len)	rename(old, new)
#define Unix_Select(width, readfds, writefds, exceptfds, timeout, timeout__typ)	select(width, readfds, writefds, exceptfds, timeout)
#define Unix_Send(socket, bufadr, buflen, flags)	send(socket, bufadr, buflen, flags)
#define Unix_Sigsetmask(mask)	sigsetmask(mask)
#define Unix_Socket(af, type, protocol)	socket(af, type, protocol)
#define Unix_Stat(name, name__len, statbuf, statbuf__typ)	stat(name, statbuf)
#define Unix_Unlink(name, name__len)	unlink(name)
#define Unix_Write(fd, buf, nbyte)	write(fd, buf, nbyte)
#define Unix_WriteBlk(fd, buf, buf__len)	write(fd, buf, buf__len)

#endif
