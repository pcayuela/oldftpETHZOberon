/* Ofront 1.1 */

#ifndef NamePlates__h
#define NamePlates__h

#include "SYSTEM.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Objects.h"

typedef
	struct NamePlates_NamePlateDesc *NamePlates_NamePlate;

typedef
	struct NamePlates_NamePlateDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		char _prvt0[14];
		CHAR val[128];
		char _prvt1[2];
	} NamePlates_NamePlateDesc;



extern long *NamePlates_NamePlateDesc__typ;

extern void NamePlates_CopyNamePlate();
extern void NamePlates_InitNamePlate();
extern void NamePlates_NamePlateHandler();
extern void NamePlates_NewNamePlate();
extern void *NamePlates__init();


#endif
