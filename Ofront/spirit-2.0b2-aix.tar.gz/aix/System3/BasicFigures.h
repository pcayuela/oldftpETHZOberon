/* Ofront 1.1 */

#ifndef BasicFigures__h
#define BasicFigures__h

#include "SYSTEM.h"
#include "Display.h"
#include "Display3.h"
#include "Gadgets.h"
#include "Objects.h"

typedef
	struct BasicFigures_FigureDesc *BasicFigures_Figure;

typedef
	struct BasicFigures_PointDesc *BasicFigures_Point;

typedef
	struct BasicFigures_MethodDesc *BasicFigures_Methods;

typedef
	struct BasicFigures_FigureDesc { /* Gadgets_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		Attributes_Attr attr;
		Links_Link link;
		SET state;
		Display3_Mask mask;
		Objects_Object obj;
		BasicFigures_Point p;
		INTEGER width;
		SET state0;
		INTEGER col, patno;
		BasicFigures_Methods do_;
	} BasicFigures_FigureDesc;

typedef
	struct BasicFigures_MethodDesc {
		void (*Draw)();
		void (*Print)();
		void (*Normalize)();
		BOOLEAN (*HitTest)();
	} BasicFigures_MethodDesc;

typedef
	struct BasicFigures_PointDesc {
		BasicFigures_Point prev, next;
		INTEGER x, y;
	} BasicFigures_PointDesc;


extern BasicFigures_Methods BasicFigures_CircleMethods, BasicFigures_LineMethods, BasicFigures_RectMethods, BasicFigures_SplineMethods;

extern long *BasicFigures_PointDesc__typ;
extern long *BasicFigures_MethodDesc__typ;
extern long *BasicFigures_FigureDesc__typ;

extern void BasicFigures_AddPoint();
extern void BasicFigures_CircleHandler();
extern void BasicFigures_CopyFigure();
extern void BasicFigures_DrawCircle();
extern void BasicFigures_DrawLine();
extern void BasicFigures_DrawRect();
extern void BasicFigures_DrawSpline();
extern void BasicFigures_FigureHandler();
extern BOOLEAN BasicFigures_HitTestCircle();
extern BOOLEAN BasicFigures_HitTestLine();
extern BOOLEAN BasicFigures_HitTestRect();
extern BOOLEAN BasicFigures_HitTestSpline();
extern void BasicFigures_InitCircle();
extern void BasicFigures_InitLine();
extern void BasicFigures_InitRect();
extern void BasicFigures_InitSpline();
extern void BasicFigures_LineHandler();
extern void BasicFigures_NewCircle();
extern void BasicFigures_NewLine();
extern void BasicFigures_NewRect();
extern void BasicFigures_NewSpline();
extern void BasicFigures_NormalizeCircle();
extern void BasicFigures_NormalizeLine();
extern void BasicFigures_NormalizeRect();
extern void BasicFigures_NormalizeSpline();
extern void BasicFigures_PrintCircle();
extern void BasicFigures_PrintLine();
extern void BasicFigures_PrintRect();
extern void BasicFigures_PrintSpline();
extern void BasicFigures_RectHandler();
extern void BasicFigures_SplineHandler();
extern BasicFigures_Point BasicFigures_ThisPoint();
extern void BasicFigures_Track();
extern void *BasicFigures__init();


#endif
