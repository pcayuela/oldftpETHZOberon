/* Ofront 1.1 */

#ifndef Viewers__h
#define Viewers__h

#include "SYSTEM.h"
#include "Display.h"
#include "Objects.h"

typedef
	struct Viewers_ViewerDesc *Viewers_Viewer;

typedef
	struct Viewers_ViewerDesc { /* Display_FrameDesc */
		LONGINT stamp;
		Objects_Object dlink, slink;
		Objects_Library lib;
		INTEGER ref;
		Objects_Handler handle;
		Display_Frame next, dsc;
		INTEGER X, Y, W, H;
		INTEGER state;
	} Viewers_ViewerDesc;


extern INTEGER Viewers_curW, Viewers_minH;

extern long *Viewers_ViewerDesc__typ;

extern void Viewers_Change();
extern void Viewers_Close();
extern void Viewers_CloseTrack();
extern void Viewers_InitTrack();
extern void Viewers_Locate();
extern Viewers_Viewer Viewers_Next();
extern void Viewers_Open();
extern void Viewers_OpenTrack();
extern void Viewers_Recall();
extern Viewers_Viewer Viewers_This();
extern void *Viewers__init();


#endif
