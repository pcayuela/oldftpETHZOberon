/* Ofront 1.0 */

#ifndef Out__h
#define Out__h

#include "SYSTEM.h"




extern void Out_Char();
extern void Out_Int();
extern void Out_Ln();
extern void Out_LongReal();
extern void Out_Open();
extern void Out_Real();
extern void Out_String();
extern void *Out__init();


#endif
