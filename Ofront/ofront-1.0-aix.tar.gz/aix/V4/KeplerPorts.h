/* Ofront 1.0 */

#ifndef KeplerPorts__h
#define KeplerPorts__h

#include "SYSTEM.h"
#include "Display.h"

typedef
	struct KeplerPorts_BalloonPortDesc *KeplerPorts_BalloonPort;

typedef
	struct KeplerPorts_PortDesc *KeplerPorts_Port;

typedef
	struct KeplerPorts_PortDesc { /* Display_FrameDesc */
		Display_Frame dsc, next;
		INTEGER X, Y, W, H;
		Display_Handler handle;
		INTEGER x0, y0, scale;
		KeplerPorts_Port ext;
	} KeplerPorts_PortDesc;

extern INTEGER KeplerPorts_Port_CX();
extern INTEGER KeplerPorts_Port_CY();
extern INTEGER KeplerPorts_Port_Cx();
extern INTEGER KeplerPorts_Port_Cy();
extern void KeplerPorts_Port_DrawCircle();
extern void KeplerPorts_Port_DrawEllipse();
extern void KeplerPorts_Port_DrawLine();
extern void KeplerPorts_Port_DrawRect();
extern void KeplerPorts_Port_DrawString();
extern void KeplerPorts_Port_FillCircle();
extern void KeplerPorts_Port_FillQuad();
extern void KeplerPorts_Port_FillRect();
#define __KeplerPorts_Port_CX(P, x) __SEND(__TYPEOF(P), 0, INTEGER, (P, x))
#define __KeplerPorts_Port_CY(P, y) __SEND(__TYPEOF(P), 1, INTEGER, (P, y))
#define __KeplerPorts_Port_Cx(P, X) __SEND(__TYPEOF(P), 2, INTEGER, (P, X))
#define __KeplerPorts_Port_Cy(P, Y) __SEND(__TYPEOF(P), 3, INTEGER, (P, Y))
#define __KeplerPorts_Port_DrawCircle(P, x, y, r, col, mode) __SEND(__TYPEOF(P), 4, void, (P, x, y, r, col, mode))
#define __KeplerPorts_Port_DrawEllipse(P, x, y, a, b, col, mode) __SEND(__TYPEOF(P), 5, void, (P, x, y, a, b, col, mode))
#define __KeplerPorts_Port_DrawLine(P, x1, y1, x2, y2, col, mode) __SEND(__TYPEOF(P), 6, void, (P, x1, y1, x2, y2, col, mode))
#define __KeplerPorts_Port_DrawRect(P, x, y, w, h, col, mode) __SEND(__TYPEOF(P), 7, void, (P, x, y, w, h, col, mode))
#define __KeplerPorts_Port_DrawString(P, x, y, s, s__len, font, col, mode) __SEND(__TYPEOF(P), 8, void, (P, x, y, s, s__len, font, col, mode))
#define __KeplerPorts_Port_FillCircle(P, x, y, r, col, pat, mode) __SEND(__TYPEOF(P), 9, void, (P, x, y, r, col, pat, mode))
#define __KeplerPorts_Port_FillQuad(P, x1, y1, x2, y2, x3, y3, x4, y4, col, pat, mode) __SEND(__TYPEOF(P), 10, void, (P, x1, y1, x2, y2, x3, y3, x4, y4, col, pat, mode))
#define __KeplerPorts_Port_FillRect(P, x, y, w, h, col, pat, mode) __SEND(__TYPEOF(P), 11, void, (P, x, y, w, h, col, pat, mode))

typedef
	struct KeplerPorts_BalloonPortDesc { /* KeplerPorts_PortDesc */
		Display_Frame dsc, next;
		INTEGER X, Y, W, H;
		Display_Handler handle;
		INTEGER x0, y0, scale;
		KeplerPorts_Port ext;
	} KeplerPorts_BalloonPortDesc;

extern void KeplerPorts_BalloonPort_DrawCircle();
extern void KeplerPorts_BalloonPort_DrawEllipse();
extern void KeplerPorts_BalloonPort_DrawLine();
extern void KeplerPorts_BalloonPort_DrawRect();
extern void KeplerPorts_BalloonPort_DrawString();
extern void KeplerPorts_BalloonPort_FillCircle();
extern void KeplerPorts_BalloonPort_FillQuad();
extern void KeplerPorts_BalloonPort_FillRect();

typedef
	struct KeplerPorts_DisplayPortDesc *KeplerPorts_DisplayPort;

typedef
	struct KeplerPorts_DisplayPortDesc { /* KeplerPorts_PortDesc */
		Display_Frame dsc, next;
		INTEGER X, Y, W, H;
		Display_Handler handle;
		INTEGER x0, y0, scale;
		KeplerPorts_Port ext;
	} KeplerPorts_DisplayPortDesc;

extern void KeplerPorts_DisplayPort_DrawCircle();
extern void KeplerPorts_DisplayPort_DrawEllipse();
extern void KeplerPorts_DisplayPort_DrawLine();
extern void KeplerPorts_DisplayPort_DrawString();
extern void KeplerPorts_DisplayPort_FillRect();

typedef
	struct KeplerPorts_PrinterPortDesc *KeplerPorts_PrinterPort;

typedef
	struct KeplerPorts_PrinterPortDesc { /* KeplerPorts_PortDesc */
		Display_Frame dsc, next;
		INTEGER X, Y, W, H;
		Display_Handler handle;
		INTEGER x0, y0, scale;
		KeplerPorts_Port ext;
	} KeplerPorts_PrinterPortDesc;

extern void KeplerPorts_PrinterPort_DrawCircle();
extern void KeplerPorts_PrinterPort_DrawEllipse();
extern void KeplerPorts_PrinterPort_DrawLine();
extern void KeplerPorts_PrinterPort_DrawString();
extern void KeplerPorts_PrinterPort_FillRect();



extern long *KeplerPorts_PortDesc__typ;
extern long *KeplerPorts_DisplayPortDesc__typ;
extern long *KeplerPorts_PrinterPortDesc__typ;
extern long *KeplerPorts_BalloonPortDesc__typ;

extern void KeplerPorts_InitBalloon();
extern INTEGER KeplerPorts_StringWidth();
extern void *KeplerPorts__init();


#endif
