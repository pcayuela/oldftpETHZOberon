/* Ofront 1.0 */

#ifndef AsciiCoder__h
#define AsciiCoder__h

#include "SYSTEM.h"




extern void AsciiCoder_Code();
extern void AsciiCoder_CodeFiles();
extern void AsciiCoder_CodeText();
extern void AsciiCoder_Compress();
extern void AsciiCoder_Decode();
extern void AsciiCoder_DecodeFiles();
extern void AsciiCoder_DecodeText();
extern void AsciiCoder_Expand();
extern void *AsciiCoder__init();


#endif
