/* Ofront 1.0 */

#ifndef Math__h
#define Math__h

#include "SYSTEM.h"




extern REAL Math_arctan();
extern REAL Math_cos();
extern REAL Math_exp();
extern REAL Math_ln();
extern REAL Math_sin();
extern REAL Math_sqrt();
extern void *Math__init();


#endif
