/* Ofront 1.0 */

#ifndef MenuViewers__h
#define MenuViewers__h

#include "SYSTEM.h"
#include "Display.h"
#include "Viewers.h"

typedef
	struct MenuViewers_ModifyMsg { /* Display_FrameMsg */
		INTEGER id, dY, Y, H;
	} MenuViewers_ModifyMsg;

typedef
	struct MenuViewers_ViewerDesc *MenuViewers_Viewer;

typedef
	struct MenuViewers_ViewerDesc { /* Viewers_ViewerDesc */
		Display_Frame dsc, next;
		INTEGER X, Y, W, H;
		Display_Handler handle;
		INTEGER state;
		INTEGER menuH;
	} MenuViewers_ViewerDesc;


extern MenuViewers_Viewer MenuViewers_Ancestor;

extern long *MenuViewers_ViewerDesc__typ;
extern long *MenuViewers_ModifyMsg__typ;

extern void MenuViewers_Handle();
extern MenuViewers_Viewer MenuViewers_New();
extern void *MenuViewers__init();


#endif
