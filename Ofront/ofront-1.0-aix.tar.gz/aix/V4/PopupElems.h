/* Ofront 1.0 */

#ifndef PopupElems__h
#define PopupElems__h

#include "SYSTEM.h"




extern void PopupElems_Alloc();
extern void PopupElems_Insert();
extern void PopupElems_InsertMenu();
extern void PopupElems_Toggle();
extern void PopupElems_Update();
extern void *PopupElems__init();


#endif
