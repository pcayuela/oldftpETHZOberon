/* Ofront 1.0 */

#ifndef KeplerFrames__h
#define KeplerFrames__h

#include "SYSTEM.h"
#include "Display.h"
#include "Fonts.h"
#include "KeplerGraphs.h"
#include "KeplerPorts.h"

typedef
	struct KeplerFrames_ButtonDesc *KeplerFrames_Button;

typedef
	struct KeplerFrames_ButtonDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
		CHAR cmd[32], par[32];
	} KeplerFrames_ButtonDesc;

extern void KeplerFrames_Button_Execute();
extern void KeplerFrames_Button_HandleMouse();
extern void KeplerFrames_Button_Read();
extern void KeplerFrames_Button_Write();
#define __KeplerFrames_Button_Execute(B, keys) __SEND(__TYPEOF(B), 4, void, (B, keys))
#define __KeplerFrames_Button_HandleMouse(B, F, x, y, keys) __SEND(__TYPEOF(B), 5, void, (B, F, x, y, keys))

typedef
	struct KeplerFrames_CaptionDesc *KeplerFrames_Caption;

typedef
	struct KeplerFrames_CaptionDesc { /* KeplerGraphs_ConsDesc */
		INTEGER nofpts;
		KeplerGraphs_Star p[4];
		KeplerGraphs_Constellation next;
		CHAR s[128];
		Fonts_Font fnt;
		SHORTINT align;
	} KeplerFrames_CaptionDesc;

extern void KeplerFrames_Caption_Draw();
extern void KeplerFrames_Caption_Read();
extern void KeplerFrames_Caption_Write();

typedef
	struct KeplerFrames_FocusPointDesc *KeplerFrames_FocusPoint;

typedef
	struct KeplerFrames_FocusPointDesc {
		KeplerFrames_FocusPoint next;
		KeplerGraphs_Star p;
	} KeplerFrames_FocusPointDesc;

typedef
	struct KeplerFrames_FrameDesc *KeplerFrames_Frame;

typedef
	struct KeplerFrames_FrameDesc { /* KeplerPorts_DisplayPortDesc */
		Display_Frame dsc, next;
		INTEGER X, Y, W, H;
		Display_Handler handle;
		INTEGER x0, y0, scale;
		KeplerPorts_Port ext;
		KeplerGraphs_Graph G;
		INTEGER col, grid;
	} KeplerFrames_FrameDesc;

extern void KeplerFrames_Frame_Consume();
extern void KeplerFrames_Frame_EditFrame();
extern void KeplerFrames_Frame_Extend();
extern void KeplerFrames_Frame_Invert();
extern void KeplerFrames_Frame_Neutralize();
extern void KeplerFrames_Frame_Reduce();
extern void KeplerFrames_Frame_Restore();
extern void KeplerFrames_Frame_TrackMouse();
#define __KeplerFrames_Frame_Consume(F, ch) __SEND(__TYPEOF(F), 12, void, (F, ch))
#define __KeplerFrames_Frame_EditFrame(F, x, y, keys) __SEND(__TYPEOF(F), 13, void, (F, x, y, keys))
#define __KeplerFrames_Frame_Extend(F, newY) __SEND(__TYPEOF(F), 14, void, (F, newY))
#define __KeplerFrames_Frame_Invert(F, p) __SEND(__TYPEOF(F), 15, void, (F, p))
#define __KeplerFrames_Frame_Neutralize(F) __SEND(__TYPEOF(F), 16, void, (F))
#define __KeplerFrames_Frame_Reduce(F, newY) __SEND(__TYPEOF(F), 17, void, (F, newY))
#define __KeplerFrames_Frame_Restore(F, X, Y, W, H) __SEND(__TYPEOF(F), 18, void, (F, X, Y, W, H))
#define __KeplerFrames_Frame_TrackMouse(F, x, y, keys) __SEND(__TYPEOF(F), 19, void, (F, x, y, keys))

typedef
	void (*KeplerFrames_Notifier)();

typedef
	struct KeplerFrames_SelMsg { /* Display_FrameMsg */
		LONGINT time;
		KeplerGraphs_Graph G;
	} KeplerFrames_SelMsg;

typedef
	struct KeplerFrames_UpdateMsg { /* Display_FrameMsg */
		INTEGER id;
		KeplerGraphs_Graph G;
		KeplerGraphs_Object O;
		KeplerPorts_Port P;
	} KeplerFrames_UpdateMsg;


extern KeplerGraphs_Graph KeplerFrames_Focus;
extern KeplerFrames_FocusPoint KeplerFrames_first, KeplerFrames_last;
extern INTEGER KeplerFrames_nofpts;
extern KeplerFrames_Caption KeplerFrames_focus;
extern INTEGER KeplerFrames_carpos;

extern long *KeplerFrames_FocusPointDesc__typ;
extern long *KeplerFrames_ButtonDesc__typ;
extern long *KeplerFrames_CaptionDesc__typ;
extern long *KeplerFrames_FrameDesc__typ;
extern long *KeplerFrames_UpdateMsg__typ;
extern long *KeplerFrames_SelMsg__typ;

extern void KeplerFrames_AlignToGrid();
extern void KeplerFrames_AppendFocusPoint();
extern void KeplerFrames_ConsumePoint();
extern void KeplerFrames_DeleteFocusPoint();
extern void KeplerFrames_GetMouse();
extern void KeplerFrames_GetPoint();
extern void KeplerFrames_GetSelection();
extern void KeplerFrames_Handle();
extern BOOLEAN KeplerFrames_IsFocusPoint();
extern KeplerFrames_Button KeplerFrames_MarkedButton();
extern void KeplerFrames_MoveOrigin();
extern KeplerFrames_Frame KeplerFrames_New();
extern void KeplerFrames_NotifyDisplay();
extern void KeplerFrames_Open();
extern KeplerFrames_Button KeplerFrames_ThisButton();
extern KeplerFrames_Caption KeplerFrames_ThisCaption();
extern void *KeplerFrames__init();


#endif
