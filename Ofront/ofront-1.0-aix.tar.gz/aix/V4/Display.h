/* Ofront 1.0 */

#ifndef Display__h
#define Display__h

#include "SYSTEM.h"

typedef
	struct Display_Bytes {
		char _prvt0[1];
	} Display_Bytes;

typedef
	Display_Bytes *Display_Font;

typedef
	struct Display_FrameDesc *Display_Frame;

typedef
	void (*Display_Handler)();

typedef
	struct Display_FrameDesc {
		Display_Frame dsc, next;
		INTEGER X, Y, W, H;
		Display_Handler handle;
	} Display_FrameDesc;

typedef
	struct Display_FrameMsg {
		char _prvt0[1];
	} Display_FrameMsg;


extern INTEGER Display_Bottom, Display_Left, Display_Width, Display_Height, Display_ColLeft, Display_UBottom;
extern LONGINT Display_Unit, Display_primary, Display_secondary, Display_arrow, Display_cross, Display_star, Display_hook, Display_downArrow, Display_grey0, Display_grey1, Display_grey2, Display_ticks;

extern long *Display_FrameMsg__typ;
extern long *Display_FrameDesc__typ;
extern long *Display_Bytes__typ;

extern void Display_CopyBlock();
extern void Display_CopyBlockC();
extern void Display_CopyPattern();
extern void Display_CopyPatternC();
extern void Display_Dot();
extern void Display_DotC();
extern void Display_GetChar();
extern void Display_GetColor();
extern LONGINT Display_Map();
extern LONGINT Display_NewPattern();
extern void Display_ReplConst();
extern void Display_ReplConstC();
extern void Display_ReplPattern();
extern void Display_ReplPatternC();
extern void Display_SetColor();
extern void Display_SetMode();
extern void *Display__init();


#endif
