/* Ofront 1.0 */

#ifndef TableElems__h
#define TableElems__h

#include "SYSTEM.h"
#include "Display.h"
#include "MenuViewers.h"
#include "Texts.h"

typedef
	struct TableElems_ElemDesc *TableElems_Elem;

typedef
	struct TableElems_ElemDesc { /* Texts_ElemDesc */
		char _prvt0[20];
		LONGINT W, H;
		Texts_Handler handle;
		char _prvt1[4];
		Texts_Text def;
		char _prvt2[148];
	} TableElems_ElemDesc;

typedef
	struct TableElems_ViewerDesc *TableElems_Viewer;

typedef
	struct TableElems_ViewerDesc { /* MenuViewers_ViewerDesc */
		Display_Frame dsc, next;
		INTEGER X, Y, W, H;
		Display_Handler handle;
		INTEGER state;
		INTEGER menuH;
		TableElems_Elem elem;
	} TableElems_ViewerDesc;



extern long *TableElems_ElemDesc__typ;
extern long *TableElems_ViewerDesc__typ;

extern void TableElems_Alloc();
extern void TableElems_Changed();
extern Texts_Text TableElems_CopyText();
extern void TableElems_Draw();
extern void TableElems_Handle();
extern void TableElems_Insert();
extern void TableElems_Load();
extern void TableElems_Open();
extern void TableElems_OpenViewer();
extern void TableElems_Print();
extern void TableElems_Store();
extern void TableElems_Track();
extern void TableElems_Update();
extern void *TableElems__init();


#endif
