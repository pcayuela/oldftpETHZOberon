/* Ofront 1.0 */

#ifndef X11__h
#define X11__h

#include "SYSTEM.h"

typedef
	struct X11_PatternDesc {
		LONGINT x, y;
		INTEGER w, h;
		LONGINT pixmap;
	} X11_PatternDesc;

typedef
	struct X11_MetricDesc {
		INTEGER dx, x, y;
		X11_PatternDesc p;
	} X11_MetricDesc;

typedef
	struct X11_Bytes {
		X11_MetricDesc metrics[256];
		LONGINT xid;
	} X11_Bytes;

typedef
	struct X11_Color {
		LONGINT pixel;
		INTEGER red, green, blue;
		CHAR flags, pad;
	} X11_Color;

typedef
	struct X11_ErrorEvent {
		LONGINT type, display, resourceid, serial;
		CHAR errorCode, requestCode, minorCode;
	} X11_ErrorEvent;

typedef
	X11_ErrorEvent *X11_ErrorEventPtr;

typedef
	LONGINT (*X11_ErrorHandler)();

typedef
	struct X11_Event {
		LONGINT type, serial, sendEvent, display, window, root, subwindow, time, x, y, xRoot, yRoot, state, button, sameScreen, focus, state2;
		LONGINT pad[32];
	} X11_Event;

typedef
	X11_Bytes *X11_Font;

typedef
	LONGINT (*X11_IOErrorHandler)();

typedef
	struct X11_ImageDesc {
		LONGINT width, height, xoffset, format, data, byteOrder, bitmapUnit, bitmapBitOrder, bitmapPad, depth, bytesPerLine, bitsPerPixel, redmask, greenmask, bluemask, obdata, createImage, destroyImage, getPixel, putPixel, subImage, addPixel;
	} X11_ImageDesc;

typedef
	X11_ImageDesc *X11_ImagePtr;

typedef
	CHAR X11_Modlist[8][32];

typedef
	X11_PatternDesc *X11_PatternPtr;

typedef
	struct X11_Point {
		INTEGER x, y;
	} X11_Point;

typedef
	struct X11_Rectangle {
		INTEGER x, y, w, h;
	} X11_Rectangle;

typedef
	struct X11_SelectionEvent {
		LONGINT type, serial, sendEvent, display, requestor, selection, target, property, time;
	} X11_SelectionEvent;

typedef
	struct X11_SelectionRequestEvent {
		LONGINT type, serial, sendEvent, display, owner, requestor, selection, target, property, time;
	} X11_SelectionRequestEvent;

typedef
	struct X11_Visual {
		LONGINT extData, visualid, class, redMask, greenMask, blueMask, bitsPerRgb, mapEntries;
	} X11_Visual;

typedef
	struct X11_VisualInfo {
		LONGINT visual, visualID, screen, depth, class, redmask, greenmask, bluemask, colomapsize, bitsperrgb;
	} X11_VisualInfo;

typedef
	X11_Visual *X11_VisualPtr;


extern CHAR X11_WinName[128], X11_IconName[128], X11_Copyright[128], X11_WinNameCopyright[128];
extern LONGINT X11_display, X11_primary, X11_secondary, X11_root, X11_basePixel, X11_foreground, X11_background;
extern INTEGER X11_backgroundCol, X11_foregroundCol;
extern LONGINT X11_screen, X11_screenw, X11_screenh, X11_screenhmm, X11_cells, X11_planes, X11_visualptr, X11_defvisualptr, X11_cmap, X11_defcmap;
extern INTEGER X11_Width, X11_Height, X11_Bottom, X11_UBottom, X11_ColLeft, X11_depth;
extern LONGINT X11_pixelValues[256];
extern LONGINT X11_function[3];
extern LONGINT X11_planesMask;
extern SHORTINT X11_colorClass;
extern LONGINT X11_nofcol, X11_arrow, X11_noCursor;
extern CHAR X11_ErrorText[80];
extern BOOLEAN X11_ErrorFlag;
extern LONGINT X11_lastEventTime, X11_ccp;
extern X11_Font X11_ccf;
extern CHAR X11_ccch;
extern INTEGER X11_ccdx, X11_ccx, X11_ccy;
extern CHAR X11_lcache[256];
extern X11_Font X11_lcf;
extern INTEGER X11_lcx0, X11_lcy0, X11_lcx, X11_lccol, X11_lcmode, X11_lclen;
extern void (*X11_SendSelection)();
extern void (*X11_ReceiveSelection)();
extern void (*X11_ClearSelection)();

extern long *X11_PatternDesc__typ;
extern long *X11_MetricDesc__typ;
extern long *X11_Bytes__typ;
extern long *X11_Visual__typ;
extern long *X11_VisualInfo__typ;
extern long *X11_Color__typ;
extern long *X11_Point__typ;
extern long *X11_Rectangle__typ;
extern long *X11_Event__typ;
extern long *X11_SelectionEvent__typ;
extern long *X11_SelectionRequestEvent__typ;
extern long *X11_ImageDesc__typ;
extern long *X11_ErrorEvent__typ;

extern void X11_DoFlush();
extern void X11_DoSync();
extern void X11_FlushLCache();
extern void X11_GetColor();
extern void X11_InitColors();
extern LONGINT X11_MyErrorHandler();
extern LONGINT X11_NewPattern();
extern LONGINT X11_RasterToPixmap();
extern void X11_Rebind();
extern void X11_SetColor();
extern void *X11__init();

#define X11_AddPixel(image, value)	XAddPixel(image, value)
#define X11_AllocColorCells(display, cmap, contig, planeMasks, nplanes, pixels, ncolors)	(long)XAllocColorCells(display, cmap, contig, planeMasks, nplanes, pixels, ncolors)
#define X11_Bell(display, percent)	XBell(display, percent)
#define X11_BlackPixel(display, screen)	(long)XBlackPixel(display, screen)
#define X11_ChangeProperty(display, window, property, type, format, mode, data, nelements)	XChangeProperty(display, window, property, type, format, mode, data, nelements)
#define X11_ClearWindow(display, window)	XClearWindow(display, window)
#define X11_ConvertSelection(display, selection, target, property, requestor, timestamp)	XConvertSelection(display, selection, target, property, requestor, timestamp)
#define X11_CopyArea(display, src, dest, gc, srcX, srcY, width, height, destX, destY)	XCopyArea(display, src, dest, gc, srcX, srcY, width, height, destX, destY)
#define X11_CopyColormapAndFree(display, cmap)	(long)XCopyColormapAndFree(display, cmap)
#define X11_CopyPlane(display, src, dest, gc, srcX, srcY, width, height, destX, destY, plane)	XCopyPlane(display, src, dest, gc, srcX, srcY, width, height, destX, destY, plane)
#define X11_CreateBitmapFromData(display, drawable, data, width, height)	(long)XCreateBitmapFromData(display, drawable, data, width, height)
#define X11_CreateColormap(display, window, vis, alloc)	(long)XCreateColormap(display, window, vis, alloc)
#define X11_CreateFontCursor(display, shape)	(long)XCreateFontCursor(display, shape)
#define X11_CreateGC(display, drawable, valueMask, values)	(long)XCreateGC(display, drawable, valueMask, values)
#define X11_CreateImage(display, visual, depth, format, offset, data, width, height, bitmapPad, bytesPerLine)	(long)XCreateImage(display, visual, depth, format, offset, data, width, height, bitmapPad, bytesPerLine)
#define X11_CreatePixmap(display, drawable, width, height, depth)	(long)XCreatePixmap(display,drawable, width, height, depth)
#define X11_CreatePixmapCursor(display, csource, cmask, cfore, cback, xhot, yhot)	(long)XCreatePixmapCursor(display, csource, cmask, cfore, cback, xhot, yhot)
#define X11_CreateSimpleWindow(display, parent, x, y, width, height, borderWidth, border, background)	(long)XCreateSimpleWindow(display, parent, x, y, width, height, borderWidth, border, background)
#define X11_DefaultColormap(display, screen)	(long)XDefaultColormap(display, screen)
#define X11_DefaultDepth(display, screen)	(long)XDefaultDepth(display, screen)
#define X11_DefaultRootWindow(display)	(long)XDefaultRootWindow(display)
#define X11_DefaultScreen(display)	(long)XDefaultScreen(display)
#define X11_DefaultVisual(display, screen)	(long)XDefaultVisual(display, screen)
#define X11_DefineCursor(display, window, curs)	XDefineCursor(display, window, curs)
#define X11_DeleteProperty(display, window, property)	XDeleteProperty(display, window, property)
#define X11_DestroyImage(image)	XDestroyImage(image)
#define X11_DisplayCells(display, screen)	(long)XDisplayCells(display, screen)
#define X11_DisplayHeight(display, screen)	(long)XDisplayHeight(display, screen)
#define X11_DisplayHeightMM(display, screen)	(long)XDisplayHeightMM(display, screen)
#define X11_DisplayPlanes(display, screen)	(long)XDisplayPlanes(display, screen)
#define X11_DisplayWidth(display, screen)	(long)XDisplayWidth(display, screen)
#define X11_DrawArc(display, window, gc, x, y, width, height, angle1, angle2)	XDrawArc(display, window, gc, x, y, width, height, angle1, angle2)
#define X11_DrawLine(display, window, gc, x1, y1, x2, y2)	XDrawLine(display, window, gc, x1, y1, x2, y2)
#define X11_DrawPoint(display, window, gc, x, y)	XDrawPoint(display, window, gc, x, y)
#define X11_DrawString(display, window, gc, x, y, width, height)	XDrawString(display, window, gc, x, y, width, height)
#define X11_EventsQueued(display, mode)	(long)XEventsQueued(display, mode)
#define X11_FetchBytes(display, nbytes)	(long)XFetchBytes(display, nbytes)
#define X11_FillArc(display, window, gc, x, y, width, height, angle1, angle2)	XFillArc(display, window, gc, x, y, width, height, angle1, angle2)
#define X11_FillPolygon(display, window, gc, points, npoints, shape, mode)	XFillPolygon(display, window, gc, points, npoints, shape, mode)
#define X11_FillRectangle(display, window, gc, x, y, width, height)	XFillRectangle(display, window, gc, x, y, width, height)
#define X11_Flush(display)	XFlush(display)
#define X11_Free(data)	XFree(data)
#define X11_FreeFontNames(list)	XFreeFontNames(list)
#define X11_FreePixmap(display, pixmap)	XFreePixmap(display, pixmap)
#define X11_Geometry(display, screen, user, user__len, default, default___len, bwidth, fw, fh, xpad, ypad, x, y, w, h)	(long)XGeometry(display, screen, user, default, bwidth, fw, fh, xpad, ypad, x, y, w, h)
#define X11_GetErrorText(display, code, buffer, length)	XGetErrorText(display, code, buffer, length)
#define X11_GetGeometry(display, drawable, root, x, y, width, height, orderWidth, Depth)	XGetGeometry(display, drawable, root, x, y, width, height, orderWidth, Depth)
#define X11_GetImage(display, drawable, x, y, width, height, planeMask, format)	(long)XGetImage(display, drawable, x, y, width, height, planeMask, format)
#define X11_GetPixel(image, x, y)	(long)XGetPixel(image, x, y)
#define X11_GetSelectionOwner(display, selection)	(long)XGetSelectionOwner(display, selection)
#define X11_GetSubImage(display, drawable, x, y, width, height, planeMask, format, dstImage, dstX, dstY)	(long)XGetSubImage(display, drawable, x, y, width, height, planeMask, format, dstImage, dstX, dstY)
#define X11_GetWindowProperty(display, window, property, offset, length, delete, reqtype, type, format, nitems, bytesafter, prop)	XGetWindowProperty(display, window, property, offset, length, delete, reqtype, type, format, nitems, bytesafter, prop)
#define X11_InstallColormap(display, cmap)	XInstallColormap(display, cmap)
#define X11_InternAtom(display, name, onlyifexists)	(long)XInternAtom(display, name, onlyifexists)
#define X11_ListFonts(display, pattern, maxnames, count)	(long)XListFonts(display, pattern, maxnames, count)
#define X11_LoadFont(display, name)	(long)XLoadFont(display, name)
#define X11_LookupString(event, buffer, bufsize, keysym, compstatus)	(long)XLookupString(event, buffer, bufsize, keysym, compstatus)
#define X11_LowerWindow(display, window)	XLowerWindow(display, window)
#define X11_MapRaised(display, window)	XMapRaised(display, window)
#define X11_MatchVisualInfo(display, screen, depth, class, vinforet)	(long)XMatchVisualInfo(display, screen, depth, class, vinforet)
#define X11_MoveResizeWindow(display, window, x, y, width, height)	XMoveResizeWindow(display, window, x, y, width, height)
#define X11_NextEvent(display, event)	XNextEvent(display, event)
#define X11_OpenDisplay(name, name__len)	(long)XOpenDisplay(name)
#define X11_PutImage(display, drawable, gc, image, srcX, srcY, dstX, dstY, width, height)	XPutImage(display, drawable, gc, image, srcX, srcY, dstX, dstY, width, height)
#define X11_PutPixel(image, x, y, pixel)	(long)XPutPixel(image, x, y, pixel)
#define X11_QueryBestSize(display, class, screen, width, height, w, h)	XQueryBestSize(display, class, screen, width, height, w, h)
#define X11_QueryPointer(display, window, rw, cw, xr, yr, xw, yw, keysButtons)	XQueryPointer(display, window, rw, cw, xr, yr, xw, yw, keysButtons)
#define X11_RebindKeysym(display, reboundsym, modlist, modlength, newstring, newlength)	XRebindKeysym(display, reboundsym, modlist, modlength, newstring, newlength)
#define X11_RecolorCursor(display, curs, cfore, cback)	XRecolorCursor(display, curs, cfore, cback)
#define X11_RefreshKeyboardMapping(event)	XRefreshKeyboardMapping(event)
#define X11_ResizeWindow(display, window, x, y)	XResizeWindow(display, window, x, y)
#define X11_SelectInput(display, window, eventMask)	XSelectInput(display, window, eventMask)
#define X11_SendEvent(display, window, propagate, eventmask, event)	XSendEvent(display, window, propagate, eventmask, event)
#define X11_SetArcMode(display, gc, arcmode)	XSetArcMode(display, gc, arcmode)
#define X11_SetBackground(display, gc, arg)	XSetBackground(display, gc, arg)
#define X11_SetClipMask(display, gc, clipMask)	XSetClipMask(display, gc, clipMask)
#define X11_SetClipRectangles(display, gc, clipxorigin, clipyorigin, rectangles, n, ordering)	XSetClipRectangles(display, gc, clipxorigin, clipyorigin, rectangles, n, ordering)
#define X11_SetCommand(display, window, argv, argc)	XSetCommand(display, window, argv, argc)
#define X11_SetErrorHandler(handler)	XSetErrorHandler(handler)
#define X11_SetFillStyle(display, gc, arg)	XSetFillStyle(display, gc, arg)
#define X11_SetFont(display, gc, arg)	XSetFont(display, gc, arg)
#define X11_SetForeground(display, gc, arg)	XSetForeground(display, gc, arg)
#define X11_SetFunction(display, gc, arg)	XSetFunction(display, gc, arg)
#define X11_SetGraphicsExposures(display, gc, graphicsExposures)	XSetGraphicsExposures(display,gc, graphicsExposures )
#define X11_SetIOErrorHandler(handler)	XSetIOErrorHandler(handler)
#define X11_SetIconName(display, window, name)	XSetIconName(display, window, name)
#define X11_SetInputFocus(display, focus, revertTo, time)	XSetInputFocus(display, focus, revertTo, time)
#define X11_SetLineAttributes(display, gc, lineWidth, lineStyle, capStyle, joinStyle)	XSetLineAttributes(display, gc, lineWidth, lineStyle, capStyle, joinStyle)
#define X11_SetPlaneMask(display, gc, mask)	XSetPlaneMask(display, gc, mask)
#define X11_SetSelectionOwner(display, selection, owner, time)	XSetSelectionOwner(display, selection, owner, time)
#define X11_SetStipple(display, gc, stipple)	XSetStipple(display, gc, stipple)
#define X11_SetTSOrigin(display, gc, tsxorigin, tsyorigin)	XSetTSOrigin(display, gc, tsxorigin, tsyorigin)
#define X11_SetWindowBackground(display, window, pixel)	XSetWindowBackground(display, window, pixel)
#define X11_SetWindowColormap(display, window, cmap)	XSetWindowColormap(display, window, cmap)
#define X11_StoreBytes(display, bytes, nbytes)	XStoreBytes(display, bytes, nbytes)
#define X11_StoreColor(display, cmap, color)	XStoreColor(display, cmap, color)
#define X11_StoreName(display, window, name)	XStoreName(display, window, name)
#define X11_StringToKeysym(string)	(long)XStringToKeysym(string)
#define X11_SubImage(image, x, y, width, height)	(long)XSubImage(image, x, y, width, height)
#define X11_Sync(display, discard)	XSync(display, discard)
#define X11_TranslateCoordinates(display, sw, dw, srcx, srcy, dstx, dsty, child)	XTranslateCoordinates(display, sw, dw, srcx, srcy, dstx, dsty, child)
#define X11_WarpPointer(display, srcwin, dstwin, srcx, srcy, srcw, srch, dstx, dsty)	XWarpPointer(display, srcwin, dstwin, srcx, srcy, srcw, srch, dstx, dsty)
#define X11_WhitePixel(display, screen)	(long)XWhitePixel(display, screen)

#endif
