/* Ofront 1.0 */

#ifndef Kepler2__h
#define Kepler2__h

#include "SYSTEM.h"
#include "KeplerGraphs.h"

typedef
	struct Kepler2_FractionDesc *Kepler2_Fraction;

typedef
	struct Kepler2_FractionDesc { /* KeplerGraphs_PlanetDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
		LONGINT cnt, dn;
	} Kepler2_FractionDesc;

extern void Kepler2_Fraction_Calc();
extern void Kepler2_Fraction_Read();
extern void Kepler2_Fraction_Write();

typedef
	struct Kepler2_OffsetDesc *Kepler2_Offset;

typedef
	struct Kepler2_OffsetDesc { /* KeplerGraphs_PlanetDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
		INTEGER dx, dy;
	} Kepler2_OffsetDesc;

extern void Kepler2_Offset_Calc();
extern void Kepler2_Offset_Read();
extern void Kepler2_Offset_Write();

typedef
	struct Kepler2_XYDesc *Kepler2_XY;

typedef
	struct Kepler2_XYDesc { /* KeplerGraphs_PlanetDesc */
		INTEGER x, y, refcnt;
		char _prvt0[2];
		BOOLEAN sel;
		KeplerGraphs_Star next;
		KeplerGraphs_Constellation c;
	} Kepler2_XYDesc;

extern void Kepler2_XY_Calc();



extern long *Kepler2_FractionDesc__typ;
extern long *Kepler2_XYDesc__typ;
extern long *Kepler2_OffsetDesc__typ;

extern void Kepler2_NewFractions();
extern void Kepler2_NewOffset();
extern void Kepler2_NewXY();
extern void *Kepler2__init();


#endif
