
/***********
 * Modules.h
 * C interface of the Oberon module loader for the IBM RISC System/6000
 * Marc-Michael Brandis, 26.4.91 / 31.3.92
 ***********/

#ifndef _I_MODULES
#define _I_MODULES

#include "OberonTypes.h"

/* values for res field */
#define done 0
#define fileNotFound 1
#define invalidObjFile 2
#define importedWithBadKey 3
#define notEnoughMemory 4
#define cyclicImport 5

/* sizes */
#define ModuleNameLength 20
#define CommandNameLength 24

/* types */

typedef PROCEDURE Command;

typedef CHAR ModuleName[ModuleNameLength];
typedef CHAR CommandName[CommandNameLength];

typedef struct _command_descriptor {
        CommandName name;
        INTEGER offset;
} CommandDesc;

typedef struct _trap_desc {
        INTEGER offset, trapno;
} TrapDesc;

typedef struct _module_descriptor {
	struct _module_descriptor* link;
	ModuleName name;
	INTEGER refcnt;
	BOOLEAN initialized;
	LONGINT key;
	INTEGER consize, codesize;
	LONGINT datasize;
	ADDRESS block;
	LONGINT blocksize;
	ADDRESS SB, PC;
	ADDRESS entries;		/* POINTER TO ARRAY OF INTEGER */
	ADDRESS commands;	/* POINTER TO ARRAY OF CommandDesc */
	ADDRESS imports;		/* POINTER TO ARRAY OF Module */
	ADDRESS typedescs;	/* POINTER TO ARRAY OF ADDRESS */
	ADDRESS pointers;	/* POINTER TO ARRAY OF LONGINT */
	ADDRESS traps;		/* POINTER TO ARRAY OF TrapDesc */
	ADDRESS refs;			/* POINTER TO ARRAY OF CHAR */
} ModuleDescriptor;

typedef ModuleDescriptor* Module;

/* if NULL is not defined, we do it here */
#ifndef NULL
#define NULL ((void*)0L)
#endif

/* macros to access the open arrays */
#define LEN(array,dim) (((long int *)(array))[3+dim])
#define ARRAY(array,dim,basetype) \
		((basetype*)(((long int *)(array))+4+(dim&0xfffffffe)))

/* conversion from C to Oberon procedure variables */
#define InitOberonProc(x,p) {long int *q = (long int *)p; \
			     x.PC = q[0]; x.SB = q[1]; }

typedef Tag (* CreateTDproc)(Module, CHAR*, LONGINT, LONGINT*, LONGINT, Tag, LONGINT, PROCEDURE*, LONGINT);

extern Module ThisMod(CHAR* name, LONGINT dy_len);
extern void ThisCommand(Module mod, CHAR* name, LONGINT dy_len, Command *Com);
extern void Free(CHAR* name, LONGINT dy_len, BOOLEAN all);
extern void DumpModules(void);
extern void ModulesInit(void);
extern void LoadKernel(void);
extern void RegisterResources(void);

#endif
