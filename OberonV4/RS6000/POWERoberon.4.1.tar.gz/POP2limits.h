
/***********
 * POP2limits.h
 * limits of the POWER OP2 Oberon compiler for the IBM RISC System/6000
 * Marc-Michael Brandis, 22.8.91 / 1.4.93
 ***********/

#ifndef _I_POP2LIMITS
#define _I_POP2LIMITS

#define MaxLinks 250
#define MaxImports 31
#define MaxRecs 64
#define MaxExts 16

#endif
