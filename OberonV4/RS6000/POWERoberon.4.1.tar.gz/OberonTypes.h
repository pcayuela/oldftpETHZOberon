
/***********
 * OberonTypes.h
 * C definition of basic Oberon types and type descriptor formats
 * Marc-Michael Brandis, 22.8.91 / 29.8.91
 ***********/

#ifndef _I_OBERONTYPES
#define _I_OBERONTYPES

#include "POP2limits.h"

/* basic Oberon types */
typedef unsigned char CHAR;
typedef CHAR BYTE;
typedef signed char SHORTINT;
typedef signed short int INTEGER;
typedef signed int LONGINT;
typedef unsigned int SET;
typedef unsigned char BOOLEAN;

#define FALSE 0
#define TRUE 1

typedef LONGINT ADDRESS;

typedef struct _procedure_desc {
	LONGINT PC, SB;
} PROCEDURE;

/* type descriptor formats */
typedef struct _type_descriptor {
	/* PROCEDURE methods[nofmethods],
		starting at offset -8-MaxExts*4 in negative direction */
	/* ADDRESS basetags[MaxExts],
		starting at offset -8 in negative direction */
	/* ADDRESS tag, at offset -4 */
	LONGINT recsize;
	LONGINT ptroff;
	/* ptroff is actually an array terminated by the value -4-nofptr*4 */
} TypeDescriptor;

typedef TypeDescriptor* Tag;

typedef CHAR TypeName[32];

typedef struct _super_descriptor {
	LONGINT tdsize;
	LONGINT ptroff;	/* contains always -4 */
	Tag tag;
	SHORTINT pad[3];
	SHORTINT ext0;
	TypeName typename;
	ADDRESS Module;
} SuperDescriptor;

typedef struct _array_desc {
	ADDRESS lastelem, reserved, firstelem;
	LONGINT len;
} ArrayDesc;

typedef SuperDescriptor* SuperTag;
typedef TypeDescriptor SystemTD;

#define TagMask 0xfffffffe

/* macros to access the special fields */
#define TAG(obj) (((long int *)&(obj))[-1])
#define PTROFF(tdesc, nr) (((long int *)&((tdesc).ptroff))[nr])
#define BASETAG(tdesc, nr) (((long int *)&(tdesc))[-2-nr])
#define METHOD(tdesc, nr) (*((PROCEDURE *)&(((long int *)&(tdesc))[-3-MaxExts-nr*2])))

#endif