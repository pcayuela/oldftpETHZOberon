/* NCFSExtend	OJ 21.8.99 */
/* Tool to enlarge a NCFS file */

#include <sys/types.h>
#include <signal.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <strings.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>

#include <netdb.h>
#include <pwd.h>
#include <setjmp.h>

#include <sys/socket.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <arpa/inet.h>


/*--- Support for Oberon style ---------------------------------------------------------*/

#define FALSE 0
#define TRUE 1
#define ORD(ch) ((INTEGER)(ch))
#define CHR(asc) ((CHAR)((asc) & 0xFF))
#define NEW(obj) { (obj)=(void *)malloc(sizeof(*(obj))); }
#define DISPOSE(obj) { free((void *)(obj)); }
#define HALT(n) \
	{ \
		printf("\nHALT(%d) in line %d of %s (errno=%d)\n", \
		(INTEGER)(n), __LINE__, __FILE__, errno); \
		exit(1); \
	}

typedef unsigned char BYTE;
typedef unsigned char CHAR;
typedef signed char SHORTINT;
typedef signed short INTEGER;
typedef signed long LONGINT;
typedef SHORTINT BOOLEAN;


/*--- Server specific constants and types --------------------------------------*/

#define BS 1024			/* Block size */
#define NCFSBlockAdr 0	/* Volume block address  */
#define NCFSIdAdr 1	/* Id block address  */
#define NCFSDirRootAdr 2	/* Directory root block address  */
#define NCFSMark 0x9B83A11F	/* Identifier of a volume file */

#define NCFSRemoteMark 0x89A51C9B	/* Identifier of a RemoteFiles volume (network order) */
#define NCFSDirMark 0x8DA31E9B	/* Identifier of a directory page (network order) */

#define PwdLength 32	/* Password Length */

typedef LONGINT Address;

typedef struct {
	LONGINT mark;		/* Mark to identify a volume file */
	LONGINT mountCount;	/* Counter for writer mounts */
	LONGINT reopenCount;	/* Counter for writer reopens */
	CHAR pwd[PwdLength];	/* Password to get write access */
	BYTE fill[BS-3*sizeof(LONGINT)-PwdLength];
} NCFSBlock;


/*--- Access procedures -----------------------------------------------------------*/

static void GetBlock(int f, Address adr, void *data)
{
	lseek(f, adr*BS, SEEK_SET);
	read(f, data, BS);
}

static void PutBlock(int f, Address adr, void *data)
{
	lseek(f, adr*BS, SEEK_SET);
	write(f, data, BS);
}


/*--- The tool --------------------------------------------------------*/

int main(int argc, char *argv[])
{
	int f;
	Address oldsize, newsize;	/* number of blocks! */
	NCFSBlock blk;

	if (argc < 3) {
		printf("Usage:  %s <filename> <new size in kByte> [ <new password> ]\n", argv[0]);
	} else {
		f = open(argv[1], O_RDWR, 0666);  
		if (f < 0) {
			f = open(argv[1], O_RDWR | O_CREAT, 0666);
			if (f < 0) {
				printf("Cannot create %s\n", argv[1]);
			} else {
				newsize = (Address)((atol(argv[2]) * 1024 +(BS-1))/ BS);
				if ( newsize <= 32 ) {
					printf("New size is too small\n");
					unlink(argv[1]);
				} else {
						/* init volume block */
					bzero(&blk, BS);
					blk.mark = htonl(NCFSMark);  blk.mountCount = blk.reopenCount = htonl(0);
					if (argc >= 4) {
						strncpy(blk.pwd, argv[3], PwdLength);
						printf("Password set\n");
					}
					PutBlock(f, NCFSBlockAdr, &blk);
						/* init id page */
					bzero(&blk, BS);
					blk.mark = htonl(NCFSRemoteMark);
					PutBlock(f, NCFSIdAdr, &blk);
						/* init dir root page */
					bzero(&blk, BS);
					blk.mark = htonl(NCFSDirMark);
					PutBlock(f, NCFSDirRootAdr, &blk);
						/* init map root page */
					bzero(&blk, BS);
					PutBlock(f, newsize-1, &blk);
					printf("Size of %s is %ld kByte\n", argv[1], (long)lseek(f, 0, SEEK_END) / 1024);
					close(f);
				}
			}
		} else {
			GetBlock(f, NCFSBlockAdr, &blk);
			if (ntohl(blk.mark) != NCFSMark) {
				printf("%s is not a NCFS file\n", argv[1]);
			} else {
				if ((argc >= 4) && strncmp(argv[3], blk.pwd, PwdLength)) {
					strncpy(blk.pwd, argv[3], PwdLength);
					PutBlock(f, NCFSBlockAdr, &blk);
					printf("Password changed\n");
				}
				oldsize = (Address)(lseek(f, 0, SEEK_END) / BS);
				newsize = (Address)((atol(argv[2]) * 1024 +(BS-1))/ BS);
				if ( newsize <= oldsize ) {
					printf("Size is already %ld kByte\n", oldsize * BS / 1024);
				} else {
					bzero(&blk, BS);
					PutBlock(f, newsize-1, &blk);
					printf("New size of %s is %ld kByte\n", argv[1], (long)lseek(f, 0, SEEK_END) / 1024);
				}
			}
			close(f);
		}
	}
	exit(0);
}
