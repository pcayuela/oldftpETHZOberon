/*
Password generator
usage: genpass [seed] < loginlist
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[])
{
	int i, j, ch;
	char pwd[10];
	char in[200];

	if (argc > 1) { srand(atoi(argv[1])); } else { srand(time(0)); }

	while (fgets(in, sizeof(in), stdin)) {
		i = strlen(in);
		if (i > 0) { in[i-1] = 0; }
		for (j = 0;  j < 6; j++) {
			ch = rand() % (26+10);
			if (ch > 9) {
				ch += 'a' - 10;
			} else {
				ch += '0';
			}
			pwd[j] = ch;
		}
		pwd[j] = 0;
		printf("NCFSExtend %s.ncfs 1001 %s\n", in, pwd);
	}
	return 0;
}
