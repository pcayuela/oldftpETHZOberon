/* NCFSServer	OJ 11.6.99 */
/* Server for remote persistent volumes in Oberon System via UDP */

#include <sys/types.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <signal.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <strings.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>
#include <stdarg.h>

#include <netdb.h>
#include <pwd.h>
#include <setjmp.h>

#include <sys/socket.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "zlib.h"

/* Macro for a (non-portable) function to suspend execution for approx. <ms> miliseconds */
#define MSleep(ms) usleep(ms*1000)

#ifndef VOLPREFIX
#error VOLPREFIX not defined
#endif

#define MAXDUMP 16
#define SYSPREFIX VOLPREFIX "system"

/*--- Support for Oberon style ---------------------------------------------------------*/

#define FALSE 0
#define TRUE 1
#define ORD(ch) ((INTEGER)(ch))
#define CHR(asc) ((CHAR)((asc) & 0xFF))
#define NEW(obj) { (obj)=(void *)malloc(sizeof(*(obj))); }
#define DISPOSE(obj) { free((void *)(obj)); }
#define HALTSTR(s) \
	{ \
		printf("\nHALT(%s) in line %d of %s (%s)\n", \
		(const char *)(s), __LINE__, __FILE__, strerror(errno)); \
		exit(1); \
	}

typedef unsigned char BYTE;
typedef unsigned char CHAR;
typedef signed char SHORTINT;
typedef signed short INTEGER;
typedef signed long LONGINT;
typedef SHORTINT BOOLEAN;


/*--- Constants and types for communication --------------------------------------------*/

#define PORT 5012		/* UDP port */

#define VFnLength 128	/* Volume filename length */
#define PwdLength 32	/* Password Length */

#define HS 16	/* size of crc header */
#define BS 1024			/* Block size */
#define AdrDGSize (8 + HS)	/* Bytesize of address part in get/put datagram */
#define BlockDGSize (AdrDGSize + BS)	/* Bytesize of a block transfer datagram */
#define OpenAnsSize (21 + HS)	/* Bytesize of open answer datagram */
#define MaxDGSize BlockDGSize	/* Max. bytesize of a datagram */

#define SockBufSize 128000

typedef LONGINT Address;

const SHORTINT getOp = 1;	/* Operation codes */
const SHORTINT putOp = 2;
const SHORTINT openOp = 3;
/*const SHORTINT createOp = 4;*/

const SHORTINT done = 0;	/* General message result codes */
const SHORTINT readonly = 1;
const SHORTINT failed = 2;
const SHORTINT unable = 3;
const SHORTINT badvid = 4;

const SHORTINT notfound = 10;	/* Error codes of an OpenAns message */
const SHORTINT invalid = 11;
const SHORTINT inuse = 12;
const SHORTINT modified = 13;

/*--- Server specific constants, types and variables --------------------------------------*/

#define ProxyAge 15	/* Age of a proxy in seconds */
#define SweepInterval 5	/* Time between two Sweep() in seconds */
#define LockTime 5		/* Estimated avg. time for a GetBlock() in millisecs */
#define LockTries 1	/* number of tries to get a lock */

#define NCFSBlockAdr 0	/* Volume block address  */
#define NCFSMark 0x9B83A11F	/* Identifier of a volume file */

typedef struct {
	LONGINT mark;		/* Mark to identify a volume file */
	LONGINT mountCount;	/* Counter for writer mounts */
	LONGINT reopenCount;	/* Counter for writer reopens */
	CHAR pwd[PwdLength];	/* Password to get write access */
	BYTE fill[BS-3*sizeof(LONGINT)-PwdLength];
} NCFSBlock;

typedef struct ProxyStruct {
	struct ProxyStruct *next;
	INTEGER vid;			/* Volume id */
	int timeout;				/* Time of death */
	int f;							/* File handle */
	Address size;			/* Number of remotely accessable blocks */
	BOOLEAN writable;	/* Access permission */
	LONGINT mountCount;	/* Copy of mountCount of volume */
	LONGINT reopenCount;	/* Copy of reopenCount of volume */
	CHAR fname[VFnLength];	/* Complete volume filename */
	struct sockaddr_in adr;	/* client IP address */
} Proxy;


static Proxy *active, *tomb;	/* Proxy lists */

static INTEGER nextVid;		/* Next volume id for a new proxy */
static int sweepTime;			/* Next time to sweep */

static BOOLEAN stopped;		/* CTRL-C pressed */

static int volprefixlen;

struct sockaddr_in clientAdr;	/* currently only one client at a time */

/*--- Function prototypes ---------------------------------------------------------*/

static BOOLEAN LockFile(CHAR *fname, struct sockaddr_in adr);
static void UnlockFile(CHAR *fname);
static void GetBlock(int f, Address adr, void *data);
static void PutBlock(int f, Address adr, void *data);

static INTEGER NextVid(void);
static Proxy *NewProxy(CHAR *fname, CHAR *pwd, BOOLEAN mounting, LONGINT mountCount, struct sockaddr_in adr, SHORTINT *resPtr);
static void KillProxy(Proxy *prx, int where);
static void RecycleProxy(Proxy *prx);
static Proxy *ThisProxy(INTEGER vid, struct sockaddr_in adr);

static void SweepDead(void);
static void SweepCompetitors(int f);
static void Cleanup(void);

static void Serve(int sock);


/*--- Debugging support ----------------------------------------------------------*/


int debug = 1;

static void dprintf(const char *fmt, ...)
{
	va_list ap;
	if (debug) {
		va_start(ap, fmt);
		(void)vprintf(fmt, ap);
		va_end(ap);
		fflush(stdout);
	}
}

static void dstamp(void)
{
	char *logtime;
	CHAR *s;
	struct tm *tm;
	time_t clock;

	time(&clock);
	tm = localtime(&clock);
	logtime = asctime(tm);
	if (logtime[24] == '\n') {
		logtime[24] = '\0';
	}
  dprintf("%s ", logtime);
	/*if (clientAdr.sin_addr.s_addr != 0)*/ {
		s = (CHAR *)&(clientAdr.sin_addr.s_addr);
		dprintf("%d.%d.%d.%d:%d ", s[0], s[1], s[2], s[3], clientAdr.sin_port);
	}
}

static void Dump(const char * action, BYTE *buf, int n)
{
	int i;

	dprintf("%s: ", action, n-1);
	for(i = 0;  i < (n > MAXDUMP ? MAXDUMP : n); i++) {
		dprintf("%02x ", buf[i]);
	}
	for(i = 0;  i < (n > MAXDUMP ? MAXDUMP : n); i++) {
		dprintf("%c", (buf[i] < ' ' || buf[i] > '~' ? '.' : buf[i]));
	}
	dprintf("\n");
}

static char *FileName(char *f)
{
	if (strncmp(f, VOLPREFIX, volprefixlen) == 0) {
		return (f+volprefixlen);
	} else {
		return f;
	}
}

/*--- File access -----------------------------------------------------------------*/

static BOOLEAN LockFile(CHAR *fname, struct sockaddr_in adr)
{
	CHAR lockname[VFnLength+5];
	int lock, retry = 0;
	struct sockaddr_in lockadr;
	
	strncpy(lockname, fname, VFnLength);
	strncpy(&(lockname[strlen(fname)]), ".lock", 5);
	while (1) {
		lock = open(lockname, O_RDWR | O_CREAT | O_EXCL, 0666);
		if (lock >= 0) {
			(void)write(lock, &adr.sin_addr.s_addr, 4);
			(void)close(lock);
			return 1;	/* success */
		}
		if (errno != EEXIST) {	/* abnormal error code */
			dstamp();
			dprintf("LockFile: create %s %s\n", strerror(errno), FileName(lockname));
		} else {	/* "normal" error code - file exists */
			lock = open(lockname, O_RDONLY, 0666);
			if (lock >= 0) {	/* file still exists */
				if (read(lock, &lockadr.sin_addr.s_addr, 4) == 4) {
					if (lockadr.sin_addr.s_addr == adr.sin_addr.s_addr) {	/* same client */
						dstamp();
						dprintf("LockFile: already locked\n");
						(void)close(lock);
						return 1;	/* success */
					} else {
						CHAR *s = (CHAR *)&(lockadr.sin_addr.s_addr);
						dstamp();
						dprintf("LockFile: locked by %d.%d.%d.%d\n", s[0], s[1], s[2], s[3]);
					}
				} else {
					dstamp();
					dprintf("LockFile: read %s %s\n", strerror(errno), FileName(lockname));
				}
				(void)close(lock);
			} else {
				dstamp();
				dprintf("LockFile: open %s %s\n", strerror(errno), FileName(lockname));
			}
		}
		if (++retry >= LockTries) { return 0;	/* failure */ }
		MSleep(LockTime + (random() % LockTime));
	}
	return lock >= 0;
}

static void UnlockFile(CHAR *fname)
{
	CHAR lockname[VFnLength+5];
	int res;
	
	strncpy(lockname, fname, VFnLength);
	strncpy(&(lockname[strlen(fname)]), ".lock", 5);
	res = unlink(lockname);
	if (res < 0) {
		dstamp();
		dprintf("UnlockFile: %s %s\n", strerror(errno), FileName(fname));
	}
}


static void GetBlock(int f, Address adr, void *data)
{
	int res;
	res = lseek(f, adr*BS, SEEK_SET);
	if (res != adr*BS) { HALTSTR("lseek"); }
	res = read(f, data, BS);
	if (res != BS) { HALTSTR("read"); }
	if (debug > 1) {
		dstamp();
		dprintf("GetBlock(%ld)\n", adr);
		if (debug > 2) {
			Dump("getblock", (BYTE *)data, 16);  
		}
	}
}

static void PutBlock(int f, Address adr, void *data)
{
	int res;
	res = lseek(f, adr*BS, SEEK_SET);
	if (res != adr*BS) { HALTSTR("lseek"); }
	res = write(f, data, BS);
	if (res != BS) { HALTSTR("write"); }
	if (debug > 1) {
		dstamp();
		dprintf("PutBlock(%ld)\n", adr);
		if (debug > 2) {
			Dump("putblock", (BYTE *)data, 16);  
		}
	}
}


/*--- Proxies -----------------------------------------------------------*/

/* Count in 1..32767 */
static INTEGER NextVid(void)
{
	nextVid++;
	if (nextVid < 0) { nextVid = 1; }
	return nextVid;
}


/* Create a new proxy for a volume file */
static Proxy *NewProxy(CHAR *fname, CHAR *pwd, BOOLEAN mounting, LONGINT mountCount, struct sockaddr_in adr, SHORTINT *resPtr)
{
	int f;
	Proxy *prx;
	NCFSBlock ncblk;
	BOOLEAN writable;
	int now = time(NULL);
	SHORTINT res = invalid;

	f = open(fname, O_RDWR, 0666);
	if (f < 0) {
  	dstamp();
		dprintf("Open: %s %s\n", strerror(errno), FileName(fname));
		res = notfound;
	} else {
		GetBlock(f, NCFSBlockAdr, &ncblk);
		if (ntohl(ncblk.mark) != NCFSMark) {
			dstamp();
			dprintf("Open: not an NCFS file (%08x) %s\n", ncblk.mark, FileName(fname));
			res = invalid;
		} else {

			if (! LockFile(fname, clientAdr)) {
				dstamp();
				dprintf("Open: in use %s\n", FileName(fname));
				res = inuse;
			} else {
	
				GetBlock(f, NCFSBlockAdr, &ncblk);
				if( !mounting && (mountCount != ntohl(ncblk.mountCount)) ) {
					dstamp();
					dprintf("Open: modified %s\n", FileName(fname));
					UnlockFile(fname);
					res = modified;
				} else {
			
					writable = (pwd[0] != 0) && (strncmp(pwd, ncblk.pwd, PwdLength) == 0);
					if (writable) {
						SweepCompetitors(f);
						if(mounting) {
							ncblk.mountCount = htonl(ntohl(ncblk.mountCount)+1);
						} else {
							ncblk.reopenCount = htonl(ntohl(ncblk.reopenCount)+1);
						}
						PutBlock(f, NCFSBlockAdr, &ncblk);
						res = done;
					} else {
						UnlockFile(fname);
						if (strncmp(fname, SYSPREFIX, strlen(SYSPREFIX)) == 0) {
							res = done;	/* allow read-only access */
						} else {
							res = failed;	/* fail access */
						}
					}
				}
			}
		}
	}
	if (res != done) {
		prx = NULL;
		if (f >= 0) { close(f); }
	} else {
		if (tomb == NULL) { NEW(prx); } else { prx = tomb;  tomb = tomb->next; }
		prx->vid = NextVid();
		prx->timeout = now + ProxyAge;
		prx->f = f;
		prx->size = (Address)(lseek(f, 0, SEEK_END) / BS) - 1;
		prx->writable  = writable;
		strncpy(prx->fname, fname, VFnLength);
		prx->mountCount = ntohl(ncblk.mountCount);
		prx->reopenCount = ntohl(ncblk.reopenCount);
		prx->adr = adr;
	}
	*resPtr = res;
	return prx;
}


/* Display a proxy */
static void ShowProxy(Proxy *prx)
{
	CHAR *s = (CHAR *)&(prx->adr.sin_addr.s_addr);

	dprintf("%d.%d.%d.%d:%d %d %d %d %d %d %s",
		s[0], s[1], s[2], s[3], prx->adr.sin_port, prx->vid, prx->f, prx->writable,
		prx->mountCount, prx->reopenCount, FileName(prx->fname));
	if (debug > 1) {
		dprintf("%d %d\n", prx->size, prx->timeout);
	} else {
		dprintf("\n");
	}
}

/* Kill a proxy */
static void KillProxy(Proxy *prx, int where)
{
	if (debug > 1) {
		dstamp();
		dprintf("Close: %s\n", FileName(prx->fname));
	}
	dstamp();
	dprintf("%d ", where);
	ShowProxy(prx);
	if (prx->writable && (where != 2)) {
		UnlockFile(prx->fname);
	}
	close(prx->f);
	prx->vid = 0;
}


/* Refresh a dead but not yet sweeped proxy */
static void RecycleProxy(Proxy *prx)
{
	dstamp();
	dprintf("Recycle: vid %d", prx->vid);
	prx->vid = NextVid();
	prx->timeout = time(NULL) + ProxyAge;
	dprintf(" -> %d\n", prx->vid);
}


/* Find a proxy by its volume id (NULL if not found) */
static Proxy *ThisProxy(INTEGER vid, struct sockaddr_in adr)
{
	Proxy *prx;

	if (vid < 0) {
		return NULL;
	} else {
		prx = active;
		while ((prx != NULL) && ((prx->vid != vid) || 
				(prx->adr.sin_addr.s_addr != adr.sin_addr.s_addr))) {
			prx = prx->next;
		}
		if (prx == NULL && debug > 1) {
			dstamp();
			dprintf("Bad vid %d\n", vid);
		}
		return prx;
	}
}


/* Collect all dead proxies */
static void SweepDead(void)
{
	Proxy *prev, *cur;
	int now = time(NULL);

	cur = active;
	while (cur != NULL) {
		if (difftime(cur->timeout, now) <= 0) {
			KillProxy(cur, 1);
			if (cur == active) {
				active = active->next;  cur->next = tomb;  tomb = cur;  cur = active;
			} else {
				prev->next = cur->next;  cur->next = tomb;  tomb = cur;  cur = prev->next;
			}
		} else {
			prev = cur;  cur = cur->next;
		}
	}
}


/* Collect all proxies of volume file f */
static void SweepCompetitors(int f)
{
	Proxy *prev, *cur;
	struct stat curstat, newstat;

	if (fstat(f, &newstat) == 0) {
		cur = active;
		while (cur != NULL) {
			if ( (fstat(cur->f, &curstat) == 0) &&
							(curstat.st_ino == newstat.st_ino) && (curstat.st_dev == newstat.st_dev) ) {
				KillProxy(cur, 2);	/* lock will not be deleted, because new client holds it! */
				if (cur == active) {
					active = active->next;  cur->next = tomb;  tomb = cur;  cur = active;
				} else {
					prev->next = cur->next;  cur->next = tomb;  tomb = cur;  cur = prev->next;
				}
			} else {
				prev = cur;  cur = cur->next;
			}
		}
	}
}


/* Cleanup before exit */
static void Cleanup(void)
{
	Proxy *prx;

	prx = active;
	while (prx != NULL) { KillProxy(prx, 3);  DISPOSE(prx);  prx = prx->next; }
	prx = tomb;
	while (prx != NULL) { DISPOSE(prx);  prx = prx->next; }
	dstamp();
	dprintf("NCFSServer exiting\n");
}


/*--- Server loop -------------------------------------------------------*/

static void Serve(int sock)
{
	Proxy * prx;
	Address dadr;
	int n, adrLen, now, i, j, sres;
	LONGINT mountCount;
	SHORTINT op, res;
	INTEGER vid;
	BYTE buf[MaxDGSize];
	CHAR vfName[VFnLength], pwd[PwdLength];
	struct timeval tv;
	fd_set readfds;

	now = time(NULL);
	nextVid = (INTEGER)(now & 0x7fff);
	sweepTime = now + SweepInterval;

	while (! stopped) {
		bzero((char *) &clientAdr, sizeof(clientAdr));
		tv.tv_sec = SweepInterval;
		tv.tv_usec = 0;
		FD_ZERO(&readfds);
		/*FD_SET(STDIN_FILENO, &readfds);*/
		FD_SET(sock, &readfds);
		sres = select(sock+1, &readfds, NULL, NULL, &tv);
		if (sres < 0) {
			dstamp();
			dprintf("select: %s\n", strerror(errno));
			break;	/* exit server */
		}
		now = time(NULL);
		if (difftime(sweepTime, now) <= 0) {
			sweepTime = now + SweepInterval;
			SweepDead();
		}
		if (sres > 0) {
			adrLen = sizeof(clientAdr);
			n = recvfrom(sock, buf, MaxDGSize, 0, (struct sockaddr *)&clientAdr, &adrLen);
			if (n <= 0) {
				dstamp();
				dprintf("recvfrm: %s\n", strerror(errno));
				continue;	/* next */
			}
			if (debug > 2) {
				dstamp();
				dprintf("Rcv %d bytes\n", n);
				Dump("rcv", buf, n);
			}
			if (HS != 0) {
				uLong crc1, crc2;
				crc1 = ntohl(*((long *)(&buf[0])));
				for (i = 0;  i < 4;  i++) { buf[i] = 0; }	/* clear first 4 bytes (crc) */
				crc2 = crc32(crc32(0L, Z_NULL, 0), buf, n);
				if (crc1 != crc2) {
					dstamp();
					dprintf("Bad CRC %08x %08x\n", n, crc1, crc2);
					continue;	/* ignore packet */
				}
			}
			op = (SHORTINT)(buf[HS+0]);  res = unable;
			vid = ntohs(*((INTEGER *)(&(buf[HS+2]))));
			if ((op == getOp) && (n == AdrDGSize)) {	/* Get block */
				dadr = ntohl(*((long *)(&(buf[HS+4]))));
				prx = ThisProxy(vid, clientAdr);
				if (prx == NULL) {
					n = AdrDGSize;  res = badvid;
				} else {
					if ((dadr <= NCFSBlockAdr) || (dadr > prx->size)) {
						n = AdrDGSize;  res = failed;
					} else {
						GetBlock(prx->f, dadr, &(buf[AdrDGSize]));
						n = BlockDGSize;  res = done;
					}
				}

			} else if ((op == putOp) && (n == BlockDGSize)) {	/* Put block */
				dadr = ntohl(*((long *)(&(buf[HS+4]))));
				prx = ThisProxy(vid, clientAdr);
				if (prx == NULL) {
					n = AdrDGSize;  res = badvid;
				} else {
					if ((dadr <= NCFSBlockAdr) || (dadr > prx->size) ) {
						n = AdrDGSize;  res = failed;
					} else if (! prx->writable) {
							n = AdrDGSize;  res = readonly;
					} else {
						PutBlock(prx->f, dadr, &(buf[AdrDGSize]));
						n = AdrDGSize;  res = done;
					}
				}

			} else if ((op == openOp) && (n >= HS+10)) {	/* (Re)Open volume */
				mountCount = ntohl(*((LONGINT *)(&(buf[HS+4]))));
					/* find last / in specified volume name */
				i = HS+8;  j = HS+7;
				while (i < n && buf[i] != 0) {
					if (buf[i] == '/') { j = i; }
					++i;
				}
					/* prepend fixed volume prefix instead of user-specified one */
				strcpy(vfName, VOLPREFIX);
				i = 0;  while (vfName[i] != 0) { i++; };
				++j;	/* skip to start of filename */
				if (buf[j] != '.') {
					while (i < VFnLength-1 && j < n && buf[j] != 0) {
						vfName[i++] = buf[j++];
					}
				} else {	/* user filename starts with '.' - fail */
					i = 0;
				}
				vfName[i] = 0;
					/* get user-specified password */
				i = 0;  ++j;
				while (i < PwdLength-1 && j < n && buf[j] != 0) {
					pwd[i++] = buf[j++];
				}
				pwd[i] = 0;
					/* open the proxy */
				prx = ThisProxy(vid, clientAdr);
				if (prx == NULL) {
					prx = NewProxy(vfName, pwd, vid<0, mountCount, clientAdr, &res);
					if(prx != NULL) { prx->next = active;  active = prx; }
				} else {
					RecycleProxy(prx);
				}
				if (prx == NULL) {
					n = HS+4;  /* res was set by NewProxy */
				} else {
					*((LONGINT *)(&(buf[HS+4]))) = htonl(prx->mountCount);
					*((LONGINT *)(&(buf[HS+8]))) = htonl(prx->reopenCount);
					*((Address *)(&(buf[HS+12]))) = htonl(prx->size);
					*((INTEGER *)(&(buf[HS+16]))) = htons(ProxyAge);
					*((INTEGER *)(&(buf[HS+18]))) = htons(prx->vid);
					*((SHORTINT *)(&(buf[HS+20]))) = (prx->writable ? 1 : 0);
					n = OpenAnsSize;  res = done;
				}

			} else {
				dprintf("unknown message %d!\n", op);
				n = 0;
			}
			
			if (n > 0) {
				buf[HS+1] = res;
				if (HS != 0) {
					uLong crc;
					for (i = 0;  i < 4;  i++) { buf[i] = 0; }	/* clear crc */
					crc = crc32(crc32(0L, Z_NULL, 0), buf, n);
					*((LONGINT *)(&buf[0])) = htonl(crc);
				}
				sendto(sock, buf, n, 0, (struct sockaddr *)&clientAdr, adrLen);
				if (debug > 2) {
					dstamp();
					dprintf("Snd %d bytes\n", n);
					Dump("snd", buf, n);
				}
			}
		}
	}
}

static void catchBreak(int signo)
{
	stopped = TRUE;
}

static void setSocketBuffer(int s, int size)
{
	int len, res, value;

	len = sizeof(int);
	res = getsockopt(s, SOL_SOCKET, SO_RCVBUF, (void *)&value, &len);
	if (res != 0) { HALTSTR("getsockopt"); }
	value = size;
	res = setsockopt(s, SOL_SOCKET, SO_RCVBUF, (void *)&value, sizeof(int));
	if (res != 0) { HALTSTR("setsockopt"); }
	len = sizeof(int);
	res = getsockopt(s, SOL_SOCKET, SO_RCVBUF, (void *)&value, &len);
	if (res != 0) { HALTSTR("getsockopt"); }
	if (value != size) { HALTSTR("sockbufsize"); }
}

int main(int argc, char *argv[])
{
	int s, res;
	struct sockaddr_in serv_addr;

	volprefixlen = strlen(VOLPREFIX);

	dstamp();
	dprintf("NCFSServer starting %s\n", VOLPREFIX);

	stopped = FALSE;
	signal(SIGINT, catchBreak);
	signal(SIGTERM, catchBreak);
	signal(SIGHUP, SIG_IGN);

	s = socket(AF_INET, SOCK_DGRAM, 0);
	if (s  < 0) {
		HALTSTR("socket");
	} else {
		setSocketBuffer(s, SockBufSize);

		bzero((char *) &serv_addr, sizeof(serv_addr));
		serv_addr.sin_family = AF_INET;
		serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
		serv_addr.sin_port = htons(PORT);
		
		res = bind(s, (struct sockaddr *) &serv_addr, sizeof(serv_addr));
		if (res < 0) {
			HALTSTR("bind");
		} else {
			active = NULL;  tomb = NULL;
			atexit(Cleanup);
			Serve(s);
		}
		
	}
	return 0;
}

