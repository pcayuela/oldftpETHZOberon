The Oberon Utility Disk is ideal for diagnosing hardware problems with PCs.
Simply install the util.dsk image file on a diskette using rawrite.exe, boot
from the diskette and you have a small RAM disk-based Oberon system which can
scan the PCI bus and read partition tables from ATA/ATAPI, Adaptec 7xxx SCSI
and NCR 810 SCSI devices.

Pieter Muller
28.03.00 (updated 24.07.00)
